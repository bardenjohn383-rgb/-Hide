package com.dyhide;

/** 隐藏规则：按 TextView 文字 / contentDescription 匹配（不依赖被混淆的资源ID）。 */
final class Rules {
    static final class R {
        final String group, label;
        final boolean exact;
        final String[] pats;

        R(String group, String label, boolean exact, String... pats) {
            this.group = group; this.label = label; this.exact = exact; this.pats = pats;
        }

        String key() { return "r_" + label; }

        boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            for (String p : pats) {
                if (exact ? t.equals(p) : t.contains(p)) return true;
            }
            return false;
        }
    }

    static final R[] ALL = {
        new R("首页", "拍同款", false, "拍同款"),
        new R("首页", "顶部：经验", true, "经验"),
        new R("首页", "顶部：热点", true, "热点"),
        new R("首页", "顶部：精选", true, "精选"),
        new R("首页", "顶部：同城", true, "同城"),
        new R("首页", "顶部：直播", true, "直播"),
        new R("首页", "作者声明", false, "作者声明"),

        new R("评论区", "大家都在搜", false, "大家都在搜"),
        new R("评论区", "AI解析", false, "AI解析", "AI 解析"),

        new R("侧边栏", "扫一扫", true, "扫一扫"),
        new R("侧边栏", "我的钱包", true, "我的钱包", "钱包"),
        new R("侧边栏", "券包", true, "券包"),
        new R("侧边栏", "通知消息", true, "通知消息"),
        new R("侧边栏", "离线缓存", true, "离线缓存"),
        new R("侧边栏", "稍后再看", true, "稍后再看"),
        new R("侧边栏", "我的转化记录", true, "我的转化记录"),
        new R("侧边栏", "抖音创作者中心", true, "抖音创作者中心", "创作者中心"),
        new R("侧边栏", "直播广场", true, "直播广场"),
        new R("侧边栏", "附近团购", true, "附近团购"),
        new R("侧边栏", "我的二维码", true, "我的二维码"),

        new R("我的页", "一起参与话题", false, "一起参与话题"),
    };
}
