package com.dyhide;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TARGET = "com.ss.android.ugc.aweme";
    static final String MODULE = "com.dyhide";
    static final Handler H = new Handler(Looper.getMainLooper());
    static final Map<View, Boolean> PENDING = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, WeakReference<View>> HIDDEN = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<View>>());
    static final Map<View, Long> LAST_DUMP = new WeakHashMap<>();
    static final Map<View, Boolean> ATTACHED = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static XSharedPreferences sp;
    static int scans, matched, navFixed;
    static long lastStatus;
    static String lastRoot = "";

    static final class Ctx {
        int sw, sh;
        float density;
        boolean nav;
        List<Rules.R> rules = new ArrayList<>();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TARGET.equals(lp.packageName)) return;
        sp = new XSharedPreferences(MODULE, "config");
        sp.makeWorldReadable();
        XposedBridge.log("DyHide: loaded in " + lp.processName + " sdk=" + android.os.Build.VERSION.SDK_INT);
        // 触发点1：每个窗口的 ViewRootImpl 绘制遍历
        try {
            Class<?> vri = XposedHelpers.findClass("android.view.ViewRootImpl", lp.classLoader);
            Set<XC_MethodHook.Unhook> u = XposedBridge.hookAllMethods(vri, "performTraversals", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Object o = XposedHelpers.getObjectField(p.thisObject, "mView");
                        if (o instanceof View) schedule((View) o);
                    } catch (Throwable ignored) { }
                }
            });
            XposedBridge.log("DyHide: performTraversals hooks=" + u.size());
        } catch (Throwable t) {
            XposedBridge.log("DyHide: ViewRootImpl hook failed: " + t);
        }
        // 触发点2（备用，不依赖隐藏API）：Activity.onResume / Dialog.show 时给窗口挂布局监听
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try { attach(((Activity) p.thisObject).getWindow().getDecorView()); } catch (Throwable ignored) { }
                }
            });
            XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try { attach(((Dialog) p.thisObject).getWindow().getDecorView()); } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DyHide: activity hook failed: " + t);
        }
        // 被隐藏的控件如果被应用重新设为可见，立即改回 GONE
        try {
            XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (((Integer) p.args[0]) != View.GONE && HIDDEN.containsKey(p.thisObject)) {
                        p.args[0] = View.GONE;
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DyHide: setVisibility hook failed: " + t);
        }
    }

    static void attach(final View decor) {
        if (decor == null || ATTACHED.containsKey(decor)) return;
        ATTACHED.put(decor, true);
        decor.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() { schedule(decor); }
        });
        schedule(decor);
    }

    static boolean on(String key, boolean def) {
        return sp == null ? def : sp.getBoolean(key, def);
    }

    static void schedule(final View root) {
        if (PENDING.containsKey(root)) return;
        PENDING.put(root, true);
        H.postDelayed(new Runnable() {
            @Override
            public void run() {
                PENDING.remove(root);
                try { scan(root); } catch (Throwable t) { XposedBridge.log(t); }
            }
        }, 250);
    }

    static void scan(View root) {
        if (!root.isAttachedToWindow()) return;
        if (sp != null && sp.hasFileChanged()) sp.reload();
        Ctx c = new Ctx();
        c.sw = root.getResources().getDisplayMetrics().widthPixels;
        c.sh = root.getResources().getDisplayMetrics().heightPixels;
        c.density = root.getResources().getDisplayMetrics().density;
        c.nav = on("nav_transparent", true);
        for (Rules.R r : Rules.ALL) if (on(r.key(), true)) c.rules.add(r);
        scans++;
        lastRoot = root.getClass().getName();
        if (scans == 1) XposedBridge.log("DyHide: first scan, rules=" + c.rules.size() + " nav=" + c.nav);
        walk(root, c);
        status();
        if (on("dump", true)) dump(root);
    }

    static boolean matchAny(View v, Ctx c) {
        CharSequence t = v instanceof TextView ? ((TextView) v).getText() : null;
        CharSequence d = v.getContentDescription();
        for (Rules.R r : c.rules) {
            if (r.match(t) || r.match(d)) return true;
        }
        return false;
    }

    static void walk(View v, Ctx c) {
        if (v.getVisibility() == View.GONE) {
            WeakReference<View> w = HIDDEN.get(v);
            if (w == null) return;
            View src = w.get();
            if (src != null && matchAny(src, c)) return;
            // 来源文字已变化（控件被复用）或规则被关闭：恢复显示
            HIDDEN.remove(v);
            v.setVisibility(View.VISIBLE);
        }
        if (matchAny(v, c)) {
            View target = climb(v, c);
            matched++;
            HIDDEN.put(target, new WeakReference<View>(v));
            if (target.getVisibility() != View.GONE) target.setVisibility(View.GONE);
            return;
        }
        if (c.nav && v instanceof TextView && "首页".contentEquals(((TextView) v).getText())) fixNav(v, c);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c);
        }
    }

    /** 向上找“整行/整个入口”容器：子项不超过3个、高度不超过文字的约3.5倍、不是整屏宽。 */
    static View climb(View v, Ctx c) {
        int h = v.getHeight();
        if (h <= 0) return v;
        View cur = v;
        for (int i = 0; i < 4; i++) {
            ViewParent p = cur.getParent();
            if (!(p instanceof ViewGroup)) break;
            ViewGroup g = (ViewGroup) p;
            if (g.getChildCount() > 3 || g.getWidth() > c.sw * 0.9f
                    || g.getHeight() > h * 3.5f + 16 * c.density) break;
            cur = g;
        }
        return cur;
    }

    /** 底栏透明：找到屏幕下方的“首页”标签，把它所在的底栏容器背景清掉。 */
    static void fixNav(View v, Ctx c) {
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        if (loc[1] < c.sh * 0.8f) return;
        View cur = v;
        for (int i = 0; i < 6; i++) {
            ViewParent p = cur.getParent();
            if (!(p instanceof View)) break;
            View pv = (View) p;
            if (pv.getHeight() > c.sh * 0.2f) break;
            Drawable bg = pv.getBackground();
            if (bg != null && !(bg instanceof ColorDrawable && ((ColorDrawable) bg).getColor() == 0)) {
                pv.setBackgroundColor(Color.TRANSPARENT);
                navFixed++;
            }
            cur = pv;
        }
    }

    static File outDir() throws Exception {
        Application app = (Application) Class.forName("android.app.ActivityThread")
                .getMethod("currentApplication").invoke(null);
        return app.getExternalFilesDir(null);
    }

    /** 状态文件：证明模块在抖音进程里跑起来了，以及命中了多少次。 */
    static void status() {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatus < 5000) return;
        lastStatus = now;
        try {
            File dir = outDir();
            if (dir == null) return;
            String t = "scans=" + scans + "\nhidden_hits=" + matched + "\nnav_fixes=" + navFixed
                    + "\nlast_root=" + lastRoot + "\nsdk=" + android.os.Build.VERSION.SDK_INT + "\n";
            FileOutputStream o = new FileOutputStream(new File(dir, "dyhide_status.txt"));
            try { o.write(t.getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
        } catch (Throwable ignored) { }
    }

    // ---------- 调试：导出控件树 ----------
    static void dump(View root) {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_DUMP.get(root);
        if (last != null && now - last < 3000) return;
        LAST_DUMP.put(root, now);
        try {
            File dir = outDir();
            if (dir == null) return;
            StringBuilder sb = new StringBuilder();
            sb.append("root=").append(root.getClass().getName()).append(' ')
                    .append(root.getWidth()).append('x').append(root.getHeight()).append('\n');
            dumpNode(root, 0, sb);
            File f = new File(dir, "viewdump_" + (System.identityHashCode(root) & 7) + ".txt");
            FileOutputStream o = new FileOutputStream(f);
            try { o.write(sb.toString().getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    static void dumpNode(View v, int depth, StringBuilder sb) {
        if (sb.length() > 600000) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            String n;
            try { n = v.getResources().getResourceEntryName(id); } catch (Throwable t) { n = Integer.toHexString(id); }
            sb.append(" #").append(n);
        }
        if (v instanceof TextView && ((TextView) v).getText().length() > 0)
            sb.append(" text=\"").append(cut(((TextView) v).getText())).append('"');
        if (v.getContentDescription() != null)
            sb.append(" desc=\"").append(cut(v.getContentDescription())).append('"');
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
                .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
        if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
        if (HIDDEN.containsKey(v)) sb.append(" HIDDEN");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpNode(g.getChildAt(i), depth + 1, sb);
        }
    }

    static String cut(CharSequence s) {
        String x = s.toString().replace('\n', ' ');
        return x.length() > 40 ? x.substring(0, 40) : x;
    }
}
