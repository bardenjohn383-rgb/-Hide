package com.dyhide;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int pad;

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences("config", MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences("config", MODE_PRIVATE);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences sp = prefs();
        pad = (int) (16 * getResources().getDisplayMetrics().density);
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        sv.addView(box);

        TextView title = text("抖音UI隐藏", 22, true);
        box.addView(title);
        box.addView(text("在 LSPosed 中启用本模块并勾选抖音，然后强行停止抖音。开关修改后无需重启抖音，约1秒内生效。", 13, false));

        String last = null;
        for (Rules.R r : Rules.ALL) {
            if (!r.group.equals(last)) { box.addView(text(r.group, 16, true)); last = r.group; }
            box.addView(sw(r.label, r.key(), true, sp));
        }
        box.addView(text("其他", 16, true));
        box.addView(sw("底栏背景全透明（图标和文字保持不透明）", "nav_transparent", true, sp));
        box.addView(sw("调试：导出控件树和状态文件（测试期保持开启）", "dump", true, sp));
        box.addView(text("开启调试后，在抖音里停留到目标界面几秒，文件保存在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/viewdump_*.txt 和 dyhide_status.txt", 12, false));
        sv.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(sv);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, pad / 2, 0, pad / 4);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Switch sw(String label, final String key, boolean def, final SharedPreferences sp) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(key, def));
        s.setPadding(0, pad / 3, 0, pad / 3);
        s.setOnCheckedChangeListener((v, on) -> sp.edit().putBoolean(key, on).apply());
        return s;
    }
}
