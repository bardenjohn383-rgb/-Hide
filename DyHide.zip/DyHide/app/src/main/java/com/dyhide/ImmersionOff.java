package com.dyhide;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 抖音里双击退出沉浸模式时发来的广播：把模块里的“沉浸模式”开关关掉（抖音进程没有权限改模块的配置）。 */
public final class ImmersionOff extends BroadcastReceiver {
    @Override
    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    public void onReceive(Context c, Intent i) {
        c.getSharedPreferences("config_local", Context.MODE_PRIVATE).edit().putBoolean("immersion", false).commit();
        if (MainActivity.isModuleActive()) c.getSharedPreferences("config", Context.MODE_WORLD_READABLE).edit().putBoolean("immersion", false).commit();   // 抖音读的那份
    }
}
