package com.dyhide;

import android.content.res.Resources;
import android.view.View;

/** 隐藏规则：按文字/描述、类名结尾、资源ID名匹配（ID名随抖音版本变化，这套规则对应 41.0.0）。 */
final class Rules {
    /** AUTO：自动向上找到整个入口；TEXT_ONLY：只隐藏匹配到的这个控件；CARD：隐藏所在的整张卡片。 */
    static final int AUTO = 0, TEXT_ONLY = 1, CARD = 2;

    static final class R {
        final String group, sub, label;
        final int mode;
        final boolean exact, overlayOnly;
        final String[] sel, pats;   // sel：类名结尾，或 "#"+资源ID名；pats：文字/描述；overlayOnly：只在弹窗/浮层窗口里匹配

        R(String group, String sub, int mode, boolean exact, boolean overlayOnly, String label, String[] sel, String[] pats) {
            this.group = group; this.sub = sub; this.mode = mode; this.exact = exact;
            this.overlayOnly = overlayOnly; this.label = label; this.sel = sel; this.pats = pats;
        }

        String key() { return "r_" + label; }

        boolean matchView(String cls, String id, CharSequence t, CharSequence d) {
            if (sel.length > 0) {
                for (String s : sel) {
                    if (s.charAt(0) == '#' ? s.substring(1).equals(id) : cls.endsWith(s)) return true;
                }
                return false;
            }
            return match(t) || match(d);
        }

        private boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            for (String p : pats) {
                if (exact ? t.equals(p) : t.contains(p)) return true;
            }
            return false;
        }
    }

    private static R t(String g, String sub, int mode, boolean exact, String label, String... p) {
        return new R(g, sub, mode, exact, false, label, new String[0], p);
    }

    private static R o(String g, String label, String... p) {
        return new R(g, null, AUTO, true, true, label, new String[0], p);
    }

    private static R s(String g, int mode, String label, String... sel) {
        return new R(g, null, mode, false, false, label, sel, new String[0]);
    }

    static final R[] ALL = {
        t("首页", null, AUTO, false, "拍同款", "拍同款"),
        s("首页", TEXT_ONLY, "右下角唱片", "MusicCoverContainerLayout", "#sz9"),
        t("首页", null, AUTO, true, "顶部：经验", "经验"),
        t("首页", null, AUTO, true, "顶部：热点", "热点"),
        t("首页", null, AUTO, true, "顶部：精选", "精选"),
        t("首页", null, AUTO, true, "顶部：同城", "同城"),
        t("首页", null, AUTO, true, "顶部：直播", "直播"),
        t("首页", null, AUTO, true, "顶部：团购", "团购"),
        t("首页", null, AUTO, false, "作者声明", "作者声明"),
        t("首页", null, AUTO, false, "视频章节要点", "章节要点"),
        t("首页", null, AUTO, false, "视频相关搜索", "相关搜索"),
        s("首页", AUTO, "视频声明警示", "FeedWarnForceCenterTextView"),
        t("首页", null, AUTO, false, "视频底部分享给好友", "分享给好友"),
        s("首页", TEXT_ONLY, "视频标题/话题（整段文案）", "ScrollMentionTextView"),

        t("评论区", null, AUTO, false, "大家都在搜", "大家都在搜"),
        t("评论区", null, AUTO, false, "AI解析", "AI解析", "AI 解析"),
        t("评论区", null, AUTO, true, "评论回复", "回复"),

        o("分享面板", "转发到日常", "转发到日常"),
        o("分享面板", "推荐", "推荐"),
        o("分享面板", "私信", "私信"),
        o("分享面板", "建群分享", "建群分享"),
        o("分享面板", "帮上热门", "帮上热门"),
        o("分享面板", "身边的人", "身边的人"),
        o("分享面板", "不感兴趣", "不感兴趣"),
        o("分享面板", "合拍", "合拍"),
        o("分享面板", "一起看视频", "一起看视频"),
        o("分享面板", "加桌面伙伴", "加桌面伙伴"),

        o("长按菜单", "投屏", "投屏"),
        o("长按菜单", "识别图片", "识别图片"),
        o("长按菜单", "定时关闭", "定时关闭"),

        t("侧边栏", null, AUTO, true, "扫一扫", "扫一扫"),
        t("侧边栏", null, AUTO, true, "我的钱包", "我的钱包", "钱包"),
        t("侧边栏", null, AUTO, true, "券包", "券包"),
        t("侧边栏", null, CARD, true, "通知消息", "通知消息"),
        t("侧边栏", "常用功能", AUTO, true, "离线缓存", "离线缓存"),
        t("侧边栏", "常用功能", AUTO, true, "稍后再看", "稍后再看"),
        t("侧边栏", "常用功能", AUTO, true, "我的转化记录", "我的转化记录"),
        t("侧边栏", "常用功能", AUTO, true, "抖音创作者中心", "抖音创作者中心", "创作者中心"),
        t("侧边栏", "常用功能", AUTO, true, "直播广场", "直播广场"),
        t("侧边栏", "常用功能", AUTO, true, "放映厅", "放映厅"),
        t("侧边栏", "常用功能", AUTO, true, "附近团购", "附近团购"),
        t("侧边栏", "常用功能", AUTO, true, "我的二维码", "我的二维码"),
    };

    static final boolean NEED_ID;

    static {
        boolean need = false;
        for (R r : ALL) for (String s : r.sel) need |= s.charAt(0) == '#';
        NEED_ID = need;
    }

    static String idName(View v) {
        if (v.getId() == View.NO_ID) return null;
        try {
            return v.getResources().getResourceEntryName(v.getId());
        } catch (Resources.NotFoundException e) {
            return null;
        }
    }
}
