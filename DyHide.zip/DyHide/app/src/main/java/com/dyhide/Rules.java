package com.dyhide;

import android.content.res.Resources;
import android.view.View;

/** 隐藏规则：按文字/描述、类名结尾、资源ID名匹配（ID名随抖音版本变化，这套规则对应 41.0.0）。 */
final class Rules {
    /** AUTO：自动向上找到整个入口；TEXT_ONLY：只隐藏匹配到的这个控件；UP：隐藏类名以 anc 结尾的最近祖先（整张卡片/整行）；CLEAR：不隐藏，只清掉背景（变透明）；DISMISS：命中后直接关掉所在的弹窗；CARD：隐藏整张卡片（找不到卡片容器时退回 AUTO）；CHILD：隐藏 anc 祖先下、包着匹配控件的那一个直接子项（整条栏里只收掉其中一种内容）；ROOT：隐藏匹配控件所在的整个窗口（Toast、弹出提示）；PARENT：隐藏 anc 祖先的父容器；BOX：从命中的控件往上找，取宽、高都不超过 box(w, h)（占屏幕的比例）的最大祖先——用来整块隐藏卡片、图标格子。 */
    static final int AUTO = 0, TEXT_ONLY = 1, UP = 2, CLEAR = 3, DISMISS = 4, CARD = 5, CHILD = 6, ROOT = 7, PARENT = 8, BOX = 9;

    static final class R {
        final String group, sub, label;
        final int mode;
        final boolean exact, overlayOnly;
        final String[] sel, pats;   // sel：类名结尾，或 "#"+资源ID名；pats：文字/描述；sel 和 pats 同时给出时两者都要满足
        int depth = 6;              // 查找祖先（anc / need）最多向上几层
        String anc, veto, need;     // anc：UP 模式的祖先（类名结尾，或 "#"+资源ID名）；veto：位于此类名的祖先内时不隐藏；need：必须位于此类名的祖先内
        float bw = 1f, bh = 1f;     // BOX 模式的宽、高上限（占屏幕宽、高的比例）
        boolean closes, live;       // closes：命中的控件在对话框里时，直接关掉这个对话框；live：只在直播间窗口里生效
        String[] alt;               // 另一条触发路径：文字/描述包含其中任一项就直接命中（不要求满足 sel），climb 和 anc/need/veto 规则相同
        String[] skip;              // 控件描述以其中任一前缀开头时不匹配（用来把“拍同款”“游戏”等同类入口排除掉）

        R(String group, String sub, int mode, boolean exact, boolean overlayOnly, String label, String[] sel, String[] pats) {
            this.group = group; this.sub = sub; this.mode = mode; this.exact = exact;
            this.overlayOnly = overlayOnly; this.label = label; this.sel = sel; this.pats = pats;
        }

        String key() { return "r_" + label; }

        /** 设置页里显示的名字：去掉“商城分类：”这类前缀，只留分类本身。 */
        String shown() { return label.startsWith("商城分类：") ? label.substring(5) : label; }

        R anc(String s) { anc = s; return this; }

        R veto(String s) { veto = s; return this; }

        R need(String s) { need = s; return this; }

        R deep() { depth = 8; return this; }

        R skip(String... prefixes) { skip = prefixes; return this; }

        R or(String... p) { alt = p; return this; }

        R closes() { closes = true; return this; }

        R live() { live = true; return this; }

        R box(float w, float h) { bw = w; bh = h; return this; }

        /** 文字是否命中本规则的文字模式（拦截提示窗口用）。 */
        boolean textHit(CharSequence t) { return match(t); }

        private boolean hitAlt(CharSequence s) {
            if (alt == null || s == null || s.length() == 0 || s.length() > 60) return false;
            for (String p : alt) if (s.toString().contains(p)) return true;
            return false;
        }

        /** 是不是靠 or(...) 的文字命中的（而不是靠 sel）。 */
        boolean viaAlt(CharSequence t, CharSequence d) { return hitAlt(t) || hitAlt(d); }

        boolean matchView(View v, String cls, String id, CharSequence t, CharSequence d) {
            if (hitAlt(t) || hitAlt(d)) return true;
            boolean bySel = sel.length == 0;
            for (String s : sel) {
                if (s.charAt(0) == '#' ? s.substring(1).equals(id) : cls.endsWith(s)) bySel = true;
            }
            if (bySel && skip != null && d != null) {
                for (String k : skip) if (d.toString().startsWith(k)) return false;
            }
            return bySel && (pats.length == 0 || match(t) || match(d));
        }

        private boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            for (String p : pats) {
                if (exact ? t.equals(p) : p.charAt(0) == '^' ? t.startsWith(p.substring(1)) : t.contains(p)) return true;
            }
            return false;
        }
    }

    private static R t(String g, String sub, int mode, boolean exact, String label, String... p) {
        return new R(g, sub, mode, exact, false, label, new String[0], p);
    }

    private static R o(String g, String label, String... p) {
        return new R(g, null, AUTO, true, true, label, new String[0], p);
    }

    private static R s(String g, int mode, String label, String... sel) {
        return new R(g, null, mode, false, false, label, sel, new String[0]);
    }

    private static R sp(String g, int mode, String label, String sel, String pat) {
        return new R(g, null, mode, false, false, label, new String[]{sel}, new String[]{pat});
    }

    /** 商城顶部的商品分类标签（Slc 列表里的一项）：必须位于 SlcItemView 内，避免误伤全局的“关注”“运动”等文字。 */
    private static R cat(String name) {
        return new R("商城", "商品分类", UP, true, false, "商城分类：" + name, new String[0], new String[]{name})
                .anc("SlcItemView").need("SlcItemView");
    }

    static final R[] ALL = {
        t("首页", null, AUTO, false, "拍同款", "拍同款", "玩同款"),
        s("首页", TEXT_ONLY, "右下角唱片", "MusicCoverContainerLayout", "#sz9"),
        t("首页", null, AUTO, true, "顶部：经验", "经验"),
        t("首页", null, AUTO, true, "顶部：热点", "热点"),
        t("首页", null, AUTO, true, "顶部：精选", "精选"),
        t("首页", null, AUTO, true, "顶部：同城", "同城"),
        t("首页", null, AUTO, true, "顶部：直播", "直播"),
        t("首页", null, AUTO, true, "顶部：团购", "团购"),
        t("首页", null, AUTO, false, "作者声明", "作者声明"),
        t("首页", null, AUTO, false, "视频章节要点", "章节要点"),
        sp("首页", UP, "视频底部搜索栏", "#title", "相关搜索").anc("#container").need("MeasureOnceFrameLayout"),
        t("首页", null, AUTO, false, "视频相关搜索", "相关搜索"),
        s("首页", AUTO, "视频声明警示", "FeedWarnForceCenterTextView"),
        sp("首页", AUTO, "视频游戏标签", "RoundedLinearLayout", "^游戏").need("FpsControlFrameLayout"),
        t("首页", null, UP, false, "视频底部汽水音乐标签", "汽水音乐听完整版", "^听完整版", "汽水音乐").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").deep(),   // 描述没设时靠里面的文字命中（最深 7 层）
        t("首页", null, UP, false, "视频底部热榜", "热榜").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").deep(),   // 整个榜单标签，不只是“热榜”两个字
        s("首页", UP, "视频位置", "RoundedLinearLayout").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").skip("拍同款", "游戏", "汽水音乐"),   // 按类名匹配标签（原来用的 #qon 会随抖音版本变）
        s("首页", CHILD, "视频底部广告", "#tv_description").anc("MeasureOnceFrameLayout").need("MeasureOnceFrameLayout"),
        t("首页", null, PARENT, true, "视频底部去汽水听卡片", "汽水音乐按钮").anc("FeedBottomMusicAnchorLayout"),   // 整条音乐信息行（徽标 + 音乐名）；按类名定位，不依赖会随版本变的混淆 id
        t("首页", null, UP, false, "视频底部挑战榜", "挑战榜").anc("MeasureOnceRelativeLayout2").need("MeasureOnceRelativeLayout2"),   // 视频底部整条挑战榜栏
        s("首页", CLEAR, "视频下方合集条背景全透明", "PlayletBottomConstraintLayout", "#fiw"),
        t("首页", null, UP, true, "刷到好友分享的视频提示", "分享给你").anc("TagLayout").need("TagLayout"),   // 头像 + 名字 + “分享给你”整条标签
        t("首页", null, CARD, false, "视频底部分享给好友", "^分享给").veto("IMShareTopAreaView"),
        t("首页", null, UP, false, "视频底部点击推荐", "点击推荐按钮", "人推荐按钮").anc("TagLayout").need("TagLayout").or("人推荐").closes(),   // “点击推荐 / 共N人推荐”整个标签；“你推荐了视频”弹层里出现同样文字就关掉弹层
        s("首页", TEXT_ONLY, "视频标题/话题（整段文案）", "ScrollMentionTextView"),

        s("评论区", UP, "大家都在搜", "CommentRelatedView").anc("FrameLayout"),   // 整行：“大家都在搜：”加上后面蓝色的搜索词
        t("评论区", null, AUTO, false, "AI解析", "AI解析", "AI 解析"),
        t("评论区", null, UP, false, "观看完整合集", "观看完整合集").anc("LinearLayout"),
        t("评论区", null, AUTO, false, "玩家讨论", "玩家讨论"),
        t("评论区", null, AUTO, false, "地点评价", "地点评价"),
        t("评论区", null, AUTO, false, "游戏标签（评论区）", "游戏标签"),


        t("我的页", null, BOX, false, "一起参与话题卡片", "一起参与话题").box(1f, 0.12f),   // 缩略图 + 标题 + “去发布”整张卡片

        t("提示", null, ROOT, true, "提示：收藏成功", "收藏成功"),   // 整个提示窗口（含“去看看”），不只是文字
        t("提示", null, ROOT, true, "提示：已取消推荐", "已取消推荐"),
        t("提示", null, ROOT, true, "提示：已取消收藏", "已取消收藏"),

        o("分享面板", "转发到日常", "转发到日常"),
        o("分享面板", "推荐", "推荐").veto("LongPressPanelCommonItemView"),
        o("分享面板", "私信", "私信"),
        o("分享面板", "建群分享", "建群分享"),
        o("分享面板", "帮上热门", "帮上热门"),
        o("分享面板", "身边的人", "身边的人"),
        o("分享面板", "不感兴趣", "不感兴趣").veto("LongPressPanelCommonItemView"),
        o("分享面板", "合拍", "合拍"),
        o("分享面板", "一起看视频", "一起看视频"),
        o("分享面板", "加桌面伙伴", "加桌面伙伴"),

        o("长按菜单", "投屏", "投屏"),
        o("长按菜单", "识别图片", "识别图片"),
        o("长按菜单", "定时关闭", "定时关闭"),


        t("侧边栏", null, AUTO, true, "扫一扫", "扫一扫"),
        t("侧边栏", null, AUTO, true, "我的钱包", "我的钱包", "钱包"),
        t("侧边栏", null, AUTO, true, "券包", "券包"),
        t("侧边栏", null, UP, true, "通知消息", "通知消息").anc("RoundedFrameLayout"),
        t("侧边栏", "常用功能", AUTO, true, "离线缓存", "离线缓存"),
        t("侧边栏", "常用功能", AUTO, true, "稍后再看", "稍后再看"),
        t("侧边栏", "常用功能", AUTO, true, "我的转化记录", "我的转化记录"),
        t("侧边栏", "常用功能", AUTO, true, "抖音创作者中心", "抖音创作者中心", "创作者中心"),
        t("侧边栏", "常用功能", AUTO, true, "直播广场", "直播广场"),
        t("侧边栏", "常用功能", AUTO, true, "放映厅", "放映厅"),
        t("侧边栏", "常用功能", AUTO, true, "附近团购", "附近团购"),
        t("侧边栏", "常用功能", AUTO, true, "我的二维码", "我的二维码"),

        t("商城", null, BOX, true, "商城：充值中心", "充值中心").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：购物消息", "购物消息").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：券红包", "券红包", "劵红包").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：评价中心", "评价中心").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：订单报销", "订单报销").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：天天抽券", "天天抽券").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：省钱严选", "省钱严选").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：小时达", "小时达").box(0.3f, 0.15f),
        t("商城", null, BOX, true, "商城：全球购", "全球购").box(0.3f, 0.15f),
        cat("直播精选"), cat("新品"), cat("关注"), cat("数码办公"), cat("食品饮料"), cat("玩乐"), cat("农资机电"),
        cat("运动"), cat("车品"), cat("百货"), cat("图书"), cat("男装"), cat("洗护"), cat("箱包"), cat("生鲜"),
        cat("配饰"), cat("鞋靴"), cat("家具家装"), cat("珠宝文玩"), cat("女装"), cat("母婴"), cat("美妆护肤"),
        cat("家电"), cat("鲜花绿植"), cat("内衣"), cat("奢品"), cat("医疗保健"), cat("玩具乐器"), cat("二手"),

        // 直播间（只在直播间窗口里生效；文字是按常见叫法写的，没有直播间的控件树可对照）
        t("直播间", null, AUTO, false, "直播间：榜单（热度、小时榜、人气榜）", "热度榜", "小时榜", "人气榜", "主播榜").live(),
        t("直播间", null, AUTO, false, "直播间：人气开场", "人气开场").live(),
        t("直播间", null, AUTO, false, "直播间：全新主粉装扮", "主粉装扮").live(),
        t("直播间", null, AUTO, false, "直播间：看直播抽套装", "抽套装").live(),
        t("直播间", null, AUTO, false, "直播间：基础展馆", "基础展馆").live(),
        t("直播间", null, AUTO, true, "直播间：右下角广告", "广告").live(),
        t("直播间", null, AUTO, true, "直播间：底部游戏按钮", "游戏").live(),
        t("直播间", null, AUTO, false, "直播间：欢迎来到直播间提示", "^欢迎来到直播间").live(),
    };

    static final boolean NEED_ID;

    static {
        boolean need = false;
        for (R r : ALL) for (String s : r.sel) need |= s.charAt(0) == '#';
        NEED_ID = need;
    }

    static String idName(View v) {
        if (v.getId() == View.NO_ID) return null;
        try {
            return v.getResources().getResourceEntryName(v.getId());
        } catch (Resources.NotFoundException e) {
            return null;
        }
    }
}
