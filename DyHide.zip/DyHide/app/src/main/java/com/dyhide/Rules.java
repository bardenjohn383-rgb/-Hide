package com.dyhide;

import android.content.res.Resources;
import android.view.View;

/** 隐藏规则：按文字/描述、类名结尾、资源ID名匹配（ID名随抖音版本变化，这套规则对应 41.0.0）。 */
final class Rules {
    /** AUTO：自动向上找到整个入口；TEXT_ONLY：只隐藏匹配到的这个控件；UP：隐藏类名以 anc 结尾的最近祖先（整张卡片/整行）；CLEAR：不隐藏，只清掉背景（变透明）；DISMISS：命中后直接关掉所在的弹窗；CARD：隐藏整张卡片（找不到卡片容器时退回 AUTO）。 */
    static final int AUTO = 0, TEXT_ONLY = 1, UP = 2, CLEAR = 3, DISMISS = 4, CARD = 5;

    static final class R {
        final String group, sub, label;
        final int mode;
        final boolean exact, overlayOnly;
        final String[] sel, pats;   // sel：类名结尾，或 "#"+资源ID名；pats：文字/描述；sel 和 pats 同时给出时两者都要满足
        String anc, veto, need;     // anc：UP 模式的祖先（类名结尾，或 "#"+资源ID名）；veto：位于此类名的祖先内时不隐藏；need：必须位于此类名的祖先内
        String[] skip;              // 控件描述以其中任一前缀开头时不匹配（用来把“拍同款”“游戏”等同类入口排除掉）

        R(String group, String sub, int mode, boolean exact, boolean overlayOnly, String label, String[] sel, String[] pats) {
            this.group = group; this.sub = sub; this.mode = mode; this.exact = exact;
            this.overlayOnly = overlayOnly; this.label = label; this.sel = sel; this.pats = pats;
        }

        String key() { return "r_" + label; }

        R anc(String s) { anc = s; return this; }

        R veto(String s) { veto = s; return this; }

        R need(String s) { need = s; return this; }

        R skip(String... prefixes) { skip = prefixes; return this; }

        boolean matchView(View v, String cls, String id, CharSequence t, CharSequence d) {
            boolean bySel = sel.length == 0;
            for (String s : sel) {
                if (s.charAt(0) == '#' ? s.substring(1).equals(id) : cls.endsWith(s)) bySel = true;
            }
            if (bySel && skip != null && d != null) {
                for (String k : skip) if (d.toString().startsWith(k)) return false;
            }
            return bySel && (pats.length == 0 || match(t) || match(d));
        }

        private boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            for (String p : pats) {
                if (exact ? t.equals(p) : p.charAt(0) == '^' ? t.startsWith(p.substring(1)) : t.contains(p)) return true;
            }
            return false;
        }
    }

    private static R t(String g, String sub, int mode, boolean exact, String label, String... p) {
        return new R(g, sub, mode, exact, false, label, new String[0], p);
    }

    private static R o(String g, String label, String... p) {
        return new R(g, null, AUTO, true, true, label, new String[0], p);
    }

    private static R s(String g, int mode, String label, String... sel) {
        return new R(g, null, mode, false, false, label, sel, new String[0]);
    }

    private static R sp(String g, int mode, String label, String sel, String pat) {
        return new R(g, null, mode, false, false, label, new String[]{sel}, new String[]{pat});
    }

    /** 商城顶部的商品分类标签（Slc 列表里的一项）：必须位于 SlcItemView 内，避免误伤全局的“关注”“运动”等文字。 */
    private static R cat(String name) {
        return new R("商城", "商品分类（可一键隐藏）", UP, true, false, "商城分类：" + name, new String[0], new String[]{name})
                .anc("SlcItemView").need("SlcItemView");
    }

    static final R[] ALL = {
        t("首页", null, AUTO, false, "拍同款", "拍同款"),
        s("首页", TEXT_ONLY, "右下角唱片", "MusicCoverContainerLayout", "#sz9"),
        t("首页", null, AUTO, true, "顶部：经验", "经验"),
        t("首页", null, AUTO, true, "顶部：热点", "热点"),
        t("首页", null, AUTO, true, "顶部：精选", "精选"),
        t("首页", null, AUTO, true, "顶部：同城", "同城"),
        t("首页", null, AUTO, true, "顶部：直播", "直播"),
        t("首页", null, AUTO, true, "顶部：团购", "团购"),
        t("首页", null, AUTO, false, "作者声明", "作者声明"),
        t("首页", null, AUTO, false, "视频章节要点", "章节要点"),
        sp("首页", UP, "视频底部搜索栏", "#title", "相关搜索").anc("#container").need("MeasureOnceFrameLayout"),
        t("首页", null, AUTO, false, "视频相关搜索", "相关搜索"),
        s("首页", AUTO, "视频声明警示", "FeedWarnForceCenterTextView"),
        sp("首页", AUTO, "视频游戏标签", "RoundedLinearLayout", "^游戏").need("FpsControlFrameLayout"),
        s("首页", UP, "视频位置", "#qon").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").skip("拍同款", "游戏"),
        t("首页", null, UP, true, "视频底部广告", "立即下载").anc("MeasureOnceFrameLayout"),
        s("首页", CLEAR, "视频下方合集条背景全透明", "PlayletBottomConstraintLayout", "#fiw"),
        t("首页", null, CARD, false, "视频底部分享给好友", "^分享给").veto("IMShareTopAreaView"),
        s("首页", TEXT_ONLY, "视频标题/话题（整段文案）", "ScrollMentionTextView"),

        t("评论区", null, AUTO, false, "大家都在搜", "大家都在搜"),
        t("评论区", null, AUTO, false, "AI解析", "AI解析", "AI 解析"),
        t("评论区", null, AUTO, true, "评论回复", "回复"),
        t("评论区", null, UP, false, "观看完整合集", "观看完整合集").anc("LinearLayout"),
        t("评论区", null, AUTO, false, "玩家讨论", "玩家讨论"),
        t("评论区", null, AUTO, false, "地点评价", "地点评价"),
        t("评论区", null, AUTO, false, "游戏标签（评论区）", "游戏标签"),

        t("推荐", null, DISMISS, true, "点击推荐后的弹层（你推荐了视频）", "你推荐了视频"),
        t("推荐", null, UP, true, "取消推荐的提示（已取消推荐）", "已取消推荐").anc("#rl_rootview"),

        o("分享面板", "转发到日常", "转发到日常"),
        o("分享面板", "推荐", "推荐").veto("LongPressPanelCommonItemView"),
        o("分享面板", "私信", "私信"),
        o("分享面板", "建群分享", "建群分享"),
        o("分享面板", "帮上热门", "帮上热门"),
        o("分享面板", "身边的人", "身边的人"),
        o("分享面板", "不感兴趣", "不感兴趣").veto("LongPressPanelCommonItemView"),
        o("分享面板", "合拍", "合拍"),
        o("分享面板", "一起看视频", "一起看视频"),
        o("分享面板", "加桌面伙伴", "加桌面伙伴"),

        o("长按菜单", "投屏", "投屏"),
        o("长按菜单", "识别图片", "识别图片"),
        o("长按菜单", "定时关闭", "定时关闭"),

        s("底栏", TEXT_ONLY, "我的页底部遮罩", "#5_6"),

        t("侧边栏", null, AUTO, true, "扫一扫", "扫一扫"),
        t("侧边栏", null, AUTO, true, "我的钱包", "我的钱包", "钱包"),
        t("侧边栏", null, AUTO, true, "券包", "券包"),
        t("侧边栏", null, UP, true, "通知消息", "通知消息").anc("RoundedFrameLayout"),
        t("侧边栏", "常用功能", AUTO, true, "离线缓存", "离线缓存"),
        t("侧边栏", "常用功能", AUTO, true, "稍后再看", "稍后再看"),
        t("侧边栏", "常用功能", AUTO, true, "我的转化记录", "我的转化记录"),
        t("侧边栏", "常用功能", AUTO, true, "抖音创作者中心", "抖音创作者中心", "创作者中心"),
        t("侧边栏", "常用功能", AUTO, true, "直播广场", "直播广场"),
        t("侧边栏", "常用功能", AUTO, true, "放映厅", "放映厅"),
        t("侧边栏", "常用功能", AUTO, true, "附近团购", "附近团购"),
        t("侧边栏", "常用功能", AUTO, true, "我的二维码", "我的二维码"),

        t("商城", null, AUTO, true, "商城：充值中心", "充值中心"),
        t("商城", null, AUTO, true, "商城：券红包", "券红包", "劵红包"),
        t("商城", null, AUTO, true, "商城：订单报销", "订单报销"),
        t("商城", null, AUTO, true, "商城：天天抽券", "天天抽券"),
        t("商城", null, AUTO, true, "商城：省钱严选", "省钱严选"),
        t("商城", null, AUTO, true, "商城：小时达", "小时达"),
        t("商城", null, AUTO, true, "商城：全球购", "全球购"),
        t("商城", null, AUTO, true, "商城：关注店铺", "关注店铺"),
        t("商城", null, AUTO, true, "商城：附近美食", "附近美食"),
        t("商城", null, AUTO, true, "商城：品牌会员", "品牌会员"),
        t("商城", null, AUTO, true, "商城：赚积分", "赚积分"),
        t("商城", null, AUTO, false, "商城：资质规则", "资质规则"),
        cat("直播精选"), cat("新品"), cat("关注"), cat("数码办公"), cat("食品饮料"), cat("玩乐"), cat("农资机电"),
        cat("运动"), cat("车品"), cat("百货"), cat("图书"), cat("男装"), cat("洗护"), cat("箱包"), cat("生鲜"),
        cat("配饰"), cat("鞋靴"), cat("家具家装"), cat("珠宝文玩"), cat("女装"), cat("母婴"), cat("美妆护肤"),
        cat("家电"), cat("鲜花绿植"), cat("内衣"), cat("奢品"), cat("医疗保健"), cat("玩具乐器"), cat("二手"),
    };

    static final boolean NEED_ID;

    static {
        boolean need = false;
        for (R r : ALL) for (String s : r.sel) need |= s.charAt(0) == '#';
        NEED_ID = need;
    }

    static String idName(View v) {
        if (v.getId() == View.NO_ID) return null;
        try {
            return v.getResources().getResourceEntryName(v.getId());
        } catch (Resources.NotFoundException e) {
            return null;
        }
    }
}
