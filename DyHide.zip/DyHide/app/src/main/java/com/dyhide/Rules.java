package com.dyhide;

/** 隐藏规则：按 TextView 文字 / contentDescription 匹配（抖音资源ID被混淆，不依赖ID）。 */
final class Rules {
    /** AUTO：自动向上找到整个入口（网格单元/列表项/标签项）；TEXT_ONLY：只隐藏这段文字；BLOCK：隐藏整块卡片。 */
    static final int AUTO = 0, TEXT_ONLY = 1, BLOCK = 2;

    static final class R {
        final String group, sub, label, cls;
        final int mode;
        final boolean exact;
        final String[] pats;

        R(String group, String sub, int mode, boolean exact, String label, String cls, String[] pats) {
            this.cls = cls;
            this.group = group; this.sub = sub; this.mode = mode;
            this.exact = exact; this.label = label; this.pats = pats;
        }

        String key() { return "r_" + label; }

        /** cls 规则按控件类名匹配（不看文字长度）；其余按文字/描述匹配。 */
        boolean matchView(android.view.View v, CharSequence t, CharSequence d) {
            if (cls != null) return v.getClass().getName().endsWith(cls);
            return match(t) || match(d);
        }

        boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            for (String p : pats) {
                if (exact ? t.equals(p) : t.contains(p)) return true;
            }
            return false;
        }
    }

    private static R r(String g, String sub, int mode, boolean exact, String label, String... p) {
        return new R(g, sub, mode, exact, label, null, p);
    }

    private static R rc(String g, int mode, String label, String cls) {
        return new R(g, null, mode, false, label, cls, new String[0]);
    }

    static final R[] ALL = {
        r("首页", null, 0, false, "拍同款", "拍同款"),
        r("首页", null, 0, true, "顶部：经验", "经验"),
        r("首页", null, 0, true, "顶部：热点", "热点"),
        r("首页", null, 0, true, "顶部：精选", "精选"),
        r("首页", null, 0, true, "顶部：同城", "同城"),
        r("首页", null, 0, true, "顶部：直播", "直播"),
        r("首页", null, 0, false, "作者声明", "作者声明"),
        rc("首页", 1, "视频标题/话题（整段文案）", "ScrollMentionTextView"),

        r("评论区", null, 0, false, "大家都在搜", "大家都在搜"),
        r("评论区", null, 0, false, "AI解析", "AI解析", "AI 解析"),

        r("侧边栏", null, 0, true, "扫一扫", "扫一扫"),
        r("侧边栏", null, 0, true, "我的钱包", "我的钱包", "钱包"),
        r("侧边栏", null, 0, true, "券包", "券包"),
        r("侧边栏", null, 1, true, "通知消息", "通知消息"),
        r("侧边栏", "常用功能", 0, true, "离线缓存", "离线缓存"),
        r("侧边栏", "常用功能", 0, true, "稍后再看", "稍后再看"),
        r("侧边栏", "常用功能", 0, true, "我的转化记录", "我的转化记录"),
        r("侧边栏", "常用功能", 0, true, "抖音创作者中心", "抖音创作者中心", "创作者中心"),
        r("侧边栏", "常用功能", 0, true, "直播广场", "直播广场"),
        r("侧边栏", "常用功能", 0, true, "附近团购", "附近团购"),
        r("侧边栏", "常用功能", 0, true, "我的二维码", "我的二维码"),

        r("我的页", null, 2, false, "一起参与话题", "一起参与话题"),
    };
}
