package com.dyhide;

import android.content.res.Resources;
import android.view.View;
import android.widget.TextView;
import android.view.ViewGroup;

/** 隐藏规则：按文字/描述、类名结尾、资源ID名匹配（ID名随抖音版本变化，这套规则对应 41.0.0）。 */
final class Rules {
    /** AUTO：自动向上找到整个入口；TEXT_ONLY：只隐藏匹配到的这个控件；UP：隐藏类名以 anc 结尾的最近祖先（整张卡片/整行）；CLEAR：不隐藏，只清掉背景（变透明）；DISMISS：命中后直接关掉所在的弹窗；CARD：隐藏整张卡片（找不到卡片容器时退回 AUTO）；CHILD：隐藏 anc 祖先下、包着匹配控件的那一个直接子项（整条栏里只收掉其中一种内容）；ROOT：隐藏匹配控件所在的整个窗口（Toast、弹出提示）；PARENT：隐藏 anc 祖先的父容器；BOX：从命中的控件往上找，取宽、高都不超过 box(w, h)（占屏幕的比例）的最大祖先——用来整块隐藏卡片、图标格子。 */
    static final int AUTO = 0, TEXT_ONLY = 1, UP = 2, CLEAR = 3, DISMISS = 4, CARD = 5, CHILD = 6, ROOT = 7, PARENT = 8, BOX = 9, CLEARUP = 10;

    static final class R {
        final String group, sub, label;
        final int mode;
        final boolean exact, overlayOnly;
        final String[] sel, pats;   // sel：类名结尾，或 "#"+资源ID名；pats：文字/描述；sel 和 pats 同时给出时两者都要满足
        int depth = 6;              // 查找祖先（anc / need）最多向上几层
        String anc, veto, need;     // anc：UP 模式的祖先（类名结尾，或 "#"+资源ID名）；veto：位于此类名的祖先内时不隐藏；need：必须位于此类名的祖先内
        String[] not;               // 文字等于其中任一项时不匹配（给“其余都算”的规则排除已有单独开关的项）
        java.util.function.Predicate<View> altPred;   // 另一条触发路径（按结构判断，不看文字）
        String altNeed;             // altUp 的前提：命中控件必须位于这个类名的祖先里（最多 10 层）
        String altAnc;              // 靠 or(...) 的文字命中时，改为隐藏这个类名的最近祖先（并且不要求 need）
        float bw = 1f, bh = 1f;     // BOX 模式的宽、高上限（占屏幕宽、高的比例）
        boolean closes, live, skipMine;   // skipMine：标签里出现“我的昵称”（设置页里填的）时不隐藏，只隐藏别人的       // closes：命中的控件在对话框里时，直接关掉这个对话框；live：只在直播间窗口里生效
        String[] alt;               // 另一条触发路径：文字/描述包含其中任一项就直接命中（不要求满足 sel），climb 和 anc/need/veto 规则相同
        String[] skip;              // 控件描述以其中任一前缀开头时不匹配（用来把“拍同款”“游戏”等同类入口排除掉）

        R(String group, String sub, int mode, boolean exact, boolean overlayOnly, String label, String[] sel, String[] pats) {
            this.group = group; this.sub = sub; this.mode = mode; this.exact = exact;
            this.overlayOnly = overlayOnly; this.label = label; this.sel = sel; this.pats = pats;
        }

        String key() { return "r_" + label; }

        /** 设置页里显示的名字：去掉“商城分类：”这类前缀，只留分类本身。 */
        String shown() { return label.startsWith("商城分类：") ? label.substring(5) : label; }

        R anc(String s) { anc = s; return this; }

        R veto(String s) { veto = s; return this; }

        R need(String s) { need = s; return this; }

        R deep() { depth = 8; return this; }

        R skip(String... prefixes) { skip = prefixes; return this; }

        R or(String... p) { alt = p; return this; }

        R closes() { closes = true; return this; }

        R live() { live = true; return this; }

        R skipMine() { skipMine = true; return this; }

        R except(String... n) { not = n; return this; }

        R orIf(java.util.function.Predicate<View> p) {
            altPred = p;
            return this;
        }

        R altUp(String anc, String need) {
            altAnc = anc;
            altNeed = need;
            return this;
        }

        R box(float w, float h) { bw = w; bh = h; return this; }

        /** 文字是否命中本规则的文字模式（拦截提示窗口用）。 */
        boolean textHit(CharSequence t) { return match(t); }

        private boolean hitAlt(CharSequence s) {
            if (alt == null || s == null || s.length() == 0 || s.length() > 60) return false;
            for (String p : alt) if (p.charAt(0) == '=' ? s.toString().trim().equals(p.substring(1)) : s.toString().contains(p)) return true;
            return false;
        }

        /** 是不是靠 or(...) 的文字命中的（而不是靠 sel）。 */
        boolean viaAlt(View v, CharSequence t, CharSequence d) { return hitAlt(t) || hitAlt(d) || (altPred != null && altPred.test(v)); }

        boolean matchView(View v, String cls, String id, CharSequence t, CharSequence d) {
            return viaAlt(v, t, d) || matchSel(v, cls, id, t, d);
        }

        /** 按 sel / 文字模式命中（不含 or(...) 那条路径）。 */
        boolean matchSel(View v, String cls, String id, CharSequence t, CharSequence d) {
            boolean bySel = sel.length == 0;
            for (String s : sel) {
                if (s.charAt(0) == '#' ? s.substring(1).equals(id) : cls.endsWith(s)) bySel = true;
            }
            if (bySel && skip != null && d != null) {
                for (String k : skip) if (d.toString().startsWith(k)) return false;
            }
            return bySel && (pats.length == 0 || match(t) || match(d));
        }

        private boolean match(CharSequence s) {
            if (s == null || s.length() == 0 || s.length() > 60) return false;
            String t = s.toString().trim();
            if (not != null) for (String n : not) if (t.equals(n)) return false;
            for (String p : pats) {
                if (exact ? t.equals(p) : p.charAt(0) == '^' ? t.startsWith(p.substring(1)) : p.charAt(0) == '$' ? t.endsWith(p.substring(1)) : t.contains(p)) return true;
            }
            return false;
        }
    }

    /** 分享面板里的一个入口：往上取宽不超过 30% 屏宽、高不超过 20% 屏高的最大祖先，也就是图标 + 文字的整个格子（整行太宽，不会被取到）。 */
    private static R ob(String label, String text) {
        return new R("分享面板", null, BOX, true, true, label, new String[0], new String[]{text}).box(0.3f, 0.2f);
    }

    private static R t(String g, String sub, int mode, boolean exact, String label, String... p) {
        return new R(g, sub, mode, exact, false, label, new String[0], p);
    }

    private static R o(String g, String label, String... p) {
        return new R(g, null, AUTO, true, true, label, new String[0], p);
    }

    private static R s(String g, int mode, String label, String... sel) {
        return new R(g, null, mode, false, false, label, sel, new String[0]);
    }

    private static R sp(String g, int mode, String label, String sel, String pat) {
        return new R(g, null, mode, false, false, label, new String[]{sel}, new String[]{pat});
    }

    /** 商城顶部的商品分类标签（Slc 列表里的一项）：必须位于 SlcItemView 内，避免误伤全局的“关注”“运动”等文字。 */
    private static R cat(String name) {
        return new R("商城", "商品分类", UP, true, false, "商城分类：" + name, new String[0], new String[]{name})
                .anc("SlcItemView").need("SlcItemView");
    }

    /** 搜索页榜单标签条里的一个标签（整个标签隐藏）。 */
    private static R rank(String name) {
        return t("搜索页", "榜单（可一键隐藏）", UP, true, "搜索榜：" + name, name).anc("TabView").need("TabView");
    }

    /**
     * 评论区上方的“地点卡片”里的第一段文字（如“陇南市”）：它所在的这一行里，紧跟着是一条很窄的竖线，后面才是地点名。
     * 竖线有两种：一条普通 View（宽 4px 左右），或者一个写着“|”“·”的文字。
     * 不再限定外层必须是 ConstraintLayout（抖音换过容器），只要结构是“文字 + 竖线 + 文字”就算。
     * 购物、游戏卡片的结构一样，只是第一段文字分别是“购物”“游戏”，这里排除掉，交给各自的开关。
     */
    static boolean poiCardText(View v) {
        if (!(v instanceof TextView)) return false;
        CharSequence t = ((TextView) v).getText();
        if (t == null || t.length() == 0 || t.length() > 24) return false;
        String x = t.toString().trim();
        if (x.isEmpty() || x.startsWith("购物") || x.startsWith("游戏")) return false;
        if (!(v.getParent() instanceof ViewGroup)) return false;
        ViewGroup p = (ViewGroup) v.getParent();
        if (p.getChildAt(0) != v || p.getChildCount() < 2) return false;
        int w = v.getResources().getDisplayMetrics().widthPixels;
        for (int i = 1; i < p.getChildCount(); i++) {
            View c = p.getChildAt(i);
            if (c instanceof TextView) {
                CharSequence ct = ((TextView) c).getText();
                if (ct != null) {
                    String s = ct.toString().trim();
                    if (s.equals("|") || s.equals("｜") || s.equals("·")) return true;
                }
                continue;
            }
            if (c.getClass().getName().equals("android.view.View") && c.getWidth() > 0 && c.getWidth() <= Math.max(4, w / 100)) return true;
        }
        return false;
    }

    static final R[] ALL = {
        t("首页", null, AUTO, false, "拍同款", "拍同款", "玩同款"),
        s("首页", TEXT_ONLY, "右下角唱片", "MusicCoverContainerLayout", "#sz9"),
        t("首页", null, TEXT_ONLY, true, "顶部：推荐右边的“>”（返回推荐页）", "返回推荐页"),
        s("首页", TEXT_ONLY, "视频上方话题", "HashTagInteractStickerViewNew"),   // 视频上层的话题贴纸，点它会跳到搜索该话题
        t("首页", null, UP, true, "视频底部热点标签", "热点").anc("MeasureOnceRelativeLayout2").need("MeasureOnceRelativeLayout2"),   // 整条“热点：xxx  N万人在看”栏
        t("首页", null, UP, false, "视频底部上升热点", "上升热点").anc("MeasureOnceRelativeLayout2").need("MeasureOnceRelativeLayout2"),   // 整条“上升热点：xxx  N万人在看”栏（同样的容器，只是标题换成“上升热点”）
        sp("首页", TEXT_ONLY, "视频右下方听抖音", "ConstraintLayout", "听抖音"),   // 右侧按钮栏下方“听抖音”入口（描述就是“听抖音”的那个 ConstraintLayout，连图标一起收）
        t("首页", null, UP, false, "视频底部热榜", "^热榜").anc("MeasureOnceRelativeLayout2").need("MeasureOnceRelativeLayout2"),   // 整条“热榜TOP18：xxx  N万人在看”栏（同样的容器，标题是“热榜TOP N”）
        sp("首页", TEXT_ONLY, "顶部：经验", "HomeTopTabItemViewNew", "经验，按钮"),   // 按标签项自己的描述匹配（关注页上偶尔出现的“直播”小标不会误伤关注页）
        sp("首页", TEXT_ONLY, "顶部：热点", "HomeTopTabItemViewNew", "热点，按钮"),
        sp("首页", TEXT_ONLY, "顶部：精选", "HomeTopTabItemViewNew", "精选，按钮"),
        sp("首页", TEXT_ONLY, "顶部：同城", "HomeTopTabItemViewNew", "同城，按钮"),
        sp("首页", TEXT_ONLY, "顶部：直播", "HomeTopTabItemViewNew", "直播，按钮"),
        sp("首页", TEXT_ONLY, "顶部：团购", "HomeTopTabItemViewNew", "团购，按钮"),
        t("首页", null, AUTO, false, "作者声明", "作者声明"),
        t("首页", null, AUTO, false, "视频章节要点", "章节要点"),
        sp("首页", UP, "视频底部搜索栏", "#title", "相关搜索").anc("#container").need("MeasureOnceFrameLayout"),
        t("首页", null, AUTO, false, "视频相关搜索", "相关搜索"),
        s("首页", AUTO, "视频声明警示", "FeedWarnForceCenterTextView"),
        sp("首页", AUTO, "视频游戏标签", "RoundedLinearLayout", "^游戏").need("FpsControlFrameLayout").or("=游戏").altUp("FrameLayout", "CommentNestedLayout"),   // 评论区上方的游戏卡片（文字“游戏”）一起隐藏
        t("首页", null, PARENT, true, "视频底部去汽水听卡片", "汽水音乐按钮").anc("FeedBottomMusicAnchorLayout"),   // 整条音乐信息行（徽标 + 音乐名）；按类名定位，不依赖会随版本变的混淆 id
        t("首页", null, UP, false, "视频底部汽水音乐标签", "^汽水音乐", "^听完整版").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").deep(),   // 两种样式：“汽水音乐听完整版《xx》”和“汽水音乐 + 一句宣传语”
        t("首页", null, UP, false, "视频底部购物", "^购物").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").deep()
                .or("=购物").altUp("FrameLayout", "CommentNestedLayout"),   // 视频底部的购物标签，和评论区上方的购物卡片一起
        t("首页", null, UP, false, "视频底部剪映标签", "^剪映").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").deep(),
        s("首页", UP, "视频地点", "RoundedLinearLayout").anc("FpsControlFrameLayout").need("FpsControlFrameLayout").skip("拍同款", "游戏", "汽水音乐", "购物", "剪映").or("人打卡", "人去过", "人想去", "人收藏").orIf(Rules::poiCardText).altUp("@poi", "CommentNestedLayout"),   // 评论区上方的地点卡片一起隐藏（有“xx万人打卡”的，和只有“城市 | 地点名”的两种）
        //   // 按类名匹配标签（原来用的 #qon 会随抖音版本变）
        s("首页", CHILD, "视频底部广告", "#tv_description").anc("MeasureOnceFrameLayout").need("MeasureOnceFrameLayout"),
        s("首页", CLEAR, "视频下方合集条背景全透明", "PlayletBottomConstraintLayout", "#fiw").or("=合集").altUp("MeasureOnceFrameLayout", "MeasureOnceFrameLayout"),   // 所有样式的合集条：文字“合集”所在的整条栏里，所有整宽的背景层一起清掉
        t("首页", null, UP, true, "刷到好友分享的视频提示", "分享给你").anc("TagLayout").need("TagLayout"),
        s("首页", UP, "好友推荐过的视频", "FamiliarRecommendTagViewV2").anc("TagLayout").skipMine(),   // “坤 推荐” + “推荐给朋友”图标那条标签   // 头像 + 名字 + “分享给你”整条标签
        t("首页", null, CARD, false, "视频底部分享给好友", "^分享给").veto("IMShareTopAreaView"),
        t("首页", null, UP, false, "视频底部点击推荐", "点击推荐按钮", "人推荐按钮").anc("TagLayout").need("TagLayout").or("人推荐").closes(),   // “点击推荐 / 共N人推荐”整个标签；“你推荐了视频”弹层里出现同样文字就关掉弹层
        s("首页", TEXT_ONLY, "视频标题/话题（整段文案）", "ScrollMentionTextView"),

        s("评论区", UP, "大家都在搜", "CommentRelatedView").anc("FrameLayout"),   // 整行：“大家都在搜：”加上后面蓝色的搜索词
        t("评论区", null, AUTO, false, "AI解析", "AI解析", "AI 解析"),
        t("评论区", null, UP, false, "观看完整合集", "观看完整合集").anc("LinearLayout"),
        t("评论区", null, AUTO, false, "玩家讨论", "玩家讨论"),
        t("评论区", null, AUTO, false, "商品评价", "商品评价"),
        t("评论区", null, AUTO, false, "门店评价", "门店评价"),   // 评论区顶部的“门店评价 N”标签   // 评论区顶部的“商品评价 N”标签
        t("评论区", null, AUTO, false, "地点评价", "地点评价"),
        t("评论区", null, AUTO, false, "游戏标签（评论区）", "游戏标签"),


        t("搜索页", null, BOX, false, "猜你想搜", "猜你想搜").box(1f, 0.6f),   // 区块本身没有可识别的文字节点，实际隐藏由 MainHook.clipGuess 按“历史记录”条目的位置裁掉下面一半
        s("搜索页", TEXT_ONLY, "右下角语音键", "VoiceSearchOverlayEntranceView"),
        s("搜索页", TEXT_ONLY, "搜索榜单里的排行榜内容", "SearchMiddleTabKeepAliveViewPager"),   // 标签条下面整个榜单列表（含置顶那条），不再一条条匹配
        rank("抖音热榜"), rank("直播榜"), rank("团购榜"), rank("品牌榜"), rank("音乐榜"), rank("游戏榜"), rank("种草榜"), rank("影视榜"), rank("短剧榜"), rank("趋势榜"),
        t("搜索页", "榜单（可一键隐藏）", UP, false, "搜索榜：地区榜（所在城市）", "$榜").anc("TabView").need("TabView")
                .except("抖音热榜", "直播榜", "团购榜", "品牌榜", "音乐榜", "游戏榜", "种草榜", "影视榜", "短剧榜", "趋势榜"),

        s("主页", PARENT, "参与话题", "CustomComposeView").anc("ProfileBubbleLayout"),   // 主页那张 Compose 画的卡片：CustomComposeView → ProfileBubbleLayout，连外层容器一起收，不留空位

        t("主页", null, AUTO, false, "侧边栏：未成年人保护", "未成年人保护"),

        t("提示", null, ROOT, true, "提示：收藏成功", "收藏成功"),   // 整个提示窗口（含“去看看”），不只是文字
        t("提示", null, ROOT, true, "提示：已取消推荐", "已取消推荐"),
        t("提示", null, ROOT, true, "提示：已取消收藏", "已取消收藏"),

        t("分享面板", null, TEXT_ONLY, false, "建群并发送", "建群并发送"),   // 底部「建群并发送 / 分别发送」里的建群按钮
        ob("转发到日常", "转发到日常"),
        ob("推荐", "推荐").veto("LongPressPanelCommonItemView"),
        ob("私信", "私信"),
        ob("建群分享", "建群分享"),
        ob("帮上热门", "帮上热门"),
        ob("身边的人", "身边的人"),
        ob("不感兴趣", "不感兴趣").veto("LongPressPanelCommonItemView"),
        ob("合拍", "合拍"),
        ob("一起看视频", "一起看视频"),
        ob("加桌面伙伴", "加桌面伙伴"),

        o("长按菜单", "投屏", "投屏"),
        o("长按菜单", "识别图片", "识别图片"),
        o("长按菜单", "定时关闭", "定时关闭"),
        t("长按菜单", null, UP, true, "电脑/Pad打开", "电脑/Pad打开").anc("LongPressPanelCommonItemView"),   // 整张功能卡片（图标 + 文字）


        t("侧边栏", null, AUTO, true, "扫一扫", "扫一扫"),
        t("侧边栏", null, AUTO, true, "我的钱包", "我的钱包", "钱包"),
        t("侧边栏", null, AUTO, true, "券包", "券包"),
        t("侧边栏", null, UP, true, "通知消息", "通知消息").anc("RoundedFrameLayout"),
        t("侧边栏", "常用功能", AUTO, true, "离线缓存", "离线缓存"),
        t("侧边栏", "常用功能", AUTO, true, "稍后再看", "稍后再看"),
        t("侧边栏", "常用功能", AUTO, true, "我的转化记录", "我的转化记录"),
        t("侧边栏", "常用功能", AUTO, true, "抖音创作者中心", "抖音创作者中心", "创作者中心"),
        t("侧边栏", "常用功能", AUTO, true, "直播广场", "直播广场"),
        t("侧边栏", "常用功能", AUTO, true, "放映厅", "放映厅"),
        t("侧边栏", "常用功能", AUTO, true, "附近团购", "附近团购"),
        t("侧边栏", "常用功能", AUTO, true, "我的二维码", "我的二维码"),

        cat("直播精选"), cat("新品"), cat("关注"), cat("数码办公"), cat("食品饮料"), cat("玩乐"), cat("农资机电"),
        cat("运动"), cat("车品"), cat("百货"), cat("图书"), cat("男装"), cat("洗护"), cat("箱包"), cat("生鲜"),
        cat("配饰"), cat("鞋靴"), cat("家具家装"), cat("珠宝文玩"), cat("女装"), cat("母婴"), cat("美妆护肤"),
        cat("家电"), cat("鲜花绿植"), cat("内衣"), cat("奢品"), cat("医疗保健"), cat("玩具乐器"), cat("二手"),

    };

    static final boolean NEED_ID;

    static {
        boolean need = false;
        for (R r : ALL) for (String s : r.sel) need |= s.charAt(0) == '#';
        NEED_ID = need;
    }

    static String idName(View v) {
        if (v.getId() == View.NO_ID) return null;
        try {
            return v.getResources().getResourceEntryName(v.getId());
        } catch (Resources.NotFoundException e) {
            return null;
        }
    }
}
