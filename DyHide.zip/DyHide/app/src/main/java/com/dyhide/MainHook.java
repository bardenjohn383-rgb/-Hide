package com.dyhide;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Toast;
import android.widget.PopupWindow;
import android.view.Window;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.text.SpannableStringBuilder;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.util.TypedValue;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TARGET = "com.ss.android.ugc.aweme";
    static final String MODULE = "com.dyhide";
    static Handler H;
    static final Map<View, Boolean> PENDING = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, WeakReference<View>> HIDDEN = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<View>>());
    static final Map<View, Long> LAST_DUMP = new WeakHashMap<>();
    static final Map<View, Boolean> ATTACHED = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, String> GRID_SIG = new WeakHashMap<>();
    static final Map<View, Object[]> ORIG_SPECS = new WeakHashMap<>();
    static final Map<View, Boolean> CENTERED = new WeakHashMap<>();
    static final Map<View, Integer> SPACE = Collections.synchronizedMap(new WeakHashMap<View, Integer>());
    static final Map<View, Boolean> MAIN = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, Drawable> BG_ORIG = new WeakHashMap<>();
    static final Map<View, int[]> SIZE = new WeakHashMap<>();
    static final Map<View, Integer> NAV_BG = Collections.synchronizedMap(new WeakHashMap<View, Integer>());       // 底栏背景图/分割线 -> 原可见性
    static final Map<View, Drawable> NAV_PAR = Collections.synchronizedMap(new WeakHashMap<View, Drawable>());   // 底栏容器 -> 原背景
    static final Map<View, Boolean> PENDANT = new WeakHashMap<>();
    static final Map<View, Boolean> PENDANTS = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, Integer> PENDANT_VIS = new WeakHashMap<>(); // 仅倍速期间保存抖音请求的可见性
    static final Map<View, Boolean> SPEED_GUIDES = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static boolean speedPendantHidden;   // 仅在抖音实际显示倍速提示时隐藏红包挂件
    static boolean settingPendantVisibility; // 区分模块隐藏操作与抖音主动设置的可见性
    static final Map<View, long[]> ANIM = new WeakHashMap<>();       // 红包挂件 -> {统计窗口起点, 这段时间里被设了几次平移}
    static final Map<View, WeakReference<Dialog>> DIALOG = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<Dialog>>());   // 弹窗根视图 -> 弹窗（命中 DISMISS 规则时用来关掉它）
    static final Map<View, float[]> PENDANT_POS = new WeakHashMap<>();   // 红包挂件按下前最后一次的屏幕内位置（左上角）；倍速结束后把它钉回去
    static final Map<TextView, CharSequence> TITLE_ORIG = new WeakHashMap<>();    // 标题被改写前的原文
    static final Map<TextView, String> TITLE_SHOWN = new WeakHashMap<>();         // 我们写进去的文字（用来判断抖音有没有换新文案）
    static final String SP = "[\\s\\u00A0\\u3000\\u2000-\\u200B\\u202F\\u205F\\uFEFF]";   // 各种空格：普通、不换行、全角、零宽
    static final java.util.regex.Pattern TAG = java.util.regex.Pattern.compile(SP + "*#[^\\s#@\\u00A0\\u3000]+");
    static final java.util.regex.Pattern MEN = java.util.regex.Pattern.compile(SP + "*@[^\\s#@\\u00A0\\u3000]+");
    static final java.util.regex.Pattern TAG_MEN = java.util.regex.Pattern.compile(SP + "*[#@][^\\s#@\\u00A0\\u3000]+");
    static final java.util.regex.Pattern GAP = java.util.regex.Pattern.compile(SP + "+(?=展开>?" + SP + "*$)");
    static final Map<View, Float> SHIFTED = new WeakHashMap<>();   // 已经被我们下移的控件 -> 下移量
    static final String TAG_KEY = "r_视频标签";
    static final String MEN_KEY = "r_视频@被提及的人";
    static boolean swiped;      // 本次触摸是不是滑动（位移超过阈值），点按不算
    static float downX, downY;
    static long swipeUntil;     // 滑动松手后 800ms 内不钉挂件位置
    static XSharedPreferences sp;
    /** 上一次扫描里“没命中任何规则”的控件及其（文字、描述、窗口类型）指纹；没变就不再逐条规则比对，滑动/切页时扫描快得多。 */
    static final Map<View, Integer> NOMATCH = new WeakHashMap<>();

    static int scans, matched, navFixed, gridFixed, centerFixed;
    static long lastStatus;
    static String lastRoot = "";

    static synchronized Handler handler() {
        if (H == null) H = new Handler(Looper.getMainLooper());
        return H;
    }

    static final class Ctx {
        int sw, sh;
        float density;
        boolean nav, center, extend, overlay, disc, live, fit, imm;
        final List<View> tabs = new ArrayList<>();   // 本次扫描遇到的顶部标签项（按出现顺序）
        int inLive;   // 当前正走在几层直播容器里面（直播内容里不动任何非直播规则，免得误隐藏画面造成黑屏）
        View root;
        float pendant = 1f;
        List<Rules.R> rules = new ArrayList<>();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (MODULE.equals(lp.packageName)) {   // 模块自己的界面：把“是否激活”钩成 true（需要在 LSPosed 的作用域里勾选本模块）
            XposedHelpers.findAndHookMethod("com.dyhide.MainActivity", lp.classLoader, "isModuleActive", XC_MethodReplacement.returnConstant(true));
            return;
        }
        if (!TARGET.equals(lp.packageName)) return;
        sp = new XSharedPreferences(MODULE, "config");
        XposedBridge.log("DyHide: loaded in " + lp.processName + " sdk=" + android.os.Build.VERSION.SDK_INT);
        Class<?> vri = XposedHelpers.findClass("android.view.ViewRootImpl", lp.classLoader);
        Set<XC_MethodHook.Unhook> u = XposedBridge.hookAllMethods(vri, "performTraversals", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                schedule((View) XposedHelpers.getObjectField(p.thisObject, "mView"));
            }
        });
        XposedBridge.log("DyHide: performTraversals hooks=" + u.size());
        // 以抖音真实的倍速提示视图作为状态源，不再猜测长按时长/触摸区域。
        // 收藏、点赞视频的触摸分发链不同，旧的 VideoPinchViewContainer 触摸监听可能收不到完整事件。
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Activity) p.thisObject).getWindow().getDecorView();
                MAIN.put(decor, true);   // Activity 自己的窗口；其余（对话框、弹出层）都算浮层
                attach(decor);
                // 回到前台时强制补一次扫描；视频 View 可能被抖音重置为原始裁切比例。
                schedule(decor);
                handler().postDelayed(() -> schedule(decor), 320);
            }
        });
        // 提示类窗口在显示之前就拦下：文字命中“整窗隐藏”规则的，干脆不显示，连一瞬间都不会闪
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Window w = ((Dialog) p.thisObject).getWindow();
                if (w != null && blocked(w.getDecorView())) p.setResult(null);
            }
        });
        XC_MethodHook popup = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                View cv = ((PopupWindow) p.thisObject).getContentView();
                if (cv != null && blocked(cv)) p.setResult(null);
            }
        };
        XposedBridge.hookAllMethods(PopupWindow.class, "showAtLocation", popup);
        XposedBridge.hookAllMethods(PopupWindow.class, "showAsDropDown", popup);
        XposedBridge.hookAllMethods(Toast.class, "show", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                View tv = ((Toast) p.thisObject).getView();
                if (tv != null && blocked(tv)) p.setResult(null);
            }
        });
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Dialog) p.thisObject).getWindow().getDecorView();
                DIALOG.put(decor, new WeakReference<Dialog>((Dialog) p.thisObject));
                attach(decor);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                int vis = (Integer) p.args[0];
                if (vis != View.VISIBLE) {
                    if (SPEED_GUIDES.remove(p.thisObject) != null) pruneSpeedGuides();
                } else if (isSpeedSignalView((View) p.thisObject)) {
                    final View signal = (View) p.thisObject;
                    handler().post(() -> {   // 等这次 setVisibility 生效后，按整条祖先链判断是不是真的显示出来了
                        if (!speedSignalShown(signal)) return;
                        SPEED_GUIDES.put(signal, true);
                        hidePendantForSpeed();
                    });
                }
                if (speedPendantHidden && PENDANT_VIS.containsKey(p.thisObject)) {
                    // 保存抖音真正想设置的状态；模块自己设为 INVISIBLE 时不能覆盖这份记录。
                    if (!settingPendantVisibility && p.thisObject instanceof View) {
                        PENDANT_VIS.put((View) p.thisObject, vis);
                    }
                    p.args[0] = View.INVISIBLE;
                } else if (vis != View.GONE && (HIDDEN.containsKey(p.thisObject) || SPACE.containsKey(p.thisObject))) {
                    p.args[0] = View.GONE;
                } else if (vis == View.VISIBLE && NAV_BG.containsKey(p.thisObject)) {
                    p.args[0] = View.INVISIBLE;   // 抖音滑动时会把底栏背景重新设为可见，这里一律拦住
                } else if (vis == View.VISIBLE && articleNow && PENDANTS.containsKey(p.thisObject)) {
                    p.args[0] = View.INVISIBLE;   // 文章页：抖音再把挂件设成可见，拦回去
                } else if (vis == View.VISIBLE && !IMM.isEmpty()) {
                    float[] o = IMM.get(p.thisObject);
                    if (o != null && o[2] == 2f) {
                        p.args[0] = View.INVISIBLE;
                        o[3] = 1f;
                    }   // 沉浸模式：抖音（比如长按菜单打开时）把顶部控件、挂件重新设为可见，拦回去
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Drawable d = (Drawable) p.args[0];
                if (d != null && NAV_PAR.containsKey(p.thisObject)) {
                    if (!(d instanceof ColorDrawable && ((ColorDrawable) d).getColor() == 0)) {
                        NAV_PAR.put((View) p.thisObject, d);   // 记下抖音新设的背景，关闭功能时还原
                    }
                    p.args[0] = null;
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackgroundColor", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (NAV_PAR.containsKey(p.thisObject)) p.args[0] = Color.TRANSPARENT;
            }
        });
        hookPendantDrag();
        XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, new XC_MethodHook() {   // 标签：抖音写文案时就去掉标签部分，不会先闪一下原文
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Object o = p.thisObject;
                if (!(o instanceof TextView) || !o.getClass().getName().endsWith("ScrollMentionTextView") || !(on(TAG_KEY, true) || on(MEN_KEY, true))) return;
                CharSequence cur = (CharSequence) p.args[0];
                CharSequence out = trimDesc(cur);
                if (out != null) {
                    TITLE_ORIG.put((TextView) o, cur);
                    TITLE_SHOWN.put((TextView) o, out.toString());
                    p.args[0] = out;
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setSelected", boolean.class, new XC_MethodHook() {   // 被我们隐藏的标签（比如主页“日常”）被选中时，改点它前面/后面最近的可见标签，滑动翻页就不会停在它上面
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View v = (View) p.thisObject;
                if (!(Boolean) p.args[0] || !(v.getParent() instanceof ViewGroup) || !v.getClass().getName().endsWith("DmtTabLayout$TabView")) return;
                ViewGroup row = (ViewGroup) v.getParent();
                int idx = row.indexOfChild(v);
                Integer prev = TAB_LAST.put(row, idx);
                Long until = TAB_SKIP.get(row);
                boolean hid = HIDDEN.containsKey(v) || dailyTab(v);
                if (hid) {   // 记一条日志（同样内容只记一次），翻页不跳过时好查原因
                    String m = "DyHide: hidden tab selected idx=" + idx + " prev=" + prev + " vis=" + v.getVisibility() + " cooldown=" + (until != null && SystemClock.uptimeMillis() < until) + " fingerDown=" + fingerDown;
                    if (!m.equals(tabLog)) {
                        tabLog = m;
                        XposedBridge.log(m);
                    }
                }
                if (prev == null || prev == idx || !hid || (until != null && SystemClock.uptimeMillis() < until)) return;
                final int step = idx > prev ? 1 : -1;   // 从左边滑过来就继续往右找，从右边滑过来就往左找
                TAB_SKIP.put(row, SystemClock.uptimeMillis() + 2000);   // 已经排了一次检查：翻页途中标签会反复“选中”它，不重复排
                handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!v.isSelected()) {   // 手指拖过去又拖回来了，不用改
                            TAB_SKIP.remove(row);
                            return;
                        }
                        if (fingerDown) {   // 手指还按着（正在拖）：等松手再改，不打断拖动
                            handler().postDelayed(this, 80);
                            return;
                        }
                        for (int i = idx + step; i >= 0 && i < row.getChildCount(); i += step) {
                            View to = row.getChildAt(i);
                            if (to.getVisibility() == View.GONE || HIDDEN.containsKey(to) || dailyTab(to)) continue;
                            TAB_SKIP.put(row, SystemClock.uptimeMillis() + 1000);   // 改选后翻页还会经过被隐藏的标签，这一秒内不再改
                            to.performClick();
                            return;
                        }
                        TAB_SKIP.remove(row);
                    }
                }, 80);
            }
        });
        XposedHelpers.findAndHookMethod(Activity.class, "dispatchTouchEvent", MotionEvent.class, new XC_MethodHook() {   // 手指按下/松开：长按倍速松手就结束，挂件立刻恢复
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                MotionEvent ev0 = (MotionEvent) p.args[0];
                int a = ev0.getActionMasked();
                if (immSynth) return;   // 我们自己补发的点按，不再处理
                Activity act = (Activity) p.thisObject;
                View decor = act.getWindow().getDecorView();
                boolean main = MAIN.containsKey(decor);
                boolean dtap = main && on("imm_dtap", false), imm = main && immOn();
                if (dtap || imm) {
                    float near = 60f * app().getResources().getDisplayMetrics().density;
                    if (immSwallow) {   // 双击的第二下：整段手势吃掉，不让抖音当成“双击点赞”
                        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) immSwallow = false;
                        p.setResult(true);
                        return;
                    }
                    boolean late = immLate;
                    if (a == MotionEvent.ACTION_DOWN) immLate = false;
                    boolean second = a == MotionEvent.ACTION_DOWN && SystemClock.uptimeMillis() - immUpAt < (immPend ? 300 : 350) && Math.hypot(ev0.getRawX() - immUpX, ev0.getRawY() - immUpY) < near;
                    if (immPend && a == MotionEvent.ACTION_DOWN) {
                        handler().removeCallbacks(IMM_REPLAY);
                        if (second) {   // 双击：第一下一直被扣着没交给抖音（不会暂停），第二下也吃掉（不会点赞）
                            immPend = false;
                            immSwallow = true;
                            immSet(!imm);
                            p.setResult(true);
                            return;
                        }
                        IMM_REPLAY.run();   // 不是双击：先把扣下的第一下补发
                        immLate = false;
                    } else if (late && second) {   // 超过 200ms 才来的第二下：第一下已经补发给抖音了，这一下再交给抖音就成了“双击点赞”——照样当双击处理（切换沉浸模式），并整段吃掉
                        immSwallow = true;
                        immSet(!imm);
                        p.setResult(true);
                        return;
                    }
                }
                if (a == MotionEvent.ACTION_DOWN) {
                    if (sp != null && sp.hasFileChanged() && MAIN.containsKey(((Activity) p.thisObject).getWindow().getDecorView())) scan(((Activity) p.thisObject).getWindow().getDecorView());   // 刚在模块里改了开关（比如刚开沉浸模式）：先扫一遍，不等下次定时扫描，长按倍速的提示才不会先闪一下
                    fingerDown = true;
                    pinForce = false;
                    swiped = false;
                    downX = ((MotionEvent) p.args[0]).getRawX();
                    downY = ((MotionEvent) p.args[0]).getRawY();
                } else if (a == MotionEvent.ACTION_MOVE) {
                    MotionEvent ev = (MotionEvent) p.args[0];
                    float slop = 12f * app().getResources().getDisplayMetrics().density;
                    if (!swiped && (Math.abs(ev.getRawX() - downX) > slop || Math.abs(ev.getRawY() - downY) > slop)) swiped = true;
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    fingerDown = false;
                    immTap = a == MotionEvent.ACTION_UP && !swiped && ev0.getEventTime() - ev0.getDownTime() < 250;   // 一次干脆的点按
                    immUpAt = SystemClock.uptimeMillis();
                    immUpX = ev0.getRawX();
                    immUpY = ev0.getRawY();
                    if (dtap && immTap && !immPend && plainVideo(decor) && (imm || (immUpX < decor.getWidth() * 0.82f && immUpY > decor.getHeight() * 0.12f && immUpY < decor.getHeight() * 0.80f))) {   // 视频中间的一次点按：松手改成取消，等 200ms 看有没有第二下
                        MotionEvent cancel = MotionEvent.obtain(ev0);
                        cancel.setAction(MotionEvent.ACTION_CANCEL);
                        p.args[0] = cancel;
                        immPend = true;
                        immPendX = ev0.getX();
                        immPendY = ev0.getY();
                        immPendAct = act;
                        handler().postDelayed(IMM_REPLAY, 200);
                    }
                    if (swiped) swipeUntil = SystemClock.uptimeMillis() + 800;   // 滑动松手后的惯性/翻页动画：挂件要跟着走，这段时间不钉位置
                    SPEED_GUIDES.clear();
                    // 松手的同时抖音会给挂件做一段复位动画（会改它的上下位置）：马上显示就会看到它上下抽一下，等动画走完再显示
                    handler().postDelayed(() -> { if (!fingerDown) showPendantAfterSpeed(); }, 350);
                }
            }
        });
        XC_MethodHook transHook = new XC_MethodHook() {   // 抖音自己给挂件设平移（回前台的动画、切页复位）时，位置差得多才纠正
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (savedPos == null) return;
                float[] st = DRAG.get(p.thisObject);
                if (st == null || st[4] != 0f) return;
                View v = (View) p.thisObject;
                long now = SystemClock.uptimeMillis();
                long[] an = ANIM.get(v);
                if (an == null) { an = new long[]{now, 0}; ANIM.put(v, an); }
                if (now - an[0] > 300) { an[0] = now; an[1] = 0; }
                an[1]++;
                if (an[1] > 5) return;   // 300ms 内连着设了好几帧：抖音正在做动画（长按两侧倍速时挂件会动一下），这几帧不抢，免得来回抽搐
                float want = p.method.getName().equals("setTranslationX") ? savedPos[0] - v.getLeft() : savedPos[1] - v.getTop();
                float ask = (Float) p.args[0];
                if (Math.abs(ask - want) <= 8f * v.getResources().getDisplayMetrics().density) return;   // 差几 dp 的小幅位移也让过去
                if (!pinAllowed(Math.abs(ask - want))) return;   // 滑动中/刚滑完：挂件在跟着页面或视频动，不拉回
                p.args[0] = want;
            }
        };
        XposedHelpers.findAndHookMethod(View.class, "setTranslationX", float.class, transHook);
        XposedHelpers.findAndHookMethod(View.class, "setTranslationY", float.class, transHook);
        XposedHelpers.findAndHookMethod(View.class, "setContentDescription", CharSequence.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {   // 抖音靠改描述标记选中的标签
                CharSequence d = (CharSequence) p.args[0];
                if (d != null && tabCls != null && p.thisObject.getClass() == tabCls && d.toString().startsWith("已选中")) onTabSelected((View) p.thisObject);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setSelected", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if ((Boolean) p.args[0] && tabCls != null && p.thisObject.getClass() == tabCls) onTabSelected((View) p.thisObject);
            }
        });
    }

    static void attach(final View decor) {
        if (ATTACHED.containsKey(decor)) return;
        ATTACHED.put(decor, true);
        final android.view.ViewTreeObserver vto = decor.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() { schedule(decor); }
        });
        if (!MAIN.containsKey(decor)) {   // 弹窗（如长按菜单）：第一帧绘制前同步扫描，被隐藏的控件不会先闪出来
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                @Override
                public boolean onPreDraw() {
                    decor.getViewTreeObserver().removeOnPreDrawListener(this);
                    scan(decor);
                    return true;
                }
            });
        }
        else {   // 主窗口：刚恢复的前 3 秒，绘制前（至少隔 60ms）扫一遍；这一轮有新隐藏就放弃这一帧重新布局，被挤到下面的作者名不会先出现一下再往下跳
            final long t0 = SystemClock.uptimeMillis();
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                long last;

                @Override
                public boolean onPreDraw() {
                    long now = SystemClock.uptimeMillis();
                    if (now - t0 > 3000) {
                        decor.getViewTreeObserver().removeOnPreDrawListener(this);
                        return true;
                    }
                    if (now - last < 60) return true;
                    last = now;
                    int before = matched;
                    scan(decor);
                    return matched == before;
                }
            });
        }
        schedule(decor);
    }

    /**
     * 抖音不同页面/版本的倍速提示结构并不一致：有时使用 LongPressFastSpeedGuideView，
     * 有时使用直接包含提示文字的 LinearLayout（如“下滑松手锁定 2 倍速”或“快进中”）。
     * 只检查直接子 TextView，避免把整棵 DecorView 等祖先容器误识别成信号。
     */
    /** 提示视图自己 VISIBLE 不代表看得见：抖音常把它留在 INVISIBLE/透明的父容器里（ViewDump 里 bottom_layout vis=4），必须看整条祖先链。 */
    static boolean speedSignalShown(View v) {
        if (!v.isShown()) return false;
        // 带文字的容器要在屏幕上占得到面积（首页有的容器可见性一直是 VISIBLE 但没有面积，会让挂件一直不恢复）；
        // 提示视图本身（LongPressFastSpeedGuideView）首页上面积为 0 也在显示，只看可见性。
        if (!v.getClass().getName().endsWith("LongPressFastSpeedGuideView") && !v.getGlobalVisibleRect(new Rect())) return false;
        for (View x = v; x.getAlpha() > 0.05f; ) {
            if (!(x.getParent() instanceof View)) return true;
            x = (View) x.getParent();
        }
        return false;
    }

    static boolean isSpeedSignalView(View view) {
        if (view.getClass().getName().endsWith("LongPressFastSpeedGuideView")) return true;
        if (!(view instanceof ViewGroup)) return false;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (!(child instanceof TextView)) continue;
            CharSequence value = ((TextView) child).getText();
            if (value == null) continue;
            String text = value.toString().trim();
            if (text.contains("下滑松手锁定 2 倍速") || text.contains("快进中")) return true;
        }
        return false;
    }

    static boolean fingerDown;   // 倍速提示只在手指按着时才算（长按倍速松手就结束）；松手后残留的淡出动画、没面积的占位容器都不再触发隐藏

    /**
     * 搜索页顶部这个 Lynx 区块里，“历史记录”和“猜你想搜”画在同一个区块里，只有历史记录的条目有无障碍节点（desc 以“，按钮”结尾），
     * 猜你想搜只画不暴露节点，没法单独隐藏；所以把区块只画到最后一个历史条目为止，下面裁掉。开关关闭时撤掉裁剪，不用重启抖音。
     */
    static void clipGuess(View wrapper) {
        if (!on("r_猜你想搜", true)) {
            if (wrapper.getClipBounds() != null) wrapper.setClipBounds(null);
            return;
        }
        int[] loc = new int[2];
        wrapper.getLocationOnScreen(loc);
        View head = findDesc(wrapper, "猜你想搜");   // 新版本里“猜你想搜”标题有无障碍节点：从它所在的那一块的顶部往下裁，历史记录整块保留
        int bottom;
        if (head != null && head.getParent() instanceof View) {
            int[] pl = new int[2];
            ((View) head.getParent()).getLocationOnScreen(pl);
            bottom = Math.max(0, pl[1] - loc[1]);
        } else {
            bottom = historyBottom(wrapper, loc[1]);
        }
        wrapper.setClipBounds(new Rect(0, 0, wrapper.getWidth(), bottom));
    }

    static View findDesc(View v, String d) {
        CharSequence c = v.getContentDescription();
        if (c != null && d.contentEquals(c)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findDesc(g.getChildAt(i), d);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** 区块里最后一个历史条目的下沿（相对区块顶部）；没有历史记录时是 0，整块裁掉。 */
    static int historyBottom(View v, int top) {
        int bottom = 0;
        CharSequence d = v.getContentDescription();
        if (d != null && d.toString().endsWith("，按钮")) {
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            bottom = loc[1] + v.getHeight() - top;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) bottom = Math.max(bottom, historyBottom(g.getChildAt(i), top));
        }
        return bottom;
    }

    static void hidePendantForSpeed() {
        if (!fingerDown) return;
        speedPendantHidden = true;
        settingPendantVisibility = true;
        try {
            for (View v : new ArrayList<View>(PENDANTS.keySet())) {
                if (v == null || !v.isAttachedToWindow()) continue;
                PENDANT_VIS.putIfAbsent(v, v.getVisibility());
                v.setVisibility(View.INVISIBLE);
            }
        } finally {
            settingPendantVisibility = false;
        }
    }

    static void showPendantAfterSpeed() {
        if (!speedPendantHidden) return;
        speedPendantHidden = false;
        settingPendantVisibility = true;
        try {
            for (Map.Entry<View, Integer> e : new ArrayList<>(PENDANT_VIS.entrySet())) {
                View v = e.getKey();
                Integer visibility = PENDANT_VIS.remove(v);
                if (v != null && visibility != null && v.isAttachedToWindow()) {
                    placePendant(v);   // 隐藏期间抖音可能把它挪了位置，先放回拖放过的位置再显示，不会在眼前跳一下
                    holdPendant(v, 1200);    // 显示后一小段时间里，每帧绘制前把位置钉回按下前的位置，抖音的复位/吸边动画就看不到
                    v.setVisibility(visibility == View.INVISIBLE ? View.VISIBLE : visibility);   // 记下来的若是 INVISIBLE，那是被我们自己（或长按期间的抖音）藏起来的状态，不是抖音真想藏：不按它恢复，否则首页上挂件要等关评论区才回来
                }
            }
        } finally {
            settingPendantVisibility = false;
        }
    }

    /** 倍速结束后的 1.2 秒里，每帧绘制前把挂件钉回应在的位置（拖放过的位置优先，否则是按下前的位置）：抖音此时做的上下/左右复位动画不会被画出来。 */
    static void holdPendant(final View v, long ms) {
        final float[] pos = savedPos != null ? savedPos : PENDANT_POS.get(v);
        if (pos == null) return;
        final long end = SystemClock.uptimeMillis() + ms;
        final ViewTreeObserver vto = v.getViewTreeObserver();
        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                float[] d = DRAG.get(v);
                boolean stop = !v.isAttachedToWindow() || swiping() || SystemClock.uptimeMillis() > end || (d != null && d[4] != 0f);
                if (stop) {
                    ViewTreeObserver o = v.getViewTreeObserver();
                    if (o.isAlive()) o.removeOnPreDrawListener(this);
                    return true;
                }
                float tx = pos[0] - v.getLeft(), ty = pos[1] - v.getTop();
                float dev = Math.max(Math.abs(v.getTranslationX() - tx), Math.abs(v.getTranslationY() - ty));
                if (dev == 0f || !pinAllowed(dev)) return true;
                v.setTranslationX(tx);
                v.setTranslationY(ty);
                return true;
            }
        });
        v.invalidate();
    }

    /** 挂件的左右位置永远钉在拖放过的位置（每帧绘制前）：打开视频页、展开文案、关评论区时抖音做的复位/吸边动画不会被画出来。只钉左右；上下留给抖音，视频上下滑动时挂件要跟着视频走。手指按着（滑动、拖动）时不钉。 */
    static final java.util.ArrayDeque<String> TRACE = new java.util.ArrayDeque<>();   // 挂件轨迹（只在位置变化时记一行），导出 viewdump 时附在最后
    static float traceX = Float.NaN, traceY = Float.NaN;

    static void traceFrame(View v) {
        float x = v.getTranslationX(), y = v.getTranslationY();
        if (x == traceX && y == traceY) return;
        traceX = x;
        traceY = y;
        synchronized (TRACE) {
            if (TRACE.size() >= 160) TRACE.removeFirst();
            TRACE.addLast((SystemClock.uptimeMillis() % 1000000) + " transX=" + Math.round(x) + " transY=" + Math.round(y) + " left=" + v.getLeft() + " top=" + v.getTop() + " down=" + fingerDown + " swiped=" + swiped + " win=" + (SystemClock.uptimeMillis() < swipeUntil));
        }
    }

    static boolean swiping() { return fingerDown && swiped; }

    static boolean pinForce;   // 滑动后的窗口里检测到“一帧跳很远”（抖音把挂件重置了），本次手势剩下的时间一律钉回去
    static float obsX = Float.NaN, obsY = Float.NaN;

    /** 挂件位置要不要钉回去：正在滑动不钉；滑动松手后的 800ms 里只钉小偏差（抖音的小抽动），大幅但连续的位移是页面在带着挂件动，放行；一帧跳变是瞬移，钉。 */
    static boolean pinAllowed(float devPx) {
        if (swiping()) return false;
        if (SystemClock.uptimeMillis() < swipeUntil) return pinForce || devPx < 80f * android.content.res.Resources.getSystem().getDisplayMetrics().density;
        return true;
    }

    /** 每帧绘制前把挂件钉在拖放过的位置（左右 + 上下）：打开视频页、展开文案、关评论区时抖音的复位/吸边动画、首次打开时 10px 左右的上下抖动都画不出来。轨迹里挂件上下从没有被抖音带着动过，所以上下也钉。 */
    static void pinPendant(final View v) {
        v.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                traceFrame(v);
                float cx = v.getTranslationX(), cy = v.getTranslationY();
                float jump = 100f * android.content.res.Resources.getSystem().getDisplayMetrics().density;
                if (SystemClock.uptimeMillis() < swipeUntil && !Float.isNaN(obsX) && (Math.abs(cx - obsX) > jump || Math.abs(cy - obsY) > jump)) pinForce = true;   // 切推荐/关注页后挂件被重置到 x=0，一帧跳了上千像素
                obsX = cx;
                obsY = cy;
                float[] d = DRAG.get(v);
                if (savedPos == null || !v.isAttachedToWindow() || (d != null && d[4] != 0f)) return true;
                float tx = savedPos[0] - v.getLeft(), ty = savedPos[1] - v.getTop();
                float dev = Math.max(Math.abs(cx - tx), Math.abs(cy - ty));
                if (dev != 0f && pinAllowed(dev)) {
                    v.setTranslationX(tx);
                    v.setTranslationY(ty);
                }
                return true;
            }
        });
    }

    /** 标签：文案里每个“#话题”去掉（连同末尾的“>”），标题文字保留；没有标签返回 null。 */
    static boolean blank(char c) {
        return Character.isWhitespace(c) || Character.isSpaceChar(c) || c == '\u200B' || c == '\uFEFF';
    }

    static CharSequence trimDesc(CharSequence cur) {
        boolean tag = on(TAG_KEY, true), men = on(MEN_KEY, true);
        if (cur == null || cur.length() == 0 || !(tag || men)) return null;
        java.util.regex.Matcher m = (tag && men ? TAG_MEN : tag ? TAG : MEN).matcher(cur);
        List<int[]> hits = new ArrayList<>();
        while (m.find()) hits.add(new int[]{m.start(), m.end()});
        SpannableStringBuilder b = new SpannableStringBuilder(cur);
        for (int i = hits.size() - 1; i >= 0; i--) b.delete(hits.get(i)[0], hits.get(i)[1]);
        int lead = 0;
        while (lead < b.length() && blank(b.charAt(lead))) lead++;
        if (lead > 0) b.delete(0, lead);   // 标签在最前面时，后面的文案前面会留着空格
        int n = b.length();
        while (n > 0 && blank(b.charAt(n - 1))) n--;
        b.delete(n, b.length());
        if (n > 0 && b.charAt(n - 1) == '>' && !b.subSequence(0, n - 1).toString().trim().endsWith("展开")) {   // 标签后面跟的“>”箭头一起去掉（“展开>”的箭头保留）
            b.delete(n - 1, n);
            n--;
            while (n > 0 && blank(b.charAt(n - 1))) n--;
            b.delete(n, b.length());
        }
        if (b.toString().equals(cur.toString())) return null;
        java.util.regex.Matcher gap = GAP.matcher(b);   // 去掉标签后，文案和“展开”之间留下的空格（含全角、不换行空格）收成一个普通空格
        List<int[]> gaps = new ArrayList<>();
        while (gap.find()) gaps.add(new int[]{gap.start(), gap.end()});
        for (int i = gaps.size() - 1; i >= 0; i--) b.replace(gaps.get(i)[0], gaps.get(i)[1], " ");
        return b;
    }

    /** 去掉标签后文案变短，但抖音给文案留的高度没变，下面会空出一两行：用户名和文案一起下移这么多。没有文案（只有标签）时下移整块文案区；文案后带“展开”的（标签很长、被折成两三行的视频）也一样按现在的行数算。 */
    static void shiftDesc(TextView tv) {
        View root = ancestor(tv, "FeedDescRootLayout");
        if (root == null) return;
        float want = 0f;
        CharSequence t = tv.getText();
        int h = tv.getHeight();
        int key = (((t == null ? 0 : t.toString().hashCode()) * 31 + h) * 31 + tv.getWidth()) * 31 + tv.getTotalPaddingTop();   // 文字上沿的偏移变了（控件刷新了排版）也要重新算
        Integer seenKey = SHIFT_KEY.get(tv);
        if (seenKey != null && seenKey == key) {   // 文字和尺寸都没变：不重新量（每次扫描都建 StaticLayout 会让评论区滑动时卡顿）
            shiftStack(root, SHIFT_WANT.get(tv));
            return;
        }
        if (TITLE_SHOWN.containsKey(tv) && h > 0 && tv.getWidth() > 0) {
            if (t == null || t.toString().trim().isEmpty()) {
                want = h;   // 只有标签：整块文案区都是空的，用户名下移这么多
            } else {
                // 控件还是按原文案（含标签）的行数撑着高度，tv.getLayout() 也可能是旧的：自己按现在的文字重新量一遍需要几行
                int w = Math.max(1, tv.getWidth() - tv.getTotalPaddingLeft() - tv.getTotalPaddingRight());
                android.text.StaticLayout sl = android.text.StaticLayout.Builder.obtain(t, 0, t.length(), tv.getPaint(), w)
                        .setLineSpacing(tv.getLineSpacingExtra(), tv.getLineSpacingMultiplier()).setIncludePad(tv.getIncludeFontPadding())
                        .setBreakStrategy(tv.getBreakStrategy()).setHyphenationFrequency(tv.getHyphenationFrequency()).build();
                // 文字下沿到控件下沿的空白。getTotalPaddingTop 里含文字在控件里居中/靠下的偏移（这样才是文字实际画的位置），
                // 下边只减固定的内边距：原来连下边的偏移也减掉，居中的文案（日志里 h=157、现在 1 行）算出来是 0，就不下移了
                int blank = h - (tv.getTotalPaddingTop() + sl.getHeight() + tv.getCompoundPaddingBottom());
                if (blank >= tv.getLineHeight() * 0.3f) want = blank;
            }
        }
        CharSequence orig = TITLE_ORIG.get(tv);
        if (want == 0f && orig != null && t != null && !orig.toString().contentEquals(t) && h > 0) {   // 标签去掉了却没有下移：记下数字，方便查（同样内容只记一次）
            String m = "DyHide: no shift origLen=" + orig.length() + " len=" + t.length() + " h=" + h + " lines=" + tv.getLineCount() + " lineH=" + tv.getLineHeight()
                    + " w=" + tv.getWidth() + " rootH=" + root.getHeight() + " maxLines=" + tv.getMaxLines() + " minH=" + tv.getMinHeight() + " ty=" + root.getTranslationY();
            if (!m.equals(shiftLog)) {
                shiftLog = m;
                XposedBridge.log(m);
            }
        }
        SHIFT_KEY.put(tv, key);
        SHIFT_WANT.put(tv, want);
        shiftStack(root, want);
    }

    /** 文案区上面同一个容器里、排在它上方的所有可见控件（作者名、店铺栏、声明、标签行、全屏观看按钮…）和文案区一起下移，中间不会再空一行。 */
    static void shiftStack(View root, float want) {
        applyShift(root, want);
        if (!(root.getParent() instanceof ViewGroup)) return;
        ViewGroup p = (ViewGroup) root.getParent();
        for (int i = 0; i < p.getChildCount(); i++) {
            View ch = p.getChildAt(i);
            if (ch == root) continue;
            boolean above = ch.getVisibility() == View.VISIBLE && ch.getHeight() > 0 && ch.getTop() < root.getTop() && ch.getBottom() <= root.getBottom()
                    && ch.getLeft() < root.getLeft() + root.getWidth() / 2;   // 只带动文字这一列上方的控件，右边的点赞/评论那一列不能被一起下移
            applyShift(ch, above ? want : 0f);
        }
    }

    static String shiftLog = "";
    static final Map<TextView, Integer> SHIFT_KEY = new WeakHashMap<>();
    static final Map<TextView, Float> SHIFT_WANT = new WeakHashMap<>();
    static final Map<View, float[]> SHIFT_ST = new WeakHashMap<>();   // 控件 -> {下移量, 我们上次设的 translationY}

    static void applyShift(View v, float want) {
        float[] st = SHIFT_ST.get(v);
        if (st == null && want == 0f) return;
        float cur = v.getTranslationY();
        float base = st == null ? cur : (cur == st[1] ? cur - st[0] : cur);   // 抖音把平移重置过（切页/复用）就以当前值为基准，不会以为“已经下移过”而不再设
        float t = base + want;
        if (cur != t) v.setTranslationY(t);
        if (want == 0f) SHIFT_ST.remove(v); else SHIFT_ST.put(v, new float[]{want, t});
        if (want == 0f) SHIFTED.remove(v); else SHIFTED.put(v, want);
    }

    static final Map<View, Integer> MALL_H = new WeakHashMap<>();   // 商城顶部那块的 FrameLayout 原来的高度（LayoutParams.height）
    static String tabLog = "";
    static String dailyKey;

    /** 主页“作品 / 日常 / 收藏”标签栏里的“日常”（标签自己的描述是“日常,按钮,…”），并且隐藏开关是开着的。 */
    static boolean dailyTab(View v) {
        if (dailyKey == null) for (Rules.R r : Rules.ALL) if (r.label.equals("主页标签：日常")) dailyKey = r.key();
        return String.valueOf(v.getContentDescription()).startsWith("日常") && on(dailyKey, true);
    }

    static final Map<ViewGroup, Long> TAB_SKIP = new WeakHashMap<>();   // 每排标签：这个时间点之前不再改选（已经排了检查 / 刚改选过）
    static final Map<ViewGroup, Integer> TAB_LAST = new WeakHashMap<>();   // 每排标签上一次被选中的位置
    static String mallLog = "";   // 上一条商城日志，同样内容不重复记
    static final Map<View, Boolean> MALL_HID = new WeakHashMap<>();   // 被我们藏起来（透明 + 移出屏幕）的商城控件，开关打开后据此还原

    static final Map<View, Integer> MALL_NUDGE = new WeakHashMap<>();

    /** 给 Lynx 根视图发一次不会触发点击的触摸（按下 + 取消）并让横向滚动容器来回动 1 像素，让它把第二页的格子建出来。 */
    static void mallNudge(ViewGroup pager) {
        View lv = pager;
        while (lv.getParent() instanceof View && !lv.getClass().getName().endsWith("AnnieXLynxView")) lv = (View) lv.getParent();
        float[] pos = mallPos(pager, lv);
        long t = SystemClock.uptimeMillis();
        XposedBridge.log("DyHide: mall nudge page2 on " + lv.getClass().getName());
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, pos[0] + 4f, pos[1] + 4f, 0);
        lv.dispatchTouchEvent(d);
        d.recycle();
        MotionEvent c = MotionEvent.obtain(t, t + 10, MotionEvent.ACTION_CANCEL, pos[0] + 4f, pos[1] + 4f, 0);
        lv.dispatchTouchEvent(c);
        c.recycle();
        if (pager.getParent() instanceof View) {
            View host = (View) pager.getParent();
            host.scrollBy(1, 0);
            host.scrollBy(-1, 0);
        }
    }

    /** g 是不是商城入口宫格的一页：10 个等宽的 ComponentView，5 列。 */
    static boolean mallIsGrid(View v) {
        if (!(v instanceof ViewGroup) || ((ViewGroup) v).getChildCount() != 10 || !v.getClass().getName().startsWith("com.lynx.tasm.behavior.ui.view.")) return false;
        ViewGroup g = (ViewGroup) v;
        int w = g.getWidth();
        if (w <= 0) return false;
        for (int i = 0; i < 10; i++) {
            View ch = g.getChildAt(i);
            if (!ch.getClass().getName().endsWith("ComponentView") || Math.abs(ch.getWidth() * 5 - w) > w / 25) return false;
        }
        return true;
    }

    static ViewGroup mallFindGrid(View v, int depth) {
        if (mallIsGrid(v)) return (ViewGroup) v;
        if (depth > 3 || !(v instanceof ViewGroup)) return null;
        ViewGroup p = (ViewGroup) v;
        for (int i = 0; i < p.getChildCount(); i++) {
            ViewGroup r = mallFindGrid(p.getChildAt(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** v 在 anc 里的位置（只加各层的 left/top，不含平移）。 */
    static float[] mallPos(View v, View anc) {
        float x = 0, y = 0;
        for (View c = v; c != anc && c != null; c = c.getParent() instanceof View ? (View) c.getParent() : null) {
            x += c.getLeft();
            y += c.getTop();
        }
        return new float[]{x, y};
    }

    /**
     * 商城顶部入口宫格（两页横向翻页，每页 10 格、5 列，先排第一行再排第二行）：按位置隐藏被关掉的格子，
     * 没隐藏的从第一页第一格起连着往后排（排满第一行排第二行，第一页装不下再排第二页）。
     * 入口是 Lynx 画出来的图片，没有文字也没有描述，只能按位置认。顺便处理宫格下面的“惊喜补贴”横条和第一页底部的“免费抽 1 次”提示条。
     * 两页的格子放在一起排，所以只在遇到第一页的宫格时处理一次。
     */
    static void mallGrid(ViewGroup g) {
        if (!mallIsGrid(g)) return;
        ViewGroup pager = null;
        View pg = g;   // g 所在的那一页（g 自己，或往上一两层）
        for (int i = 0; i < 3 && pager == null && pg.getParent() instanceof ViewGroup; i++) {
            ViewGroup p = (ViewGroup) pg.getParent();
            if (p instanceof android.widget.LinearLayout && p.getChildCount() >= 2) pager = p;
            else pg = p;
        }
        if (pager == null || pager.indexOfChild(pg) != 0) return;   // 不是翻页容器里的第一页
        ViewGroup g1 = mallFindGrid(pager.getChildAt(1), 0);
        View p2 = pager.getChildAt(1);
        if (mallFindGrid(p2, 0) == null && p2 instanceof ViewGroup && ((ViewGroup) p2).getChildCount() <= 1) {   // 第二页的格子要触碰才会建出来：主动碰一下（最多 3 次）
            Integer tries = MALL_NUDGE.get(pager);
            if (tries == null || tries < 3) {
                MALL_NUDGE.put(pager, tries == null ? 1 : tries + 1);
                final ViewGroup pgr = pager;
                handler().post(() -> mallNudge(pgr));
            }
        }
        // 第二页的状态记一条日志（同样内容只记一次），方便看第二页什么时候才排好
        String m = "DyHide: mall page2 " + (g1 == null ? "not ready" : "ready") + " cls=" + p2.getClass().getName() + " children=" + (p2 instanceof ViewGroup ? ((ViewGroup) p2).getChildCount() : -1)
                + " w=" + p2.getWidth() + " vis=" + p2.getVisibility() + " alpha=" + p2.getAlpha() + " shown=" + p2.isShown();
        if (!m.equals(mallLog)) {
            mallLog = m;
            XposedBridge.log(m);
        }
        ViewGroup[] pages = g1 == null ? new ViewGroup[]{g} : new ViewGroup[]{g, g1};
        boolean[][] hide = new boolean[2][10];
        boolean banner = false, hint = false;
        for (Rules.R r : Rules.MALL_RULES) {
            if (!on(r.key(), true)) continue;
            if (r.mallPage >= 0) hide[r.mallPage][r.mallIdx] = true;
            else if (r.mallPage == -1) banner = true;
            else hint = true;
        }
        int v0 = 0, v1 = 0;   // 两页各自没隐藏的格子数
        for (int i = 0; i < 10; i++) {
            if (!hide[0][i]) v0++;
            if (g1 != null && !hide[1][i]) v1++;
        }
        boolean toFirst = v0 < 10 && v1 > 0;   // 第一页有空位、第二页有格子：第二页的格子要排到第一页
        float[] o0 = mallPos(g, pager);
        float shiftX = 0f, shiftY = 0f;
        if (toFirst) {   // 整个第二页平移到第一页上面，它的格子就在第一页自己的位置里（不会跑到页面边界之外）
            float[] o1 = mallPos(g1, pager);
            shiftX = o0[0] - o1[0];
            shiftY = o0[1] - o1[1];
        }
        if (g1 != null) {
            if (g1.getTranslationX() != shiftX) g1.setTranslationX(shiftX);
            if (g1.getTranslationY() != shiftY) g1.setTranslationY(shiftY);
        }
        int slot = 0;
        for (int pi = 0; pi < pages.length; pi++) {
            for (int i = 0; i < 10; i++) {
                View ch = pages[pi].getChildAt(i);
                if (hide[pi][i]) {
                    mallPlace(ch, true, -20000f, 0f);
                    continue;
                }
                View to = pages[slot / 10].getChildAt(slot % 10);
                slot++;
                float[] f = mallPos(ch, pager), t = mallPos(to, pager);
                float cx = pi == 1 ? shiftX : 0f, cy = pi == 1 ? shiftY : 0f;   // 第二页的格子已经跟着整页平移了一段
                mallPlace(ch, false, t[0] - f[0] - cx, t[1] - f[1] - cy);
            }
        }
        if (g.getParent() instanceof ViewGroup) {   // 第一页底部的提示条：和宫格同一个父容器，在第一行下面、几乎一样宽、比一格矮
            ViewGroup gp = (ViewGroup) g.getParent();
            for (int i = 0; i < gp.getChildCount(); i++) {
                View b = gp.getChildAt(i);
                if (b != g && b instanceof ViewGroup && b.getHeight() > 0 && b.getHeight() < g.getChildAt(0).getHeight()
                        && b.getWidth() * 10 >= g.getWidth() * 9 && b.getTop() >= g.getTop() + g.getChildAt(0).getBottom() - 4) {
                    mallPlace(b, hint, -20000f, 0f);
                }
            }
        }
        View blk = g;   // “惊喜补贴”横条和宫格所在的整块并排，在它下面、一样宽、更矮
        for (int i = 0; i < 9 && blk.getParent() instanceof ViewGroup; i++) {
            ViewGroup p = (ViewGroup) blk.getParent();
            if (p.getChildCount() == 2) {
                View b = p.getChildAt(p.indexOfChild(blk) == 0 ? 1 : 0);
                if (b != blk && b.getTop() >= blk.getBottom() - 1 && Math.abs(b.getWidth() - blk.getWidth()) <= 2 && b.getHeight() > 0 && b.getHeight() < blk.getHeight()) {
                    mallPlace(b, banner, -20000f, 0f);
                    View fl = p;   // Lynx 把横条的白色圆角底画在父层上，光把横条移走还会剩一块白底：把 Lynx 外面的 FrameLayout 收到横条原来的位置，超出的部分就不显示了
                    for (int k = 0; k < 4 && fl != null && fl.getClass() != android.widget.FrameLayout.class; k++) fl = fl.getParent() instanceof View ? (View) fl.getParent() : null;
                    if (fl != null && fl.getClass() == android.widget.FrameLayout.class && fl.getLayoutParams() != null) {
                        ViewGroup.LayoutParams lp = fl.getLayoutParams();
                        Integer orig = MALL_H.get(fl);
                        if (orig == null) {
                            orig = lp.height;
                            MALL_H.put(fl, orig);
                        }
                        int want = banner ? b.getTop() : orig;
                        if (lp.height != want) {
                            lp.height = want;
                            fl.setLayoutParams(lp);
                        }
                    }
                    break;
                }
            }
            blk = p;
        }
    }

    /** hide：透明并移出屏幕（不改可见性，免得 Lynx 重新布局时闪一下）；否则平移到 (tx, ty)，之前被我们藏起来的恢复不透明。 */
    static void mallPlace(View v, boolean hide, float tx, float ty) {
        if (v.getTranslationX() != tx) v.setTranslationX(tx);
        if (v.getTranslationY() != ty) v.setTranslationY(ty);
        if (hide) {
            if (v.getAlpha() != 0f) v.setAlpha(0f);
            MALL_HID.put(v, true);
        } else if (MALL_HID.remove(v) != null) {
            v.setAlpha(1f);
        }
    }

    /** 整个文案区被收起又恢复显示后，让文案重新走一遍写入和布局（收起期间它没有被测量，恢复后部分视频文案显示不出来，要刷几个视频才正常）。 */
    static void rebindDesc(View root) {
        View tv = findByClass(root, "ScrollMentionTextView", 0);
        if (!(tv instanceof TextView)) return;
        TextView t = (TextView) tv;
        CharSequence orig = TITLE_ORIG.get(t);
        TITLE_SHOWN.remove(t);
        TITLE_ORIG.remove(t);
        t.setText(orig != null ? orig : t.getText());
        for (View a = tv; a != null; a = a.getParent() instanceof View && a != root ? (View) a.getParent() : null) a.forceLayout();
        root.requestLayout();
    }

    static View findByClass(View v, String suffix, int depth) {
        if (v.getClass().getName().endsWith(suffix)) return v;
        if (depth > 6 || !(v instanceof ViewGroup)) return null;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            View r = findByClass(g.getChildAt(i), suffix, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** 兜底：钩子没拦到的文案（子类自己改写文字）在扫描时补一次；开关关闭时把原文还原。 */
    static void titleScan(View v, boolean enabled) {
        if (!(v instanceof TextView)) return;
        TextView tv = (TextView) v;
        CharSequence cur = tv.getText();
        String shown = TITLE_SHOWN.get(tv);
        boolean mine = shown != null && cur != null && cur.toString().equals(shown);   // 现在显示的就是我们改过的
        if (!enabled) {
            if (mine) tv.setText(TITLE_ORIG.get(tv));
            TITLE_SHOWN.remove(tv);
            TITLE_ORIG.remove(tv);
            return;
        }
        CharSequence base = mine ? TITLE_ORIG.get(tv) : cur;   // 从原文重新算：标签/@ 两个开关只关了其中一个时，另一个的结果也要跟着变
        CharSequence out = trimDesc(base);
        if (mine && (out == null ? base : out).toString().equals(shown)) return;
        if (out == null) {
            if (mine) {
                TITLE_SHOWN.remove(tv);
                TITLE_ORIG.remove(tv);
                tv.setText(base);
            }
            return;
        }
        TITLE_ORIG.put(tv, base);
        TITLE_SHOWN.put(tv, out.toString());
        tv.setText(out);
    }

    // ---------- 沉浸模式 ----------
    static final Map<View, float[]> IMM = new WeakHashMap<>();   // 被沉浸模式藏起来的控件 -> {原可见性, 原透明度}
    /** 首页视频翻页容器（RTViewPager，描述“视频”）在屏幕上、并且评论区没打开：只有这时的点按才可能是“视频上的双击”，主页、商城、评论区里的点按不能被扣 200ms。 */
    static boolean plainVideo(View decor) {
        View[] f = new View[2];   // f[0] 视频翻页容器，f[1] 打开着的评论区
        probeFeed(decor, f);
        if (f[0] == null || f[1] != null || !f[0].isShown()) return false;
        int[] loc = new int[2];
        f[0].getLocationOnScreen(loc);
        return loc[0] > -decor.getWidth() / 2 && loc[0] < decor.getWidth() / 2;
    }

    static void probeFeed(View v, View[] out) {
        String cn = v.getClass().getName();
        if (out[0] == null && cn.endsWith("RTViewPager") && "视频".equals(String.valueOf(v.getContentDescription()))) out[0] = v;
        if (out[1] == null && cn.endsWith("CommentNestedLayout") && v.isShown() && v.getHeight() > 0) out[1] = v;
        if (!(v instanceof ViewGroup)) return;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) probeFeed(g.getChildAt(i), out);
    }

    static boolean immStatusHidden, immTap, immSwallow, immSynth, immPend, immLate;   // immLate：第一下已经超时补发（视频已暂停），正在等可能迟到的第二下
    static long immOvrAt = -1;    // 抖音里最近一次双击/菜单切换沉浸模式的时间（存在抖音自己的配置里，重开抖音也在）
    static boolean immOvr;
    static float immPendX, immPendY;
    static Activity immPendAct;
    static long immUpAt;
    static float immUpX, immUpY;

    /** 1 = 只把透明度压到 0（里面有长按倍速的触摸层，必须还能收到触摸）；2 = 透明度 0 + 不可见，抖音再设成可见时 setVisibility 钩子会拦回去（没有手势的纯控件，不会一闪一闪）；0 = 不动。进度条（DProSeekBar）不在其中。 */
    static int immKind(String cn) {
        if (cn.endsWith("MonitorScrollFrameLayout")) return 1;
        if (cn.endsWith("MainTitleBarContainer") || cn.endsWith("MainBottomTabContainer") || cn.endsWith("FeedRightScaleView") || cn.endsWith("AwemeIntroInfoLayout") || cn.endsWith("CoinPendantView")) return 2;
        return 0;
    }

    static void immHide(View v, String cn) {
        int k = immKind(cn);
        if (k == 0) return;
        if (cn.endsWith("MonitorScrollFrameLayout")) {
            View ph = findByClass(v, "FeedPhotosGestureDispatchLayout", 0);
            View keep = ph != null ? ph : findByClass(v, "AnnieXLynxView", 0);   // 图文的图片层 / 文章正文（Lynx 的 MarkdownView）：内容就在这个控件层里，整层压透明会什么都看不到
            if (keep != null && keep.isShown()) {
                immUnhide(v);
                immKeep(v, keep, ph != null ? findByClass(v, "FeedListProgressBar", -3) : null);   // 图文底部的分段进度条也留着
                return;
            }
        }
        immApply(v, k);
    }

    /** 只留 a、b 两个控件（以及它们往上到 top 的整条路径），路径上每一级的其它兄弟全部压透明（只是透明度，长按倍速的触摸层照常收触摸）。 */
    static void immKeep(View top, View a, View b) {
        java.util.HashSet<View> path = new java.util.HashSet<>();
        path.add(top);
        for (View k : new View[]{a, b}) for (View x = k; x != null && x != top; x = x.getParent() instanceof View ? (View) x.getParent() : null) path.add(x);
        for (View n : path) {
            if (n == a || n == b || !(n instanceof ViewGroup)) continue;
            ViewGroup g = (ViewGroup) n;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (path.contains(ch)) immUnhide(ch); else immApply(ch, 1);
            }
        }
    }

    static void immApply(View v, int k) {
        if (!IMM.containsKey(v)) IMM.put(v, new float[]{v.getVisibility(), v.getAlpha(), k, 0f});
        if (v.getAlpha() != 0f) v.setAlpha(0f);
        if (k == 2 && v.getVisibility() == View.VISIBLE) v.setVisibility(View.INVISIBLE);
    }

    static void immUnhide(View v) {
        float[] o = IMM.remove(v);
        if (o == null) return;
        v.setAlpha(o[1] > 0.05f ? o[1] : 1f);   // 记下来的是 0（页面刚建好、抖音还没把它淡入）就当 1，否则关掉沉浸模式后这些页的右侧控件会一直透明
        if (v.getVisibility() == View.INVISIBLE && ((int) o[0] == View.VISIBLE || o[3] == 1f)) v.setVisibility(View.VISIBLE);   // o[3]：沉浸期间抖音想把它设成可见、被我们拦下的，关掉后也要还它可见
    }

    static boolean articleNow;   // 当前屏幕上的这一页是文章（正文是 Lynx 视图）
    static final Map<View, Integer> ART_PEND = new WeakHashMap<>();

    /** 文章页不显示红包挂件（沉浸模式开不开都一样）：挂件被抖音再设成可见时，setVisibility 钩子拦回去。 */
    static void articlePendant(boolean on) {
        for (View p : new ArrayList<>(PENDANTS.keySet())) {
            if (p == null) continue;
            if (on) {
                if (!ART_PEND.containsKey(p)) ART_PEND.put(p, p.getVisibility());
                if (p.getVisibility() == View.VISIBLE) p.setVisibility(View.INVISIBLE);
            } else if (ART_PEND.containsKey(p)) {
                int o = ART_PEND.remove(p);
                if (p.getVisibility() == View.INVISIBLE && o == View.VISIBLE && !IMM.containsKey(p)) p.setVisibility(View.VISIBLE);
            }
        }
    }

    static void immRestore() {
        for (View v : new ArrayList<>(IMM.keySet())) if (v != null) immUnhide(v);
        IMM.clear();
    }

    /** 系统状态栏：开着沉浸模式就藏起来（从屏幕顶部下拉仍能临时唤出），关掉再显示回来。 */
    static void immStatusBar(View root, boolean hide) {
        if (android.os.Build.VERSION.SDK_INT < 30) return;
        android.view.WindowInsetsController ic = root.getWindowInsetsController();
        if (ic == null) return;
        if (hide) {
            android.view.WindowInsets wi = root.getRootWindowInsets();
            if (wi != null && wi.isVisible(android.view.WindowInsets.Type.statusBars())) {
                ic.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                ic.hide(android.view.WindowInsets.Type.statusBars());
            }
            immStatusHidden = true;
        } else if (immStatusHidden) {
            ic.show(android.view.WindowInsets.Type.statusBars());
            immStatusHidden = false;
        }
    }

    /** 沉浸模式现在是否开着：模块里的开关（带 immersion_ts 时间戳）和抖音里双击/长按菜单的切换（imm_ovr_at 时间戳），谁新听谁的。抖音进程改不了模块的配置文件，靠这个才能在重开抖音后不被旧开关值“复活”。 */
    static boolean immOn() {
        if (immOvrAt < 0) {
            SharedPreferences pp = posPrefs();
            immOvrAt = pp.getLong("imm_ovr_at", 0);
            immOvr = pp.getBoolean("imm_ovr_on", false);
        }
        return immOvrAt > (sp == null ? 0 : sp.getLong("immersion_ts", 0)) ? immOvr : on("immersion", false);
    }

    /** 抖音里切换沉浸模式（双击快捷开关 / 长按菜单）：本地时间戳立即生效，同时通知模块把界面上的开关同步过去。 */
    static void immSet(boolean enable) {
        immOvrAt = System.currentTimeMillis();
        immOvr = enable;
        posPrefs().edit().putLong("imm_ovr_at", immOvrAt).putBoolean("imm_ovr_on", enable).apply();
        app().sendBroadcast(new Intent("com.dyhide.IMMERSION_SET").setPackage(MODULE).putExtra("on", enable));
        for (View r : new ArrayList<>(MAIN.keySet())) schedule(r);
    }

    /** 被扣下的“可能是双击第一下”：没等到第二下，就原样补发一次完整的点按（抖音照常处理单击）。 */
    static final Runnable IMM_REPLAY = () -> {
        if (!immPend) return;
        immPend = false;
        long t = SystemClock.uptimeMillis();
        immSynth = true;
        MotionEvent d = MotionEvent.obtain(t - 30, t - 30, MotionEvent.ACTION_DOWN, immPendX, immPendY, 0);
        immPendAct.dispatchTouchEvent(d);
        d.recycle();
        MotionEvent u = MotionEvent.obtain(t - 30, t, MotionEvent.ACTION_UP, immPendX, immPendY, 0);
        immPendAct.dispatchTouchEvent(u);
        u.recycle();
        immSynth = false;
        immLate = true;
    };

    /** 抖音长按菜单（LPPRoundedLinearLayout 那一组）里，在“倍速”那一项下面加一行“沉浸模式”开关（左边的图标、字体、分隔线都照着“倍速”那一项做）；模块里的“内置在抖音的长按菜单里”关掉就不加。 */
    static void lpMenu(ViewGroup g) {
        View item = null;
        TextView ref = null;
        int at = -1, mine = -1;
        for (int i = 0; i < g.getChildCount(); i++) {
            View ch = g.getChildAt(i);
            if ("dyhide_imm".equals(ch.getTag())) mine = i;
            else if (at < 0 && findText(ch, "倍速") instanceof TextView) {
                item = ch;
                ref = (TextView) findText(ch, "倍速");
                at = i;
            }
        }
        if (!on("imm_menu", false)) {
            if (mine >= 0) g.removeViewAt(mine);
            return;
        }
        if (mine >= 0) {
            FastSwitch existing = (FastSwitch) findByClass(g.getChildAt(mine), "FastSwitch", 0);
            if (existing != null) existing.setChecked(immOn());
            return;
        }
        if (at < 0) return;   // 这一组里没有“倍速”（菜单里别的组）
        View icon = findByClass(item, "LongPressPanelIconSmartCircleImageView", 0);
        if (icon == null || icon.getWidth() <= 0 || ref.getLeft() <= 0) return;
        Context ctx = g.getContext();
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(icon.getLeft(), 0, icon.getLeft(), 0);
        android.widget.ImageView iv = new android.widget.ImageView(ctx);
        iv.setImageDrawable(new ImmIcon(ref.getCurrentTextColor()));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(icon.getWidth(), icon.getHeight());
        ilp.rightMargin = ref.getLeft() - icon.getLeft() - icon.getWidth();
        row.addView(iv, ilp);
        TextView label = new TextView(ctx);
        label.setText("沉浸模式");
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, ref.getTextSize());
        label.setTextColor(ref.getCurrentTextColor());
        label.setTypeface(ref.getTypeface());
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
        final FastSwitch sw = new FastSwitch(ctx, ref.getCurrentTextColor() & 0x00FFFFFF | 0x40000000, immOn());
        sw.listener = MainHook::immSet;
        row.addView(sw);
        android.widget.FrameLayout cell = new android.widget.FrameLayout(ctx);
        cell.setTag("dyhide_imm");
        cell.addView(row, new android.widget.FrameLayout.LayoutParams(-1, -1));
        for (int i = 0; i < ((ViewGroup) item).getChildCount(); i++) {   // 分隔线：照“倍速”那一项里那条 1px 的 View 复制
            View d = ((ViewGroup) item).getChildAt(i);
            if (d.getClass() == View.class && d.getHeight() > 0 && d.getHeight() <= 3 && d.getBackground() != null) {
                View line = new View(ctx);
                line.setBackground(d.getBackground().getConstantState().newDrawable());
                android.widget.FrameLayout.LayoutParams llp = new android.widget.FrameLayout.LayoutParams(-1, d.getHeight(), Gravity.BOTTOM);
                llp.leftMargin = d.getLeft();
                cell.addView(line, llp);
                break;
            }
        }
        g.addView(cell, at + 1, new LinearLayout.LayoutParams(-1, item.getHeight()));
    }

    /** 自绘开关：滑块位置由自己的 270ms 动画驱动，不再用系统 Switch（它的滑块动画在 Android 17 上很慢，也改不动）。 */
    static final class FastSwitch extends View {
        static final android.animation.ArgbEvaluator ARGB = new android.animation.ArgbEvaluator();
        final float d = getResources().getDisplayMetrics().density;
        final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final int offColor;
        java.util.function.Consumer<Boolean> listener;
        boolean checked;
        float pos;   // 0 = 关，1 = 开
        android.animation.ValueAnimator anim;

        FastSwitch(Context ctx, int offColor, boolean checked) {
            super(ctx);
            this.offColor = offColor;
            this.checked = checked;
            pos = checked ? 1f : 0f;
            setOnClickListener(v -> {
                setChecked(!this.checked);
                if (listener != null) listener.accept(this.checked);
            });
        }

        /** 只改状态并播放动画，不触发监听。 */
        void setChecked(boolean on) {
            if (on == checked) return;
            checked = on;
            if (anim != null) anim.cancel();
            anim = android.animation.ValueAnimator.ofFloat(pos, on ? 1f : 0f);
            anim.setDuration(270L);
            anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                pos = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        @Override protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(46 * d), Math.round(28 * d));
        }

        @Override protected void onDraw(android.graphics.Canvas c) {
            float w = getWidth(), h = getHeight(), r = h / 2f;
            paint.setColor((Integer) ARGB.evaluate(pos, offColor, 0xFF34C759));
            c.drawRoundRect(0, 0, w, h, r, r, paint);
            paint.setColor(Color.WHITE);
            c.drawCircle(r + (w - 2 * r) * pos, r, r - 3 * d, paint);
        }
    }

    /** “沉浸模式”的菜单图标：四个角的取景框 + 中间一个小方块，线条粗细和颜色跟着菜单文字。 */
    static final class ImmIcon extends android.graphics.drawable.Drawable {
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        ImmIcon(int color) {
            p.setColor(color);
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        }

        @Override
        public void draw(android.graphics.Canvas c) {
            android.graphics.Rect r = getBounds();
            float s = Math.min(r.width(), r.height());
            float x = r.left + (r.width() - s) / 2f, y = r.top + (r.height() - s) / 2f;
            p.setStrokeWidth(s * 0.08f);
            float a = s * 0.16f, b = s * 0.84f, k = s * 0.30f;   // 取景框四角：每个角两条线
            float[][] cs = {{a, a, 1, 1}, {b, a, -1, 1}, {a, b, 1, -1}, {b, b, -1, -1}};
            for (float[] q : cs) {
                c.drawLine(x + q[0], y + q[1], x + q[0] + q[2] * k, y + q[1], p);
                c.drawLine(x + q[0], y + q[1], x + q[0], y + q[1] + q[3] * k, p);
            }
            c.drawRoundRect(x + s * 0.38f, y + s * 0.38f, x + s * 0.62f, y + s * 0.62f, s * 0.05f, s * 0.05f, p);
        }

        @Override public void setAlpha(int alpha) { p.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter cf) { p.setColorFilter(cf); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    static View findText(View v, String t) {
        if (v instanceof TextView && t.contentEquals(((TextView) v).getText())) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findText(g.getChildAt(i), t);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** 倍速提示（“下滑松手锁定 2 倍速”“快进中”）所在的整块平时是 GONE（扫描进不去），长按时抖音才把它设成可见：这里直接钻进 LayoutCheckFrameLayout 里 GONE 的那几块把提示提前藏好，不用等长按之后的下一次扫描。 */
    static void immHintScan(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View ch = g.getChildAt(i);
            if (ch instanceof ViewGroup && ch.getVisibility() == View.GONE) immHintFind(ch, 0);
        }
    }

    static void immHintFind(View v, int depth) {
        if (isSpeedSignalView(v)) {
            immApply(v, 2);
            return;
        }
        if (depth < 6 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) immHintFind(g.getChildAt(i), depth + 1);
        }
    }

    static void pruneSpeedGuides() {
        for (View v : new ArrayList<View>(SPEED_GUIDES.keySet())) {
            if (v == null || !speedSignalShown(v)) SPEED_GUIDES.remove(v);
        }
        if (speedPendantHidden && SPEED_GUIDES.isEmpty()) showPendantAfterSpeed();
    }

    static boolean on(String key, boolean def) {
        return sp == null ? def : sp.getBoolean(key, def);
    }

    static long scanCost;   // 上一次扫描用了多少毫秒：评论区这类控件很多的页面扫一次要很久，下一次就隔得更远，不去占着主线程

    static void schedule(final View root) {
        if (PENDING.containsKey(root)) return;
        PENDING.put(root, true);
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PENDING.remove(root);
                long t0 = SystemClock.uptimeMillis();
                try {
                    scan(root);
                    if (on("dump", false)) {   // 状态文件也只在调试开关打开时写：它原来每 5 秒在主线程写一次文件，会让视频隔几秒卡一下
                        status();
                        dump(root);
                    }
                } catch (Throwable t) { XposedBridge.log(t); }
                scanCost = SystemClock.uptimeMillis() - t0;
            }
        }, MAIN.containsKey(root) ? Math.max(hasLive(root, 0) ? 60 : 250, scanCost * 12) : 30);   // 直播间里元素多、变得快，扫得更勤   // Toast、弹出提示这类小窗口扫得更快，被隐藏的提示几乎不会先闪一下
    }

    static void scan(View root) {
        if (!root.isAttachedToWindow()) return;
        if (sp != null && sp.hasFileChanged()) {
            sp.reload();
            NOMATCH.clear();   // 开关变了：规则集合变了，指纹作废
        }
        Ctx c = new Ctx();
        c.sw = root.getResources().getDisplayMetrics().widthPixels;
        c.sh = root.getResources().getDisplayMetrics().heightPixels;
        c.density = root.getResources().getDisplayMetrics().density;
        c.nav = on("nav_transparent", true);
        c.center = on("center_tabs", true);
        c.extend = on("extend_feed", true);
        c.fit = on("fit_video", false);
        myName = sp == null ? "" : sp.getString("my_name", "").trim();
        c.overlay = !MAIN.containsKey(root);
        c.imm = !c.overlay && immOn();
        c.root = root;
        c.live = hasLive(root, 0);
        c.disc = on("r_右下角唱片", true);
        c.pendant = sp == null ? 1f : sp.getFloat("pendant_scale", 1f);
        for (Rules.R r : Rules.ALL) if (r.mode != Rules.MALL && on(r.key(), true)) c.rules.add(r);   // MALL 是按位置隐藏的，不走文字/类名匹配
        for (Rules.R r : Rules.FOLLOW) if (on(r.key(), true)) c.rules.add(r);
        scans++;
        lastRoot = root.getClass().getName();
        if (scans == 1) XposedBridge.log("DyHide: first scan, rules=" + c.rules.size());
        if (!c.nav) restoreNav();
        articleNow = false;
        walk(root, c);
        if (!c.overlay) immStatusBar(root, c.imm);
        if (!c.overlay) articlePendant(articleNow);
        if (!c.overlay && !c.imm && !IMM.isEmpty()) immRestore();   // 只有主窗口的扫描能决定“沉浸模式已关”；长按菜单这类弹窗窗口的扫描 imm 恒为 false，不能拿来还原，否则每扫一次顶部控件就闪出来一次
        if (!SHIFTED.isEmpty() && !(on(TAG_KEY, true) || on(MEN_KEY, true))) for (View sv : new ArrayList<View>(SHIFTED.keySet())) applyShift(sv, 0f);
        if (!TITLE_SHOWN.isEmpty() && !(on(TAG_KEY, true) || on(MEN_KEY, true))) for (TextView tv : new ArrayList<TextView>(TITLE_SHOWN.keySet())) titleScan(tv, false);
        if (MAIN.containsKey(root) && !c.tabs.isEmpty()) {
            lastTabs.clear();
            for (View t : c.tabs) lastTabs.add(new WeakReference<View>(t));
            selectVisibleTab(c.tabs);
        }
        boolean clearOn = false;
        for (Rules.R x : c.rules) clearOn |= x.mode == Rules.CLEAR;
        if (!clearOn) restoreBg();
    }

    /**
     * 返回第一条“匹配并且条件都满足”的规则。条件（直播窗口、veto、need、altNeed）必须在这里一并判断：
     * 否则文字相同的前一条规则匹配上但条件不满足时，会把后面真正适用的规则挡住（例如底部“热点”被顶部“热点”挡住）。
     */
    static Rules.R firstMatch(View v, Ctx c) {
        CharSequence t = viewText(v);
        CharSequence d = v.getContentDescription();
        String cls = v.getClass().getName();
        String id = Rules.NEED_ID ? Rules.idName(v) : null;
        for (Rules.R r : c.rules) {
            if ((r.overlayOnly && !c.overlay) || !r.matchView(v, cls, id, t, d)) continue;
            if (r.live ? !c.live : c.inLive > 0) continue;
            if (r.veto != null && ancestor(v, r.veto) != null) continue;
            if (r.skipMine && isMine(v)) continue;
            boolean viaAlt = r.altAnc != null && r.viaAlt(v, t, d);
            if (viaAlt && r.altNeed != null && ancestor(v, r.altNeed, 10) == null) {   // 文字命中了但不在要求的容器里（视频底部的“N人想去”地点卡片不在评论区）：改走按类名的常规路径
                if (!r.matchSel(v, cls, id, t, d)) continue;
                viaAlt = false;
            }
            if (viaAlt) {
                if (r.altNeed != null && ancestor(v, r.altNeed, 10) == null) continue;
            } else if (r.closes && r.viaAlt(v, t, d) && DIALOG.containsKey(c.root)) {
                return r;   // 对话框里靠文字命中：直接关掉，不看 need
            } else if (r.need != null && ancestor(v, r.need, r.depth) == null) {
                continue;
            }
            return r;
        }
        return null;
    }

    /** 向上最多 6 层找祖先：suffix 是类名结尾，或 "#"+资源ID名。 */
    static View ancestor(View v, String suffix) {
        return ancestor(v, suffix, 6);
    }

    static View ancestor(View v, String suffix, int depth) {
        boolean byId = suffix.charAt(0) == '#';
        ViewParent p = v.getParent();
        for (int i = 0; i < depth && p instanceof View; i++, p = p.getParent()) {
            if (byId ? suffix.substring(1).equals(Rules.idName((View) p)) : p.getClass().getName().endsWith(suffix)) return (View) p;
        }
        return null;
    }

    /**
     * 抖音搜索页的“猜你想搜”由 Lynx 渲染，文字节点不是 TextView；
     * 对 Lynx 节点补读无障碍节点文本，普通 View 仍走原来的轻量路径。
     */
    static CharSequence viewText(View v) {
        if (v instanceof TextView) return ((TextView) v).getText();
        String name = v.getClass().getName();
        if (!name.startsWith("com.lynx.tasm.")) return null;
        AccessibilityNodeInfo info = null;
        try {
            info = v.createAccessibilityNodeInfo();
            if (info == null) return null;
            CharSequence value = info.getText();
            if (value == null || value.length() == 0) value = info.getContentDescription();
            return value;
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (info != null) try { info.recycle(); } catch (Throwable ignored) { }
        }
    }

    static void walk(View v, Ctx c) {
        String cn = v.getClass().getName();
        // 首次扫描时也要识别已经处于 VISIBLE 的提示，不能只依赖后续 setVisibility 回调。
        pruneSpeedGuides();
        if (isSpeedSignalView(v)) {
            if (c.imm) immApply(v, 2);   // 底部“下滑松手锁定 2 倍速”这类提示：沉浸模式下不显示（功能不受影响）
            if (speedSignalShown(v)) {
                SPEED_GUIDES.put(v, true);
                hidePendantForSpeed();
            } else {
                SPEED_GUIDES.remove(v);
                pruneSpeedGuides();
            }
        }
        if (cn.endsWith("DynamicWrapperView") && v.getParent() != null && v.getParent().getClass().getName().endsWith("SearchMiddlePageRecyclerView")) clipGuess(v);
        if (cn.endsWith("BottomSpace")) fixSpace(v, c);
        if (c.nav && v.getClass() == View.class && !NAV_BG.containsKey(v) && v.getParent() instanceof ViewGroup && v.getWidth() >= c.sw * 0.9f
                && v.getHeight() >= c.sw * 0.05f && v.getHeight() <= c.sw * 0.2f && v.getBottom() >= ((ViewGroup) v.getParent()).getHeight() - 4) {   // 紧贴窗口底边、整宽、和底栏差不多高的纯 View：底栏的背景垫片，和底栏容器里的背景图一样处理
            NAV_BG.put(v, v.getVisibility());
            if (v.getVisibility() == View.VISIBLE) {
                v.setVisibility(View.INVISIBLE);
                navFixed++;
            }
        }
        if (v instanceof ViewGroup && ((ViewGroup) v).getChildCount() == 10) mallGrid((ViewGroup) v);
        if (cn.endsWith("CoinPendantView")) pendant(v, c);
        if (!c.overlay && cn.endsWith("MonitorScrollFrameLayout")) {
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            if (v.getHeight() > 0 && Math.abs(loc[1]) < v.getHeight() / 2) {   // 当前屏幕上的这一页
                View lynx = findByClass(v, "AnnieXLynxView", 0);
                if (lynx != null && lynx.isShown()) articleNow = true;
            }
        }
        if (c.imm) immHide(v, cn);
        if (c.imm && cn.endsWith("LayoutCheckFrameLayout")) immHintScan((ViewGroup) v);
        if (c.overlay && cn.endsWith("LPPRoundedLinearLayout")) lpMenu((ViewGroup) v);
        if (cn.endsWith("HomeTopTabItemViewNew")) {
            c.tabs.add(v);
            tabCls = v.getClass();
        }
        if (v.getVisibility() == View.GONE) {
            WeakReference<View> w = HIDDEN.get(v);
            if (w == null) return;
            View src = w.get();
            Rules.R still = src == null ? null : firstMatch(src, c);
            if (still != null && still.mode != Rules.TAGS && still.mode != Rules.MENTION && !"猜你想搜".equals(still.label)) return;   // 视频标签、猜你想搜这两条规则自己不隐藏控件：它们命中不能算“还该隐藏”，否则关掉视频文案后，已收起的文案区一直不恢复
            // 来源文字已变化（控件被复用）或规则被关闭：恢复显示
            HIDDEN.remove(v);
            int[] size = SIZE.remove(v);
            if (size != null) {
                ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                lp.width = size[0];
                lp.height = size[1];
                lp.setMargins(size[2], size[3], size[4], size[5]);
                v.setLayoutParams(lp);
            }
            v.setVisibility(View.VISIBLE);
            reattachImages(v);
            if (cn.endsWith("FeedDescRootLayout")) rebindDesc(v);
        }
        Rules.R r;
        CharSequence mt = viewText(v), md = v.getContentDescription();
        int key = 31 * (31 * (31 * (31 * (mt == null ? 0 : mt.toString().hashCode()) + (md == null ? 0 : md.toString().hashCode())) + ctxSig(v)) + (c.live ? 1 : 0)) + (c.inLive > 0 ? 2 : 0) + (c.overlay ? 4 : 0);
        Integer seen = NOMATCH.get(v);
        if (seen != null && seen == key) {
            r = null;
        } else {
            r = firstMatch(v, c);
            if (r == null) NOMATCH.put(v, key);
        }
        if (r != null && "猜你想搜".equals(r.label)) r = null;   // 它只靠 clipGuess 裁掉，不能再把整个区块（含历史记录）隐藏
        if (r != null && (r.mode == Rules.TAGS || r.mode == Rules.MENTION)) {
            titleScan(v, true);
            if (v instanceof TextView) shiftDesc((TextView) v);
            r = null;
        }
        if (r != null && r.live && !c.live) r = null;
        if (r != null && !r.live && c.inLive > 0) r = null;
        CharSequence vt = viewText(v);
        boolean alt = r != null && r.altAnc != null && r.viaAlt(v, vt, v.getContentDescription());   // 靠 or(...) 的文字命中，走另一条定位路径
        if (alt && r.altNeed != null && ancestor(v, r.altNeed, 10) == null) alt = false;   // 不在要求的容器里（比如不是评论区）：不走这条路径，firstMatch 已按常规路径判定过
        if (r != null && r.veto != null && ancestor(v, r.veto) != null) r = null;
        if (r != null && (r.mode == Rules.DISMISS || (r.closes && r.viaAlt(v, vt, v.getContentDescription()))) && v.getHeight() > 0) {   // 靠文字命中的控件在对话框里：直接关掉对话框（只认文字，不认 sel，免得误关别的对话框）
            WeakReference<Dialog> w = DIALOG.get(c.root);
            final Dialog d = w == null ? null : w.get();
            if (d != null) {
                c.root.setAlpha(0f);   // 先让它看不见，再关
                matched++;
                handler().post(new Runnable() {
                    @Override
                    public void run() { d.dismiss(); }
                });
                return;
            }
            if (r.mode == Rules.DISMISS) r = null;
        }
        if (r != null && !alt && r.need != null && ancestor(v, r.need, r.depth) == null) r = null;
        if (r != null && r.mode == Rules.CLEARUP) {   // 清掉最近的 anc 祖先（和它同类的父容器）的背景，继续往下扫
            View b = ancestor(v, r.anc, r.depth);
            if (b != null) {
                clearBg(b);
                if (b.getParent() instanceof View && b.getParent().getClass().getName().endsWith(r.anc)) clearBg((View) b.getParent());
            }
            r = null;
        }
        if (r != null && r.mode == Rules.CLEAR) {   // 只清背景，继续往下扫
            if (alt) {   // 靠文字命中（合集条的各种样式）：从最近的 anc 祖先起，整棵栏里所有整宽的背景层都清掉
                View bar = ancestor(v, r.altAnc, r.depth);
                if (bar != null) clearTree(bar, bar.getWidth(), 0);
            } else {
                clearBg(v);
            }
            r = null;
        }
        if (r != null && r.mode == Rules.ROOT) {   // 整个提示窗口：透明并挪到屏幕外（不改可见性，免得窗口重新布局跑到屏幕上方）；Activity 自己的窗口永远不动
            if (!MAIN.containsKey(c.root) && blocked(c.root) && c.root.getTranslationX() > -10000f) {
                c.root.setAlpha(0f);
                c.root.setTranslationX(-20000f);
                matched++;
            }
            return;
        }
        View target = null;
        if (r != null && r.mode != Rules.DISMISS && (r.mode == Rules.TEXT_ONLY || v.getHeight() > 0)) {
            View up = !alt ? null : "@poi".equals(r.altAnc) ? poiBox(v, c) : ancestor(v, r.altAnc, r.depth);
            target = alt ? (up != null ? up : v) : climb(v, r, c);
            if (target != null && touchesSearch(target)) target = null;   // 搜索框永远不隐藏
        }
        if (target != null) {
            matched++;
            HIDDEN.put(target, new WeakReference<View>(v));
            if (target.getVisibility() != View.GONE) {
                target.setVisibility(View.GONE);
                // RecyclerView 里的条目 GONE 后仍会占位（宽高 + 条目间距），需要把宽高和间距都收成 0，否则后面的条目会被推偏
                if (isRecycler(target.getParent()) && target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) target.getLayoutParams();
                    int[] d = decor(target);
                    SIZE.put(target, new int[]{lp.width, lp.height, lp.leftMargin, lp.topMargin, lp.rightMargin, lp.bottomMargin});
                    lp.width = 0;
                    lp.height = 0;
                    lp.setMargins(-d[0], -d[1], -d[2], -d[3]);   // 外边距 + 分隔装饰 = 0
                    target.setLayoutParams(lp);
                }
            }
            return;
        }
        if (v instanceof ViewGroup) {
            if (c.nav && cn.endsWith("MainBottomTabContainer")) fixNav((ViewGroup) v, c, 0);
            ViewGroup g = (ViewGroup) v;
            boolean liveCls = (cn.contains(".live.") && !cn.endsWith("MaxWidthLinearLayout")) || cn.contains("LiveSub") || cn.contains("LiveMeasure") || cn.endsWith("LiveFrameLayout");
            if (liveCls) c.inLive++;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c);
            if (liveCls) c.inLive--;
            if (v instanceof GridLayout) reflowGrid((GridLayout) v);
            if (cn.endsWith("MainTabStripScrollView")) centerTabs(v, c);
            if (cn.endsWith("FeedRightScaleView")) shiftColumn(v, c);
            if (cn.endsWith("VideoPinchViewContainer")) fitVideo(g, c);
        }
    }

    static String myName = "";

    /** 控件所在容器链（最多 6 层）的指纹：need / altNeed 都看容器，换了容器“没命中”的缓存就要作废。 */
    static int ctxSig(View v) {
        int h = 0;
        ViewParent p = v.getParent();
        for (int i = 0; i < 6 && p instanceof View; i++, p = p.getParent()) h = 31 * h + System.identityHashCode(p.getClass());
        return h;
    }

    /** 这个控件（含子孙）里有没有文字包含“我的昵称”。 */
    static boolean isMine(View v) {
        if (myName.isEmpty()) return false;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.toString().contains(myName)) return true;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (isMine(g.getChildAt(i))) return true;
        }
        return false;
    }

    /** 顶部标签项现在是不是选中状态（选中时抖音会把描述改成“已选中，xx，按钮”）。 */
    static boolean selected(View tab) {
        CharSequence d = tab.getContentDescription();
        return tab.isSelected() || (d != null && d.toString().startsWith("已选中"));
    }

    static int prevSel = -1;
    static Class<?> tabCls;
    static final List<WeakReference<View>> lastTabs = new ArrayList<>();

    /** 顶部标签项被选中的瞬间（刚滑进某一页）：选中的是被隐藏的，就跳到下一个没被隐藏的；否则记下当前页。 */
    static void onTabSelected(final View tab) {
        int idx = -1;
        for (int i = 0; i < lastTabs.size(); i++) if (lastTabs.get(i).get() == tab) { idx = i; break; }
        if (idx < 0) return;
        if (!HIDDEN.containsKey(tab)) {
            prevSel = idx;
            return;
        }
        int dir = prevSel >= 0 && idx < prevSel ? -1 : 1;   // 从哪个方向滑进来的，就继续往那个方向找
        int to = idx + dir;
        while (to >= 0 && to < lastTabs.size() && (lastTabs.get(to).get() == null || HIDDEN.containsKey(lastTabs.get(to).get()))) to += dir;
        if (to < 0 || to >= lastTabs.size()) return;
        final View target = lastTabs.get(to).get();
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (selected(tab) && target != null) target.performClick();   // 等松手、翻页落定后再点，避免和手势打架
            }
        }, 150);
    }

    /**
     * 隐藏了顶部「直播」等标签后，左右滑动仍会滑进被隐藏的那一页。每次扫描看一下当前选中的顶部标签：
     * 如果选中的是被隐藏的，就顺着刚才滑动的方向点一下下一个没被隐藏的标签（等同于用手点它），
     * 这样不用碰抖音的 ViewPager 内部实现。
     */
    static void selectVisibleTab(List<View> tabs) {
        int sel = -1;
        for (int i = 0; i < tabs.size(); i++) if (selected(tabs.get(i))) { sel = i; break; }
        if (sel < 0) return;
        if (!HIDDEN.containsKey(tabs.get(sel))) {
            prevSel = sel;
            return;
        }
        int dir = prevSel >= 0 && sel < prevSel ? -1 : 1;
        int to = sel + dir;
        while (to >= 0 && to < tabs.size() && HIDDEN.containsKey(tabs.get(to))) to += dir;
        if (to < 0 || to >= tabs.size()) return;
        final View target = tabs.get(to);
        handler().post(new Runnable() {
            @Override
            public void run() { target.performClick(); }
        });
    }

    static final Map<View, int[]> FITS = new WeakHashMap<>();   // 被我们改过布局尺寸的视频画面 → {改后宽, 改后高, 抖音原来的 LayoutParams 宽, 高, 抖音原来的实际宽, 高}
    static final Map<View, Boolean> FIT_LISTENED = new WeakHashMap<>();
    static final Map<View, Boolean> DUMP_LATER = new WeakHashMap<>();

    /**
     * 9:16 视频不裁切：抖音把画面布局得比容器还宽（居中，左右被裁），这里把它的布局尺寸改成宽度刚好等于容器、高度按原比例算（居中，上下留黑边）。
     * 画面是 SurfaceView，不能用缩放做：后台切回前台后，它的合成层会按“缩放前、被窗口裁掉两边之后”的区域取画面再缩放，
     * ViewDump 里缩放和位置都对，实际却只显示中间 1272 宽的内容、两边留黑。直接改布局尺寸，画面不做任何变换，就没有这个问题。
     */
    static void fitVideo(ViewGroup box, Ctx c) {
        for (int i = 0; i < box.getChildCount(); i++) {
            View vid = box.getChildAt(i);
            if (vid.getWidth() == 0 || vid.getHeight() == 0) continue;
            if (FIT_LISTENED.put(vid, true) == null) {
                vid.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {   // 抖音重排画面后马上改回来，不等下一次扫描
                    if (on("fit_video", false)) v.post(() -> { if (v.getParent() instanceof View) fitNow(v, (View) v.getParent()); });
                });
            }
            if (c.fit) fitNow(vid, box); else releaseFit(vid);
        }
    }

    /** 容器处于缩放动画时不动。画面不是 9:16、或本来就不比容器宽（抖音自己布局成适配宽度）时，撤掉我们改过的尺寸。 */
    static void fitNow(View vid, View box) {
        int target = box.getWidth();
        ViewGroup.LayoutParams lp = vid.getLayoutParams();
        if (target <= 0 || lp == null || Math.abs(box.getScaleX() - 1f) > 0.001f) return;
        int[] own = FITS.get(vid);
        boolean ours = own != null && lp.width == own[0] && lp.height == own[1];   // 布局参数还是我们设的
        int w = ours ? own[4] : vid.getWidth(), h = ours ? own[5] : vid.getHeight();   // 抖音原本给它的尺寸
        if (w == 0 || h == 0) return;
        if (Math.abs((float) w / h - 9f / 16f) >= 0.012f || w <= target + 2) {
            releaseFit(vid);
            return;
        }
        int fw = target, fh = Math.round((float) h * target / w);
        if (ours && own[0] == fw && own[1] == fh) return;
        FITS.put(vid, new int[]{fw, fh, ours ? own[2] : lp.width, ours ? own[3] : lp.height, w, h});
        lp.width = fw;
        lp.height = fh;
        vid.setLayoutParams(lp);
    }

    static void releaseFit(View vid) {
        int[] own = FITS.remove(vid);
        if (own == null) return;
        ViewGroup.LayoutParams lp = vid.getLayoutParams();
        if (lp != null && lp.width == own[0] && lp.height == own[1]) {   // 还是我们设的才改回去；抖音已经换了新尺寸就不动
            lp.width = own[2];
            lp.height = own[3];
            vid.setLayoutParams(lp);
        }
    }

    /**
     * 地点卡片（评论区上方“城市 | 地点名”、或“N万人打卡”那种）整块的范围：从命中的文字往上，
     * 取“宽度不到屏幕 90%、高度不到屏幕 25%”的最大一层。上到评论列表那一层（整宽）就停，
     * 所以收掉的正好是卡片本身，不会把整个评论区也抹掉。
     */
    static View poiBox(View v, Ctx c) {
        View best = v;
        ViewParent q = v.getParent();
        for (int i = 0; i < 8 && q instanceof View; i++) {
            View a = (View) q;
            if (a.getWidth() > c.sw * 0.9f || a.getHeight() > c.sh * 0.25f) break;
            best = a;
            q = a.getParent();
        }
        // 评论区地点卡片左边的小图标：和文字是同一父容器里的兄弟。评论区刚展开时容器宽度还没定，上面的宽度限制会提前停在文字这一层，图标就剩下了；
        // 所以只要同一父容器里其余兄弟都没有文字（只有图标），就连父容器一起收。
        for (int i = 0; i < 3 && best.getParent() instanceof ViewGroup; i++) {
            ViewGroup p = (ViewGroup) best.getParent();
            if (p.getHeight() > c.sh * 0.25f || p.getChildCount() > 3) break;
            boolean iconsOnly = true;
            for (int k = 0; k < p.getChildCount() && iconsOnly; k++) iconsOnly = p.getChildAt(k) == best || !hasAnyText(p.getChildAt(k));
            if (!iconsOnly) break;
            best = p;
        }
        return best;
    }

    static boolean hasAnyText(View v) {
        if (v instanceof TextView && ((TextView) v).getText().length() > 0) return true;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasAnyText(g.getChildAt(i))) return true;
        }
        return false;
    }


    static boolean has(View v, String cls, int depth) {
        if (v.getClass().getName().contains(cls)) return true;
        if (depth < 30 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (has(g.getChildAt(i), cls, depth + 1)) return true;
        }
        return false;
    }

    /** 窗口是不是直播间：最上面 3 层里有直播的根容器（LiveFrameLayout）。首页里的“直播”标签页不算——它的外层是普通容器。 */
    static boolean hasLive(View v, int depth) {
        if (v.getClass().getName().endsWith("LiveFrameLayout")) return true;
        if (depth < 3 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasLive(g.getChildAt(i), depth + 1)) return true;
        }
        return false;
    }

    /**
     * 整个窗口里有没有已开启的“整窗隐藏”规则要隐藏的文字（Toast / 弹出提示 / 对话框式提示），并且它是个小提示：
     * 窗口里的文字不超过 3 段（提示文字 + “撤销/去看看”）。文字更多的是带选项的面板（比如“已取消推荐”后让你选原因的面板），整窗收掉就点不进去了。
     */
    static boolean blocked(View v) {
        int[] texts = {0};
        return hitTip(v, texts) && texts[0] <= 3;
    }

    static boolean hitTip(View v, int[] texts) {
        boolean hit = false;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.length() > 0) {
                texts[0]++;
                for (Rules.R r : Rules.ALL) if (r.mode == Rules.ROOT && on(r.key(), true) && r.textHit(t)) hit = true;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) hit |= hitTip(g.getChildAt(i), texts);
        }
        return hit;
    }

    /** 父容器是（或继承自）RecyclerView：类名里带 RecyclerView 即可。 */
    /** 子孙里可见（不含被收起的）的文字段数，到 2 就不再数。 */
    static int visibleTexts(View v) {
        if (v.getVisibility() != View.VISIBLE) return 0;
        int n = v instanceof TextView && ((TextView) v).getText().length() > 0 ? 1 : 0;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && n < 2; i++) n += visibleTexts(g.getChildAt(i));
        }
        return n;
    }

    /** 被收起期间绑定的图片（比如右下角唱片的封面）视图是 GONE、尺寸为 0，没有加载；恢复显示后让里面的图片控件重新挂接一次，重新加载。 */
    static void reattachImages(View v) {
        if (v instanceof android.widget.ImageView) {
            v.onStartTemporaryDetach();
            v.onFinishTemporaryDetach();
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) reattachImages(g.getChildAt(i));
        }
    }

    static boolean isRecycler(ViewParent p) {
        for (Class<?> k = p.getClass(); k != null; k = k.getSuperclass()) if (k.getName().contains("RecyclerView")) return true;
        return false;
    }

    /** 目标本身是搜索框（输入框 / id 含 search），或里面包着搜索框：不隐藏。 */
    static boolean touchesSearch(View t) {
        String id = Rules.idName(t);
        if (t instanceof android.widget.EditText || (id != null && id.toLowerCase().contains("search"))) return true;
        if (t instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) t;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch.getVisibility() != View.GONE && touchesSearch(ch)) return true;
            }
        }
        return false;
    }

    // ---------- 找到“整个入口”并隐藏 ----------
    static View climb(View v, Rules.R r, Ctx c) {
        if (r.mode == Rules.TEXT_ONLY) return v;
        if (r.mode == Rules.BOX) {   // 往上取宽、高都不超限的最大祖先：整张卡片 / 整个图标格子
            View best = v, safe = null;
            ViewParent q = v.getParent();
            for (int i = 0; i < 12 && q instanceof View; i++) {
                View a = (View) q;
                if (a.getWidth() > c.sw * r.bw || a.getHeight() > c.sh * r.bh || (r.single && visibleTexts(a) > 1)) break;
                best = a;
                if (!touchesSearch(a)) safe = a;   // 一路往上，记住“不含搜索框”的最大那一层：往里取到搜索框整块就不会被抹掉
                if (isRecycler(a.getParent())) break;   // 到列表条目的根就停，整条内容一起收，不碰整个列表
                q = a.getParent();
            }
            return safe != null ? safe : best;
        }
        if (r.mode == Rules.PARENT) {   // 按类名找到 anc，隐藏它的父容器
            View a = ancestor(v, r.anc, r.depth);
            if (a != null && a.getParent() instanceof View) return (View) a.getParent();
        }
        if (r.mode == Rules.CHILD) {   // 广告/汽水听栏：只收掉 MeasureOnceFrameLayout 下包着它的那一块，同栏的相关搜索、合集条不受影响
            View bar = ancestor(v, r.anc, r.depth);
            if (bar != null) {
                View x = v;
                while (x.getParent() != bar) x = (View) x.getParent();
                return x;
            }
        }
        if (r.mode == Rules.CARD) {   // 整张卡片：最近的 MeasureOnceFrameLayout；它的外层如果只装着它，连外层一起收掉，不留空位
            View card = ancestor(v, "MeasureOnceFrameLayout", r.depth);
            if (card != null && card.getHeight() < c.sh * 0.3f) {
                if (card.getParent() instanceof ViewGroup && ((ViewGroup) card.getParent()).getChildCount() == 1
                        && ((View) card.getParent()).getHeight() <= card.getHeight() + 8 * c.density) return (View) card.getParent();
                return card;
            }
        }
        // UP：指定祖先；长按菜单里的条目：隐藏整行（图标+文字+分隔线）
        View up = ancestor(v, r.mode == Rules.UP ? r.anc : "LongPressPanelCommonItemView");
        if (up != null) return up;
        if (r.mode == Rules.UP) return v;
        // 常用功能这类系统 GridLayout：隐藏整个单元（图标+文字）
        View cell = v;
        for (int i = 0; i < 4 && cell.getParent() instanceof ViewGroup; i++) {
            if (cell.getParent() instanceof GridLayout) return cell;
            cell = (View) cell.getParent();
        }
        int h = v.getHeight();
        View cur = v;
        for (int i = 0; i < 4 && cur.getParent() instanceof ViewGroup; i++) {
            ViewGroup g = (ViewGroup) cur.getParent();
            String n = g.getClass().getName();
            if (n.contains("RecyclerView") || n.contains("ScrollView") || n.contains("ViewPager")
                    || n.contains("CardModuleView") || n.contains("RoundedFrameLayout")
                    || g instanceof android.widget.AbsListView) break;
            int same = 0, kids = 0;
            for (int k = 0; k < g.getChildCount(); k++) {
                View ch = g.getChildAt(k);
                if (ch.getVisibility() == View.GONE) continue;
                kids++;
                if (ch.getClass() == cur.getClass()) same++;   // cur 已经是列表里的一项
            }
            if (same >= 2 || kids > 3 || g.getWidth() > c.sw * 0.9f || g.getHeight() > h * 3.5f + 16 * c.density) break;
            cur = g;
        }
        return cur;
    }

    /** 清掉控件及与它同高的父容器、与它同宽的子容器的背景（按钮等内部小控件的背景保留）。 */
    static void clearTree(View v, int barWidth, int depth) {
        if (v.getWidth() >= barWidth * 0.85f) strip(v);
        if (depth < 5 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch.getVisibility() != View.GONE && ch.getWidth() >= barWidth * 0.85f) clearTree(ch, barWidth, depth + 1);
            }
        }
    }

    static void clearBg(View v) {
        strip(v);
        if (v.getParent() instanceof View && ((View) v.getParent()).getHeight() <= v.getHeight() * 1.5f) strip((View) v.getParent());
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (g.getChildAt(i).getWidth() >= v.getWidth() * 0.9f) strip(g.getChildAt(i));
            }
        }
    }

    static void strip(View x) {
        Drawable b = x.getBackground();
        if (b != null) {
            BG_ORIG.put(x, b);
            x.setBackground(null);
        }
    }

    static void restoreBg() {
        for (Map.Entry<View, Drawable> e : new ArrayList<>(BG_ORIG.entrySet())) e.getKey().setBackground(e.getValue());
        BG_ORIG.clear();
    }

    static boolean hasDesc(View v, String d) {
        if (v.getVisibility() != View.VISIBLE) return false;
        if (d.contentEquals(String.valueOf(v.getContentDescription()))) return true;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasDesc(g.getChildAt(i), d)) return true;
        }
        return false;
    }

    /** 右侧点赞/评论/收藏/分享一列：唱片行隐藏后，整体下移该行的高度，补上空位。 */
    static void shiftColumn(View col, Ctx c) {
        float dy = 0f;
        if (c.disc) {
            ViewGroup p = (ViewGroup) col.getParent();
            for (int i = 0; i < p.getChildCount(); i++) {
                View s = p.getChildAt(i);
                // 唱片行里是"听抖音"按钮（占着原来的位置）时，不下移
                if (s.getClass().getName().endsWith("FpsControlFrameLayout") && !hasDesc(s, "听抖音")) dy = s.getHeight();
            }
        }
        if (col.getTranslationY() != dy) col.setTranslationY(dy);
    }

    // ---------- 网格重排：隐藏后把剩下的单元顺序补位 ----------
    static GridLayout.Spec specAt(GridLayout.Spec old, int start) {
        GridLayout.Alignment a = (GridLayout.Alignment) XposedHelpers.getObjectField(old, "alignment");
        return GridLayout.spec(start, 1, a, XposedHelpers.getFloatField(old, "weight"));
    }

    static void reflowGrid(GridLayout g) {
        int cols = g.getColumnCount();
        if (cols <= 0) return;
        int n = g.getChildCount();
        boolean any = false;
        StringBuilder sig = new StringBuilder();
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            if (HIDDEN.containsKey(ch)) any = true;
            sig.append(ch.getVisibility() == View.GONE ? '0' : '1');
        }
        String now = any ? sig.toString() : "";
        String prev = GRID_SIG.get(g);
        if (now.equals(prev == null ? "" : prev)) return;
        GRID_SIG.put(g, now);
        gridFixed++;
        int k = 0;
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) ch.getLayoutParams();
            if (!any) {
                Object[] o = ORIG_SPECS.remove(ch);
                if (o != null) {
                    lp.rowSpec = (GridLayout.Spec) o[0];
                    lp.columnSpec = (GridLayout.Spec) o[1];
                    ch.setLayoutParams(lp);
                }
                continue;
            }
            if (ch.getVisibility() == View.GONE) continue;
            if (!ORIG_SPECS.containsKey(ch)) ORIG_SPECS.put(ch, new Object[]{lp.rowSpec, lp.columnSpec});
            lp.rowSpec = specAt(lp.rowSpec, k / cols);
            lp.columnSpec = specAt(lp.columnSpec, k % cols);
            ch.setLayoutParams(lp);
            k++;
        }
    }

    // ---------- 顶部标签：隐藏后剩下的居中 ----------
    static void centerTabs(View strip, Ctx c) {
        ViewGroup rl = (ViewGroup) ((ViewGroup) strip).getChildAt(0);
        boolean anyHidden = false;
        int minL = Integer.MAX_VALUE, maxR = Integer.MIN_VALUE;
        int[] loc = new int[2];
        for (int i = 0; i < rl.getChildCount(); i++) {
            View it = rl.getChildAt(i);
            if (!it.getClass().getName().contains("TabItem")) continue;
            if (it.getVisibility() == View.GONE) {
                anyHidden |= HIDDEN.containsKey(it);
            } else if (it.getWidth() > 0) {
                it.getLocationOnScreen(loc);
                minL = Math.min(minL, loc[0]);
                maxR = Math.max(maxR, loc[0] + it.getWidth());
            }
        }
        if (!c.center || !anyHidden || minL == Integer.MAX_VALUE) {
            if (CENTERED.remove(strip) != null) strip.setTranslationX(0f);
            return;
        }
        View bar = strip;
        for (int i = 0; i < 6 && bar.getParent() instanceof View; i++) {
            bar = (View) bar.getParent();
            if (bar.getClass().getName().endsWith("MainTitleBar")) break;
        }
        int[] bl = new int[2];
        bar.getLocationOnScreen(bl);
        float d = (bl[0] + bar.getWidth() / 2f) - (minL + maxR) / 2f;
        if (Math.abs(d) > 2f) {
            strip.setTranslationX(strip.getTranslationX() + d);
            CENTERED.put(strip, true);
            centerFixed++;
        }
    }

    // ---------- 底栏透明：容器背景清空，背景图/分割线设为 INVISIBLE（并拦截抖音重新设回可见/背景） ----------
    static void fixNav(ViewGroup g, Ctx c, int depth) {
        stripNav(g);
        for (int i = 0; i < g.getChildCount(); i++) {
            View ch = g.getChildAt(i);
            String n = ch.getClass().getName();
            if (n.endsWith("BottomTab") || n.endsWith("PublishButton")) continue;   // 图标和文字保持不透明
            if (ch instanceof ViewGroup) {
                if (depth < 4) fixNav((ViewGroup) ch, c, depth + 1);
            } else if (ch.getVisibility() == View.VISIBLE && ch.getWidth() >= c.sw * 0.9f) {
                NAV_BG.put(ch, View.VISIBLE);
                ch.setVisibility(View.INVISIBLE);
                navFixed++;
            }
        }
    }

    static void stripNav(View x) {
        if (NAV_PAR.containsKey(x)) return;
        Drawable b = x.getBackground();
        NAV_PAR.put(x, b);   // 没有背景的容器也登记，抖音之后再设背景时同样会被拦住
        if (b != null) {
            x.setBackground(null);
            navFixed++;
        }
    }

    static void restoreNav() {
        for (View x : new ArrayList<View>(NAV_BG.keySet())) {
            Integer o = NAV_BG.remove(x);
            if (o != null) x.setVisibility(o);
        }
        for (Map.Entry<View, Drawable> e : new ArrayList<>(NAV_PAR.entrySet())) {
            NAV_PAR.remove(e.getKey());
            e.getKey().setBackground(e.getValue());
        }
    }

    // ---------- 红包挂件缩放（贴哪边就以哪边的中点为轴，缩放后仍贴边） ----------
    /** 红包挂件拖拽状态：downRawX, downRawY, 按下时 translationX, translationY, 是否正在拖。 */
    static final Map<View, float[]> DRAG = new WeakHashMap<>();
    static float[] savedPos;   // 拖放后挂件左上角在父容器里的绝对位置 x、y；null = 没拖过，保持抖音原位置（用绝对位置：抖音把挂件的布局位置挪动后也能原样放回去）

    static Context app() {
        return (Application) XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
    }

    static SharedPreferences posPrefs() {
        return app().getSharedPreferences("dyhide_pendant", Context.MODE_PRIVATE);
    }

    /** 拖拽钩子：挂件被手指拖动超过 touch slop 后，改为跟手移动并吃掉后续事件；没拖动的点按照常交给抖音。 */
    static void hookPendantDrag() {
        XposedBridge.hookMethod(XposedHelpers.findMethodExact(ViewGroup.class, "dispatchTouchEvent", MotionEvent.class), new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) throws Throwable {
                float[] s = DRAG.get(p.thisObject);
                if (s == null) return;
                View v = (View) p.thisObject;
                MotionEvent e = (MotionEvent) p.args[0];
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    s[0] = e.getRawX();
                    s[1] = e.getRawY();
                    s[2] = v.getTranslationX();
                    s[3] = v.getTranslationY();
                    s[4] = 0f;
                    return;
                }
                if (a == MotionEvent.ACTION_MOVE && s[4] == 0f
                        && Math.hypot(e.getRawX() - s[0], e.getRawY() - s[1]) > ViewConfiguration.get(v.getContext()).getScaledTouchSlop()) {
                    s[4] = 1f;
                    MotionEvent cancel = MotionEvent.obtain(e);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    ViewGroup g = (ViewGroup) v;
                    for (int i = 0; i < g.getChildCount(); i++) g.getChildAt(i).dispatchTouchEvent(cancel);   // 让挂件里的按钮放弃这次点按
                    cancel.recycle();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (s[4] == 0f) return;
                if (a == MotionEvent.ACTION_MOVE) {
                    View par = (View) v.getParent();
                    float tx = Math.max(-v.getLeft(), Math.min(par.getWidth() - v.getWidth() - v.getLeft(), s[2] + e.getRawX() - s[0]));
                    float ty = Math.max(-v.getTop(), Math.min(par.getHeight() - v.getHeight() - v.getTop(), s[3] + e.getRawY() - s[1]));
                    v.setTranslationX(tx);
                    v.setTranslationY(ty);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    s[4] = 0f;
                    savedPos = new float[]{v.getLeft() + v.getTranslationX(), v.getTop() + v.getTranslationY()};
                    posPrefs().edit().putFloat("ax", savedPos[0]).putFloat("ay", savedPos[1]).apply();
                }
                p.setResult(true);
            }
        });
    }

    /** 每次扫描把拖放过的位置重新套上（抖音自己会把挂件挪回去）；设置页点“重置位置”则清掉。 */
    static void applyPendantPos(View v) {
        SharedPreferences pp = posPrefs();
        long reset = sp == null ? 0 : sp.getLong("pendant_reset", 0);
        if (pp.getLong("reset_seen", 0) != reset) {
            pp.edit().clear().putLong("reset_seen", reset).apply();
            savedPos = null;
            v.setTranslationX(0f);
            v.setTranslationY(0f);
            return;
        }
        if (savedPos == null && pp.contains("ax")) savedPos = new float[]{pp.getFloat("ax", 0f), pp.getFloat("ay", 0f)};
        else if (savedPos == null && pp.contains("tx")) savedPos = new float[]{v.getLeft() + pp.getFloat("tx", 0f), v.getTop() + pp.getFloat("ty", 0f)};   // 旧版保存的是偏移量
        placePendant(v);
    }

    static void placePendant(View v) {
        float[] s = DRAG.get(v);
        if (savedPos == null || s == null || s[4] != 0f) return;
        float tx = savedPos[0] - v.getLeft(), ty = savedPos[1] - v.getTop();
        float eps = 8f * v.getResources().getDisplayMetrics().density;   // 差几 dp 不动：避免和抖音自己的小动画互相拉扯
        float dev = Math.max(Math.abs(v.getTranslationX() - tx), Math.abs(v.getTranslationY() - ty));
        if (dev > eps && pinAllowed(dev)) {
            v.setTranslationX(tx);
            v.setTranslationY(ty);
        }
    }

    static void pendant(View v, Ctx c) {
        PENDANTS.put(v, true);
        // 倍速期间新创建的红包挂件尚无历史状态；按正常可见状态作为恢复基线，避免记录模块隐藏后的 INVISIBLE。
        if (speedPendantHidden) {
            PENDANT_VIS.putIfAbsent(v, View.VISIBLE);
            settingPendantVisibility = true;
            try { v.setVisibility(View.INVISIBLE); }
            finally { settingPendantVisibility = false; }
        }
        if (v.getWidth() == 0) return;
        if (!DRAG.containsKey(v)) {
            DRAG.put(v, new float[5]);
            pinPendant(v);
            v.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {   // 抖音一重新布局（切页、回前台）就在同一帧里放回去，不会先跳一下
                @Override
                public void onLayoutChange(View view, int l, int t, int r, int b, int ol, int ot, int or, int ob) { placePendant(view); }
            });
        }
        applyPendantPos(v);
        float[] ds = DRAG.get(v);
        if (!fingerDown && !speedPendantHidden && v.getVisibility() == View.VISIBLE && ds != null && ds[4] == 0f && v.getTranslationX() != 0f) PENDANT_POS.put(v, new float[]{v.getLeft() + v.getTranslationX(), v.getTop() + v.getTranslationY()});
        boolean was = PENDANT.containsKey(v);
        if (c.pendant == 1f && !was) return;
        boolean right = v.getLeft() + v.getTranslationX() + v.getWidth() / 2f > c.sw / 2f;
        Boolean prev = PENDANT.get(v);
        if (prev == null || prev != right) {
            v.setPivotX(right ? v.getWidth() : 0f);
            v.setPivotY(v.getHeight() / 2f);
            PENDANT.put(v, right);
        }
        if (v.getScaleX() != c.pendant) {
            v.setScaleX(c.pendant);
            v.setScaleY(c.pendant);
        }
        if (c.pendant == 1f) PENDANT.remove(v);
    }

    /** RecyclerView 条目四周的分隔装饰宽度（左、上、右、下）；取不到就当 0。 */
    static int[] decor(View item) {
        try {
            Object lm = XposedHelpers.callMethod(item.getParent(), "getLayoutManager");
            return new int[]{(Integer) XposedHelpers.callMethod(lm, "getLeftDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getTopDecorationHeight", item),
                    (Integer) XposedHelpers.callMethod(lm, "getRightDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getBottomDecorationHeight", item)};
        } catch (Throwable t) {   // 方法名被混淆时才会走到这里
            return new int[4];
        }
    }

    /** 视频区域底部的占位（BottomSpace，高度=底栏）收起，视频铺满到底栏下方。 */
    static void fixSpace(View v, Ctx c) {
        if (c.nav && c.extend) {
            if (!SPACE.containsKey(v)) SPACE.put(v, v.getVisibility());
            if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
        } else {
            Integer o = SPACE.remove(v);
            if (o != null) v.setVisibility(o);
        }
    }

    // ---------- 状态 / 调试 ----------
    static void write(String name, String text) throws Exception {
        FileOutputStream o = new FileOutputStream(new File(app().getExternalFilesDir(null), name));
        try { o.write(text.getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
    }

    /** viewdump 直接写到 内部存储/Download。Android 10+ 走 MediaStore（同名文件原地覆盖），更低版本直接写文件。 */
    static void download(String name, String text) throws Exception {
        Context ctx = app();
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (android.os.Build.VERSION.SDK_INT < 29) {
            FileOutputStream o = new FileOutputStream(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name));
            try { o.write(bytes); } finally { o.close(); }
            return;
        }
        ContentResolver cr = ctx.getContentResolver();
        Uri col = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        Uri uri = null;
        Cursor q = cr.query(col, new String[]{MediaStore.MediaColumns._ID},
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                new String[]{name, "Download/"}, null);
        try { if (q != null && q.moveToFirst()) uri = ContentUris.withAppendedId(col, q.getLong(0)); } finally { if (q != null) q.close(); }
        if (uri == null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/");
            uri = cr.insert(col, v);
        }
        java.io.OutputStream o = cr.openOutputStream(uri, "wt");
        try { o.write(bytes); } finally { o.close(); }
    }

    static void status() throws Exception {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatus < 5000) return;
        lastStatus = now;
        final String text = "scans=" + scans + "\nhidden_hits=" + matched + "\nnav_fixes=" + navFixed
                + "\ngrid_reflows=" + gridFixed + "\ntab_centerings=" + centerFixed
                + "\nlast_root=" + lastRoot + "\nsdk=" + android.os.Build.VERSION.SDK_INT + "\n";
        new Thread(() -> {   // 写文件放到后台线程，不占主线程
            try { write("dyhide_status.txt", text); } catch (Exception e) { XposedBridge.log(e); }
        }).start();
    }

    static void dump(View root) throws Exception {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_DUMP.get(root);
        if (last != null && now - last < 3000) {   // 3 秒内的变化不能丢：补一次延后的导出，文件才是最终状态
            if (DUMP_LATER.put(root, true) == null) handler().postDelayed(() -> {
                DUMP_LATER.remove(root);
                LAST_DUMP.remove(root);
                try { dump(root); } catch (Exception e) { XposedBridge.log(e); }
            }, 3000 - (now - last) + 50);
            return;
        }
        LAST_DUMP.put(root, now);
        StringBuilder sb = new StringBuilder();
        sb.append("root=").append(root.getClass().getName()).append(' ')
                .append(root.getWidth()).append('x').append(root.getHeight()).append('\n');
        dumpNode(root, 0, sb);
        sb.append("\n# 红包挂件轨迹（每次平移变化一行，最新在最后；时间是开机后毫秒数取模）\n");
        synchronized (TRACE) { for (String line : TRACE) sb.append(line).append('\n'); }
        final String name = (hasLive(root, 0) ? "viewdump_live_" + (System.identityHashCode(root) & 3) : has(root, "SearchMiddlePageRecyclerView", 0) ? "viewdump_search" : has(root, "ProfileBubbleLayout", 0) ? "viewdump_profile" : "viewdump_" + (System.identityHashCode(root) & 15)) + ".txt";
        final String body = sb.toString();
        new Thread(() -> {   // 控件树要在主线程里遍历，但写到 Download（MediaStore）很慢，放到后台线程
            try { download(name, body); } catch (Exception e) { XposedBridge.log(e); }
        }).start();   // 直播、搜索页、主页各自固定文件名，不会被别的窗口覆盖   // 直播窗口单独存，不会被别的窗口覆盖
    }

    static void dumpNode(View v, int depth, StringBuilder sb) {
        if (sb.length() > 600000) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getName());
        if (v.getClass().getName().startsWith("X.")) sb.append(" extends ").append(v.getClass().getSuperclass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            String n;
            try { n = v.getResources().getResourceEntryName(id); } catch (Throwable t) { n = Integer.toHexString(id); }
            sb.append(" #").append(n);
        }
        if (v instanceof TextView && ((TextView) v).getText().length() > 0)
            sb.append(" text=\"").append(cut(((TextView) v).getText())).append('"');
        if (v.getContentDescription() != null)
            sb.append(" desc=\"").append(cut(v.getContentDescription())).append('"');
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
                .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
        if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
        if (v.getScaleX() != 1f || v.getScaleY() != 1f) sb.append(" scale=").append(v.getScaleX()).append(',').append(v.getScaleY()).append(" pivot=").append(v.getPivotX()).append(',').append(v.getPivotY());
        if (v.getTranslationX() != 0f || v.getTranslationY() != 0f) sb.append(" trans=").append(v.getTranslationX()).append(',').append(v.getTranslationY());
        if (v.getAlpha() != 1f) sb.append(" alpha=").append(v.getAlpha());
        if (v.getLeft() != 0) sb.append(" left=").append(v.getLeft());
        if (HIDDEN.containsKey(v)) sb.append(" HIDDEN");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpNode(g.getChildAt(i), depth + 1, sb);
        }
    }

    static String cut(CharSequence s) {
        String x = s.toString().replace('\n', ' ');
        return x.length() > 40 ? x.substring(0, 40) : x;
    }
}
