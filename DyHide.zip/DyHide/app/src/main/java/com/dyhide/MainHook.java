package com.dyhide;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.GridLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TARGET = "com.ss.android.ugc.aweme";
    static final String MODULE = "com.dyhide";
    static Handler H;
    static final Map<View, Boolean> PENDING = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, WeakReference<View>> HIDDEN = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<View>>());
    static final Map<View, Long> LAST_DUMP = new WeakHashMap<>();
    static final Map<View, Boolean> ATTACHED = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, String> GRID_SIG = new WeakHashMap<>();
    static final Map<View, Object[]> ORIG_SPECS = new WeakHashMap<>();
    static final Map<View, Boolean> CENTERED = new WeakHashMap<>();
    static final Map<View, Integer> SPACE = Collections.synchronizedMap(new WeakHashMap<View, Integer>());
    static final Map<View, Boolean> MAIN = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, Drawable> BG_ORIG = new WeakHashMap<>();
    static final Map<View, int[]> SIZE = new WeakHashMap<>();
    static final Map<View, Integer> NAV_BG = Collections.synchronizedMap(new WeakHashMap<View, Integer>());       // 底栏背景图/分割线 -> 原可见性
    static final Map<View, Drawable> NAV_PAR = Collections.synchronizedMap(new WeakHashMap<View, Drawable>());   // 底栏容器 -> 原背景
    static final Map<View, Boolean> PENDANT = new WeakHashMap<>();   // 红包挂件 -> 当前贴右边(true)/左边(false)
    static final Map<View, WeakReference<Dialog>> DIALOG = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<Dialog>>());   // 弹窗根视图 -> 弹窗（命中 DISMISS 规则时用来关掉它）
    static XSharedPreferences sp;
    static int scans, matched, navFixed, gridFixed, centerFixed;
    static long lastStatus;
    static String lastRoot = "";

    static synchronized Handler handler() {
        if (H == null) H = new Handler(Looper.getMainLooper());
        return H;
    }

    static final class Ctx {
        int sw, sh;
        float density;
        boolean nav, center, extend, overlay, disc;
        View root;
        float pendant = 1f;
        List<Rules.R> rules = new ArrayList<>();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (MODULE.equals(lp.packageName)) {   // 模块自己的界面：把“是否激活”钩成 true（需要在 LSPosed 的作用域里勾选本模块）
            XposedHelpers.findAndHookMethod("com.dyhide.MainActivity", lp.classLoader, "isModuleActive", XC_MethodReplacement.returnConstant(true));
            return;
        }
        if (!TARGET.equals(lp.packageName)) return;
        sp = new XSharedPreferences(MODULE, "config");
        sp.makeWorldReadable();
        XposedBridge.log("DyHide: loaded in " + lp.processName + " sdk=" + android.os.Build.VERSION.SDK_INT);
        Class<?> vri = XposedHelpers.findClass("android.view.ViewRootImpl", lp.classLoader);
        Set<XC_MethodHook.Unhook> u = XposedBridge.hookAllMethods(vri, "performTraversals", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                schedule((View) XposedHelpers.getObjectField(p.thisObject, "mView"));
            }
        });
        XposedBridge.log("DyHide: performTraversals hooks=" + u.size());
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Activity) p.thisObject).getWindow().getDecorView();
                MAIN.put(decor, true);   // Activity 自己的窗口；其余（对话框、弹出层）都算浮层
                attach(decor);
            }
        });
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Dialog) p.thisObject).getWindow().getDecorView();
                DIALOG.put(decor, new WeakReference<Dialog>((Dialog) p.thisObject));
                attach(decor);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                int vis = (Integer) p.args[0];
                if (vis != View.GONE && (HIDDEN.containsKey(p.thisObject) || SPACE.containsKey(p.thisObject))) {
                    p.args[0] = View.GONE;
                } else if (vis == View.VISIBLE && NAV_BG.containsKey(p.thisObject)) {
                    p.args[0] = View.INVISIBLE;   // 抖音滑动时会把底栏背景重新设为可见，这里一律拦住
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Drawable d = (Drawable) p.args[0];
                if (d != null && NAV_PAR.containsKey(p.thisObject)) {
                    if (!(d instanceof ColorDrawable && ((ColorDrawable) d).getColor() == 0)) {
                        NAV_PAR.put((View) p.thisObject, d);   // 记下抖音新设的背景，关闭功能时还原
                    }
                    p.args[0] = null;
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackgroundColor", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (NAV_PAR.containsKey(p.thisObject)) p.args[0] = Color.TRANSPARENT;
            }
        });
        hookPendantDrag();
    }

    static void attach(final View decor) {
        if (ATTACHED.containsKey(decor)) return;
        ATTACHED.put(decor, true);
        final android.view.ViewTreeObserver vto = decor.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() { schedule(decor); }
        });
        if (!MAIN.containsKey(decor)) {   // 弹窗（如长按菜单）：第一帧绘制前同步扫描，被隐藏的控件不会先闪出来
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                @Override
                public boolean onPreDraw() {
                    decor.getViewTreeObserver().removeOnPreDrawListener(this);
                    scan(decor);
                    return true;
                }
            });
        }
        else {   // 主窗口：刚恢复的前 3 秒，绘制前（至少隔 60ms）扫一遍；这一轮有新隐藏就放弃这一帧重新布局，被挤到下面的作者名不会先出现一下再往下跳
            final long t0 = SystemClock.uptimeMillis();
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                long last;

                @Override
                public boolean onPreDraw() {
                    long now = SystemClock.uptimeMillis();
                    if (now - t0 > 3000) {
                        decor.getViewTreeObserver().removeOnPreDrawListener(this);
                        return true;
                    }
                    if (now - last < 60) return true;
                    last = now;
                    int before = matched;
                    scan(decor);
                    return matched == before;
                }
            });
        }
        schedule(decor);
    }

    static boolean on(String key, boolean def) {
        return sp == null ? def : sp.getBoolean(key, def);
    }

    static void schedule(final View root) {
        if (PENDING.containsKey(root)) return;
        PENDING.put(root, true);
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PENDING.remove(root);
                try {
                    scan(root);
                    status();
                    if (on("dump", false)) dump(root);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        }, 250);
    }

    static void scan(View root) {
        if (!root.isAttachedToWindow()) return;
        if (sp != null && sp.hasFileChanged()) sp.reload();
        Ctx c = new Ctx();
        c.sw = root.getResources().getDisplayMetrics().widthPixels;
        c.sh = root.getResources().getDisplayMetrics().heightPixels;
        c.density = root.getResources().getDisplayMetrics().density;
        c.nav = on("nav_transparent", true);
        c.center = on("center_tabs", true);
        c.extend = on("extend_feed", true);
        c.overlay = !MAIN.containsKey(root);
        c.root = root;
        c.disc = on("r_右下角唱片", true);
        c.pendant = sp == null ? 1f : sp.getFloat("pendant_scale", 1f);
        for (Rules.R r : Rules.ALL) if (on(r.key(), true)) c.rules.add(r);
        scans++;
        lastRoot = root.getClass().getName();
        if (scans == 1) XposedBridge.log("DyHide: first scan, rules=" + c.rules.size());
        if (!c.nav) restoreNav();
        walk(root, c);
        boolean clearOn = false;
        for (Rules.R x : c.rules) clearOn |= x.mode == Rules.CLEAR;
        if (!clearOn) restoreBg();
    }

    static Rules.R firstMatch(View v, Ctx c) {
        CharSequence t = v instanceof TextView ? ((TextView) v).getText() : null;
        CharSequence d = v.getContentDescription();
        String cls = v.getClass().getName();
        String id = Rules.NEED_ID ? Rules.idName(v) : null;
        for (Rules.R r : c.rules) {
            if ((!r.overlayOnly || c.overlay) && r.matchView(v, cls, id, t, d)) return r;
        }
        return null;
    }

    /** 向上最多 6 层找祖先：suffix 是类名结尾，或 "#"+资源ID名。 */
    static View ancestor(View v, String suffix) {
        return ancestor(v, suffix, 6);
    }

    static View ancestor(View v, String suffix, int depth) {
        boolean byId = suffix.charAt(0) == '#';
        ViewParent p = v.getParent();
        for (int i = 0; i < depth && p instanceof View; i++, p = p.getParent()) {
            if (byId ? suffix.substring(1).equals(Rules.idName((View) p)) : p.getClass().getName().endsWith(suffix)) return (View) p;
        }
        return null;
    }

    static void walk(View v, Ctx c) {
        String cn = v.getClass().getName();
        if (cn.endsWith("BottomSpace")) fixSpace(v, c);
        if (cn.endsWith("CoinPendantView")) pendant(v, c);
        if (v.getVisibility() == View.GONE) {
            WeakReference<View> w = HIDDEN.get(v);
            if (w == null) return;
            View src = w.get();
            if (src != null && firstMatch(src, c) != null) return;
            // 来源文字已变化（控件被复用）或规则被关闭：恢复显示
            HIDDEN.remove(v);
            int[] size = SIZE.remove(v);
            if (size != null) {
                ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                lp.width = size[0];
                lp.height = size[1];
                lp.setMargins(size[2], size[3], size[4], size[5]);
                v.setLayoutParams(lp);
            }
            v.setVisibility(View.VISIBLE);
        }
        Rules.R r = firstMatch(v, c);
        if (r != null && r.veto != null && ancestor(v, r.veto) != null) r = null;
        if (r != null && r.need != null && ancestor(v, r.need, r.depth) == null) r = null;
        if (r != null && r.mode == Rules.CLEAR) {   // 只清背景，继续往下扫
            clearBg(v);
            r = null;
        }
        if (r != null && r.mode == Rules.DISMISS && v.getHeight() > 0) {
            WeakReference<Dialog> w = DIALOG.get(c.root);
            final Dialog d = w == null ? null : w.get();
            if (d != null) {
                c.root.setAlpha(0f);   // 先让它看不见，再关
                matched++;
                handler().post(new Runnable() {
                    @Override
                    public void run() { d.dismiss(); }
                });
                return;
            }
            r = null;
        }
        View target = null;
        if (r != null && r.mode != Rules.DISMISS && (r.mode == Rules.TEXT_ONLY || v.getHeight() > 0)) {
            target = climb(v, r, c);
            if (touchesSearch(target)) target = null;   // 搜索框永远不隐藏
        }
        if (target != null) {
            matched++;
            HIDDEN.put(target, new WeakReference<View>(v));
            if (target.getVisibility() != View.GONE) {
                target.setVisibility(View.GONE);
                // RecyclerView 里的条目 GONE 后仍会占位（宽高 + 条目间距），需要把宽高和间距都收成 0，否则后面的条目会被推偏
                if (isRecycler(target.getParent()) && target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) target.getLayoutParams();
                    int[] d = decor(target);
                    SIZE.put(target, new int[]{lp.width, lp.height, lp.leftMargin, lp.topMargin, lp.rightMargin, lp.bottomMargin});
                    lp.width = 0;
                    lp.height = 0;
                    lp.setMargins(-d[0], -d[1], -d[2], -d[3]);   // 外边距 + 分隔装饰 = 0
                    target.setLayoutParams(lp);
                }
            }
            return;
        }
        if (v instanceof ViewGroup) {
            if (c.nav && cn.endsWith("MainBottomTabContainer")) fixNav((ViewGroup) v, c, 0);
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c);
            if (v instanceof GridLayout) reflowGrid((GridLayout) v);
            if (cn.endsWith("MainTabStripScrollView")) centerTabs(v, c);
            if (cn.endsWith("FeedRightScaleView")) shiftColumn(v, c);
        }
    }

    /** 父容器是（或继承自）RecyclerView：类名里带 RecyclerView 即可。 */
    static boolean isRecycler(ViewParent p) {
        for (Class<?> k = p.getClass(); k != null; k = k.getSuperclass()) if (k.getName().contains("RecyclerView")) return true;
        return false;
    }

    /** 目标本身是搜索框（输入框 / id 含 search），或里面包着搜索框：不隐藏。 */
    static boolean touchesSearch(View t) {
        String id = Rules.idName(t);
        if (t instanceof android.widget.EditText || (id != null && id.toLowerCase().contains("search"))) return true;
        if (t instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) t;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch.getVisibility() != View.GONE && touchesSearch(ch)) return true;
            }
        }
        return false;
    }

    // ---------- 找到“整个入口”并隐藏 ----------
    static View climb(View v, Rules.R r, Ctx c) {
        if (r.mode == Rules.TEXT_ONLY) return v;
        if (r.mode == Rules.CHILD) {   // 广告/汽水听栏：只收掉 MeasureOnceFrameLayout 下包着它的那一块，同栏的相关搜索、合集条不受影响
            View bar = ancestor(v, r.anc, r.depth);
            if (bar != null) {
                View x = v;
                while (x.getParent() != bar) x = (View) x.getParent();
                return x;
            }
        }
        if (r.mode == Rules.CARD) {   // 整张卡片：最近的 MeasureOnceFrameLayout；它的外层如果只装着它，连外层一起收掉，不留空位
            View card = ancestor(v, "MeasureOnceFrameLayout", r.depth);
            if (card != null && card.getHeight() < c.sh * 0.3f) {
                if (card.getParent() instanceof ViewGroup && ((ViewGroup) card.getParent()).getChildCount() == 1
                        && ((View) card.getParent()).getHeight() <= card.getHeight() + 8 * c.density) return (View) card.getParent();
                return card;
            }
        }
        // UP：指定祖先；长按菜单里的条目：隐藏整行（图标+文字+分隔线）
        View up = ancestor(v, r.mode == Rules.UP ? r.anc : "LongPressPanelCommonItemView");
        if (up != null) return up;
        if (r.mode == Rules.UP) return v;
        // 常用功能这类系统 GridLayout：隐藏整个单元（图标+文字）
        View cell = v;
        for (int i = 0; i < 4 && cell.getParent() instanceof ViewGroup; i++) {
            if (cell.getParent() instanceof GridLayout) return cell;
            cell = (View) cell.getParent();
        }
        int h = v.getHeight();
        View cur = v;
        for (int i = 0; i < 4 && cur.getParent() instanceof ViewGroup; i++) {
            ViewGroup g = (ViewGroup) cur.getParent();
            String n = g.getClass().getName();
            if (n.contains("RecyclerView") || n.contains("ScrollView") || n.contains("ViewPager")
                    || n.contains("CardModuleView") || n.contains("RoundedFrameLayout")
                    || g instanceof android.widget.AbsListView) break;
            int same = 0, kids = 0;
            for (int k = 0; k < g.getChildCount(); k++) {
                View ch = g.getChildAt(k);
                if (ch.getVisibility() == View.GONE) continue;
                kids++;
                if (ch.getClass() == cur.getClass()) same++;   // cur 已经是列表里的一项
            }
            if (same >= 2 || kids > 3 || g.getWidth() > c.sw * 0.9f || g.getHeight() > h * 3.5f + 16 * c.density) break;
            cur = g;
        }
        return cur;
    }

    /** 清掉控件及与它同高的父容器、与它同宽的子容器的背景（按钮等内部小控件的背景保留）。 */
    static void clearBg(View v) {
        strip(v);
        if (v.getParent() instanceof View && ((View) v.getParent()).getHeight() <= v.getHeight() * 1.5f) strip((View) v.getParent());
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (g.getChildAt(i).getWidth() >= v.getWidth() * 0.9f) strip(g.getChildAt(i));
            }
        }
    }

    static void strip(View x) {
        Drawable b = x.getBackground();
        if (b != null) {
            BG_ORIG.put(x, b);
            x.setBackground(null);
        }
    }

    static void restoreBg() {
        for (Map.Entry<View, Drawable> e : new ArrayList<>(BG_ORIG.entrySet())) e.getKey().setBackground(e.getValue());
        BG_ORIG.clear();
    }

    static boolean hasDesc(View v, String d) {
        if (v.getVisibility() != View.VISIBLE) return false;
        if (d.contentEquals(String.valueOf(v.getContentDescription()))) return true;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasDesc(g.getChildAt(i), d)) return true;
        }
        return false;
    }

    /** 右侧点赞/评论/收藏/分享一列：唱片行隐藏后，整体下移该行的高度，补上空位。 */
    static void shiftColumn(View col, Ctx c) {
        float dy = 0f;
        if (c.disc) {
            ViewGroup p = (ViewGroup) col.getParent();
            for (int i = 0; i < p.getChildCount(); i++) {
                View s = p.getChildAt(i);
                // 唱片行里是"听抖音"按钮（占着原来的位置）时，不下移
                if (s.getClass().getName().endsWith("FpsControlFrameLayout") && !hasDesc(s, "听抖音")) dy = s.getHeight();
            }
        }
        if (col.getTranslationY() != dy) col.setTranslationY(dy);
    }

    // ---------- 网格重排：隐藏后把剩下的单元顺序补位 ----------
    static GridLayout.Spec specAt(GridLayout.Spec old, int start) {
        GridLayout.Alignment a = (GridLayout.Alignment) XposedHelpers.getObjectField(old, "alignment");
        return GridLayout.spec(start, 1, a, XposedHelpers.getFloatField(old, "weight"));
    }

    static void reflowGrid(GridLayout g) {
        int cols = g.getColumnCount();
        if (cols <= 0) return;
        int n = g.getChildCount();
        boolean any = false;
        StringBuilder sig = new StringBuilder();
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            if (HIDDEN.containsKey(ch)) any = true;
            sig.append(ch.getVisibility() == View.GONE ? '0' : '1');
        }
        String now = any ? sig.toString() : "";
        String prev = GRID_SIG.get(g);
        if (now.equals(prev == null ? "" : prev)) return;
        GRID_SIG.put(g, now);
        gridFixed++;
        int k = 0;
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) ch.getLayoutParams();
            if (!any) {
                Object[] o = ORIG_SPECS.remove(ch);
                if (o != null) {
                    lp.rowSpec = (GridLayout.Spec) o[0];
                    lp.columnSpec = (GridLayout.Spec) o[1];
                    ch.setLayoutParams(lp);
                }
                continue;
            }
            if (ch.getVisibility() == View.GONE) continue;
            if (!ORIG_SPECS.containsKey(ch)) ORIG_SPECS.put(ch, new Object[]{lp.rowSpec, lp.columnSpec});
            lp.rowSpec = specAt(lp.rowSpec, k / cols);
            lp.columnSpec = specAt(lp.columnSpec, k % cols);
            ch.setLayoutParams(lp);
            k++;
        }
    }

    // ---------- 顶部标签：隐藏后剩下的居中 ----------
    static void centerTabs(View strip, Ctx c) {
        ViewGroup rl = (ViewGroup) ((ViewGroup) strip).getChildAt(0);
        boolean anyHidden = false;
        int minL = Integer.MAX_VALUE, maxR = Integer.MIN_VALUE;
        int[] loc = new int[2];
        for (int i = 0; i < rl.getChildCount(); i++) {
            View it = rl.getChildAt(i);
            if (!it.getClass().getName().contains("TabItem")) continue;
            if (it.getVisibility() == View.GONE) {
                anyHidden |= HIDDEN.containsKey(it);
            } else if (it.getWidth() > 0) {
                it.getLocationOnScreen(loc);
                minL = Math.min(minL, loc[0]);
                maxR = Math.max(maxR, loc[0] + it.getWidth());
            }
        }
        if (!c.center || !anyHidden || minL == Integer.MAX_VALUE) {
            if (CENTERED.remove(strip) != null) strip.setTranslationX(0f);
            return;
        }
        View bar = strip;
        for (int i = 0; i < 6 && bar.getParent() instanceof View; i++) {
            bar = (View) bar.getParent();
            if (bar.getClass().getName().endsWith("MainTitleBar")) break;
        }
        int[] bl = new int[2];
        bar.getLocationOnScreen(bl);
        float d = (bl[0] + bar.getWidth() / 2f) - (minL + maxR) / 2f;
        if (Math.abs(d) > 2f) {
            strip.setTranslationX(strip.getTranslationX() + d);
            CENTERED.put(strip, true);
            centerFixed++;
        }
    }

    // ---------- 底栏透明：容器背景清空，背景图/分割线设为 INVISIBLE（并拦截抖音重新设回可见/背景） ----------
    static void fixNav(ViewGroup g, Ctx c, int depth) {
        stripNav(g);
        for (int i = 0; i < g.getChildCount(); i++) {
            View ch = g.getChildAt(i);
            String n = ch.getClass().getName();
            if (n.endsWith("BottomTab") || n.endsWith("PublishButton")) continue;   // 图标和文字保持不透明
            if (ch instanceof ViewGroup) {
                if (depth < 4) fixNav((ViewGroup) ch, c, depth + 1);
            } else if (ch.getVisibility() == View.VISIBLE && ch.getWidth() >= c.sw * 0.9f) {
                NAV_BG.put(ch, View.VISIBLE);
                ch.setVisibility(View.INVISIBLE);
                navFixed++;
            }
        }
    }

    static void stripNav(View x) {
        if (NAV_PAR.containsKey(x)) return;
        Drawable b = x.getBackground();
        NAV_PAR.put(x, b);   // 没有背景的容器也登记，抖音之后再设背景时同样会被拦住
        if (b != null) {
            x.setBackground(null);
            navFixed++;
        }
    }

    static void restoreNav() {
        for (View x : new ArrayList<View>(NAV_BG.keySet())) {
            Integer o = NAV_BG.remove(x);
            if (o != null) x.setVisibility(o);
        }
        for (Map.Entry<View, Drawable> e : new ArrayList<>(NAV_PAR.entrySet())) {
            NAV_PAR.remove(e.getKey());
            e.getKey().setBackground(e.getValue());
        }
    }

    // ---------- 红包挂件缩放（贴哪边就以哪边的中点为轴，缩放后仍贴边） ----------
    /** 红包挂件拖拽状态：downRawX, downRawY, 按下时 translationX, translationY, 是否正在拖。 */
    static final Map<View, float[]> DRAG = new WeakHashMap<>();
    static float[] savedPos;   // 拖放后的 translationX/Y；null = 没拖过，保持抖音原位置

    static Context app() {
        return (Application) XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
    }

    static SharedPreferences posPrefs() {
        return app().getSharedPreferences("dyhide_pendant", Context.MODE_PRIVATE);
    }

    /** 拖拽钩子：挂件被手指拖动超过 touch slop 后，改为跟手移动并吃掉后续事件；没拖动的点按照常交给抖音。 */
    static void hookPendantDrag() {
        XposedBridge.hookMethod(XposedHelpers.findMethodExact(ViewGroup.class, "dispatchTouchEvent", MotionEvent.class), new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) throws Throwable {
                float[] s = DRAG.get(p.thisObject);
                if (s == null) return;
                View v = (View) p.thisObject;
                MotionEvent e = (MotionEvent) p.args[0];
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    s[0] = e.getRawX();
                    s[1] = e.getRawY();
                    s[2] = v.getTranslationX();
                    s[3] = v.getTranslationY();
                    s[4] = 0f;
                    return;
                }
                if (a == MotionEvent.ACTION_MOVE && s[4] == 0f
                        && Math.hypot(e.getRawX() - s[0], e.getRawY() - s[1]) > ViewConfiguration.get(v.getContext()).getScaledTouchSlop()) {
                    s[4] = 1f;
                    MotionEvent cancel = MotionEvent.obtain(e);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    XposedBridge.invokeOriginalMethod(p.method, v, new Object[]{cancel});   // 让挂件里的按钮放弃这次点按
                    cancel.recycle();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (s[4] == 0f) return;
                if (a == MotionEvent.ACTION_MOVE) {
                    View par = (View) v.getParent();
                    float tx = Math.max(-v.getLeft(), Math.min(par.getWidth() - v.getWidth() - v.getLeft(), s[2] + e.getRawX() - s[0]));
                    float ty = Math.max(-v.getTop(), Math.min(par.getHeight() - v.getHeight() - v.getTop(), s[3] + e.getRawY() - s[1]));
                    v.setTranslationX(tx);
                    v.setTranslationY(ty);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    s[4] = 0f;
                    savedPos = new float[]{v.getTranslationX(), v.getTranslationY()};
                    posPrefs().edit().putFloat("tx", savedPos[0]).putFloat("ty", savedPos[1]).apply();
                }
                p.setResult(true);
            }
        });
    }

    /** 每次扫描把拖放过的位置重新套上（抖音自己会把挂件挪回去）；设置页点“重置位置”则清掉。 */
    static void applyPendantPos(View v) {
        SharedPreferences pp = posPrefs();
        long reset = sp == null ? 0 : sp.getLong("pendant_reset", 0);
        if (pp.getLong("reset_seen", 0) != reset) {
            pp.edit().clear().putLong("reset_seen", reset).apply();
            savedPos = null;
            v.setTranslationX(0f);
            v.setTranslationY(0f);
            return;
        }
        if (savedPos == null && pp.contains("tx")) savedPos = new float[]{pp.getFloat("tx", 0f), pp.getFloat("ty", 0f)};
        float[] s = DRAG.get(v);
        if (savedPos != null && s[4] == 0f) {
            v.setTranslationX(savedPos[0]);
            v.setTranslationY(savedPos[1]);
        }
    }

    static void pendant(View v, Ctx c) {
        if (v.getWidth() == 0) return;
        if (!DRAG.containsKey(v)) DRAG.put(v, new float[5]);
        applyPendantPos(v);
        boolean was = PENDANT.containsKey(v);
        if (c.pendant == 1f && !was) return;
        boolean right = v.getLeft() + v.getTranslationX() + v.getWidth() / 2f > c.sw / 2f;
        Boolean prev = PENDANT.get(v);
        if (prev == null || prev != right) {
            v.setPivotX(right ? v.getWidth() : 0f);
            v.setPivotY(v.getHeight() / 2f);
            PENDANT.put(v, right);
        }
        if (v.getScaleX() != c.pendant) {
            v.setScaleX(c.pendant);
            v.setScaleY(c.pendant);
        }
        if (c.pendant == 1f) PENDANT.remove(v);
    }

    /** RecyclerView 条目四周的分隔装饰宽度（左、上、右、下）；取不到就当 0。 */
    static int[] decor(View item) {
        try {
            Object lm = XposedHelpers.callMethod(item.getParent(), "getLayoutManager");
            return new int[]{(Integer) XposedHelpers.callMethod(lm, "getLeftDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getTopDecorationHeight", item),
                    (Integer) XposedHelpers.callMethod(lm, "getRightDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getBottomDecorationHeight", item)};
        } catch (Throwable t) {   // 方法名被混淆时才会走到这里
            return new int[4];
        }
    }

    /** 视频区域底部的占位（BottomSpace，高度=底栏）收起，视频铺满到底栏下方。 */
    static void fixSpace(View v, Ctx c) {
        if (c.nav && c.extend) {
            if (!SPACE.containsKey(v)) SPACE.put(v, v.getVisibility());
            if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
        } else {
            Integer o = SPACE.remove(v);
            if (o != null) v.setVisibility(o);
        }
    }

    // ---------- 状态 / 调试 ----------
    static void write(String name, String text) throws Exception {
        FileOutputStream o = new FileOutputStream(new File(app().getExternalFilesDir(null), name));
        try { o.write(text.getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
    }

    /** viewdump 直接写到 内部存储/Download。Android 10+ 走 MediaStore（同名文件原地覆盖），更低版本直接写文件。 */
    static void download(String name, String text) throws Exception {
        Context ctx = app();
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (android.os.Build.VERSION.SDK_INT < 29) {
            FileOutputStream o = new FileOutputStream(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name));
            try { o.write(bytes); } finally { o.close(); }
            return;
        }
        ContentResolver cr = ctx.getContentResolver();
        Uri col = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        Uri uri = null;
        Cursor q = cr.query(col, new String[]{MediaStore.MediaColumns._ID},
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                new String[]{name, "Download/"}, null);
        try { if (q != null && q.moveToFirst()) uri = ContentUris.withAppendedId(col, q.getLong(0)); } finally { if (q != null) q.close(); }
        if (uri == null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/");
            uri = cr.insert(col, v);
        }
        java.io.OutputStream o = cr.openOutputStream(uri, "wt");
        try { o.write(bytes); } finally { o.close(); }
    }

    static void status() throws Exception {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatus < 5000) return;
        lastStatus = now;
        write("dyhide_status.txt", "scans=" + scans + "\nhidden_hits=" + matched + "\nnav_fixes=" + navFixed
                + "\ngrid_reflows=" + gridFixed + "\ntab_centerings=" + centerFixed
                + "\nlast_root=" + lastRoot + "\nsdk=" + android.os.Build.VERSION.SDK_INT + "\n");
    }

    static void dump(View root) throws Exception {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_DUMP.get(root);
        if (last != null && now - last < 3000) return;
        LAST_DUMP.put(root, now);
        StringBuilder sb = new StringBuilder();
        sb.append("root=").append(root.getClass().getName()).append(' ')
                .append(root.getWidth()).append('x').append(root.getHeight()).append('\n');
        dumpNode(root, 0, sb);
        download("viewdump_" + (System.identityHashCode(root) & 15) + ".txt", sb.toString());
    }

    static void dumpNode(View v, int depth, StringBuilder sb) {
        if (sb.length() > 600000) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            String n;
            try { n = v.getResources().getResourceEntryName(id); } catch (Throwable t) { n = Integer.toHexString(id); }
            sb.append(" #").append(n);
        }
        if (v instanceof TextView && ((TextView) v).getText().length() > 0)
            sb.append(" text=\"").append(cut(((TextView) v).getText())).append('"');
        if (v.getContentDescription() != null)
            sb.append(" desc=\"").append(cut(v.getContentDescription())).append('"');
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
                .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
        if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
        if (HIDDEN.containsKey(v)) sb.append(" HIDDEN");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpNode(g.getChildAt(i), depth + 1, sb);
        }
    }

    static String cut(CharSequence s) {
        String x = s.toString().replace('\n', ' ');
        return x.length() > 40 ? x.substring(0, 40) : x;
    }
}
