package com.dyhide;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.View;
import android.widget.Toast;
import android.widget.PopupWindow;
import android.view.Window;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.GridLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TARGET = "com.ss.android.ugc.aweme";
    static final String MODULE = "com.dyhide";
    static Handler H;
    static final Map<View, Boolean> PENDING = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, WeakReference<View>> HIDDEN = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<View>>());
    static final Map<View, Long> LAST_DUMP = new WeakHashMap<>();
    static final Map<View, Boolean> ATTACHED = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, String> GRID_SIG = new WeakHashMap<>();
    static final Map<View, Object[]> ORIG_SPECS = new WeakHashMap<>();
    static final Map<View, Boolean> CENTERED = new WeakHashMap<>();
    static final Map<View, Integer> SPACE = Collections.synchronizedMap(new WeakHashMap<View, Integer>());
    static final Map<View, Boolean> MAIN = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, Drawable> BG_ORIG = new WeakHashMap<>();
    static final Map<View, int[]> SIZE = new WeakHashMap<>();
    static final Map<View, Integer> NAV_BG = Collections.synchronizedMap(new WeakHashMap<View, Integer>());       // 底栏背景图/分割线 -> 原可见性
    static final Map<View, Drawable> NAV_PAR = Collections.synchronizedMap(new WeakHashMap<View, Drawable>());   // 底栏容器 -> 原背景
    static final Map<View, Boolean> PENDANT = new WeakHashMap<>();
    static final Map<View, Boolean> PENDANTS = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, Integer> PENDANT_VIS = new WeakHashMap<>(); // 仅倍速期间保存抖音请求的可见性
    static final Map<View, Boolean> SPEED_GUIDES = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static boolean speedPendantHidden;   // 仅在抖音实际显示倍速提示时隐藏红包挂件
    static boolean settingPendantVisibility; // 区分模块隐藏操作与抖音主动设置的可见性
    static final Map<View, long[]> ANIM = new WeakHashMap<>();       // 红包挂件 -> {统计窗口起点, 这段时间里被设了几次平移}
    static final Map<View, WeakReference<Dialog>> DIALOG = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<Dialog>>());   // 弹窗根视图 -> 弹窗（命中 DISMISS 规则时用来关掉它）
    static XSharedPreferences sp;
    /** 上一次扫描里“没命中任何规则”的控件及其（文字、描述、窗口类型）指纹；没变就不再逐条规则比对，滑动/切页时扫描快得多。 */
    static final Map<View, Integer> NOMATCH = new WeakHashMap<>();

    static int scans, matched, navFixed, gridFixed, centerFixed;
    static long lastStatus;
    static String lastRoot = "";

    static synchronized Handler handler() {
        if (H == null) H = new Handler(Looper.getMainLooper());
        return H;
    }

    static final class Ctx {
        int sw, sh;
        float density;
        boolean nav, center, extend, overlay, disc, live, fit;
        final List<View> tabs = new ArrayList<>();   // 本次扫描遇到的顶部标签项（按出现顺序）
        int inLive;   // 当前正走在几层直播容器里面（直播内容里不动任何非直播规则，免得误隐藏画面造成黑屏）
        View root;
        float pendant = 1f;
        List<Rules.R> rules = new ArrayList<>();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (MODULE.equals(lp.packageName)) {   // 模块自己的界面：把“是否激活”钩成 true（需要在 LSPosed 的作用域里勾选本模块）
            XposedHelpers.findAndHookMethod("com.dyhide.MainActivity", lp.classLoader, "isModuleActive", XC_MethodReplacement.returnConstant(true));
            return;
        }
        if (!TARGET.equals(lp.packageName)) return;
        sp = new XSharedPreferences(MODULE, "config");
        XposedBridge.log("DyHide: loaded in " + lp.processName + " sdk=" + android.os.Build.VERSION.SDK_INT);
        Class<?> vri = XposedHelpers.findClass("android.view.ViewRootImpl", lp.classLoader);
        Set<XC_MethodHook.Unhook> u = XposedBridge.hookAllMethods(vri, "performTraversals", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                schedule((View) XposedHelpers.getObjectField(p.thisObject, "mView"));
            }
        });
        XposedBridge.log("DyHide: performTraversals hooks=" + u.size());
        // 以抖音真实的倍速提示视图作为状态源，不再猜测长按时长/触摸区域。
        // 收藏、点赞视频的触摸分发链不同，旧的 VideoPinchViewContainer 触摸监听可能收不到完整事件。
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Activity) p.thisObject).getWindow().getDecorView();
                MAIN.put(decor, true);   // Activity 自己的窗口；其余（对话框、弹出层）都算浮层
                attach(decor);
                // 回到前台时强制补一次扫描；视频 View 可能被抖音重置为原始裁切比例。
                schedule(decor);
                handler().postDelayed(() -> schedule(decor), 320);
            }
        });
        // 提示类窗口在显示之前就拦下：文字命中“整窗隐藏”规则的，干脆不显示，连一瞬间都不会闪
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Window w = ((Dialog) p.thisObject).getWindow();
                if (w != null && blocked(w.getDecorView())) p.setResult(null);
            }
        });
        XC_MethodHook popup = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                View cv = ((PopupWindow) p.thisObject).getContentView();
                if (cv != null && blocked(cv)) p.setResult(null);
            }
        };
        XposedBridge.hookAllMethods(PopupWindow.class, "showAtLocation", popup);
        XposedBridge.hookAllMethods(PopupWindow.class, "showAsDropDown", popup);
        XposedBridge.hookAllMethods(Toast.class, "show", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                View tv = ((Toast) p.thisObject).getView();
                if (tv != null && blocked(tv)) p.setResult(null);
            }
        });
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View decor = ((Dialog) p.thisObject).getWindow().getDecorView();
                DIALOG.put(decor, new WeakReference<Dialog>((Dialog) p.thisObject));
                attach(decor);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                int vis = (Integer) p.args[0];
                if (vis != View.VISIBLE) {
                    if (SPEED_GUIDES.remove(p.thisObject) != null) pruneSpeedGuides();
                } else if (isSpeedSignalView((View) p.thisObject)) {
                    final View signal = (View) p.thisObject;
                    handler().post(() -> {   // 等这次 setVisibility 生效后，按整条祖先链判断是不是真的显示出来了
                        if (!speedSignalShown(signal)) return;
                        SPEED_GUIDES.put(signal, true);
                        hidePendantForSpeed();
                    });
                }
                if (speedPendantHidden && PENDANT_VIS.containsKey(p.thisObject)) {
                    // 保存抖音真正想设置的状态；模块自己设为 INVISIBLE 时不能覆盖这份记录。
                    if (!settingPendantVisibility && p.thisObject instanceof View) {
                        PENDANT_VIS.put((View) p.thisObject, vis);
                    }
                    p.args[0] = View.INVISIBLE;
                } else if (vis != View.GONE && (HIDDEN.containsKey(p.thisObject) || SPACE.containsKey(p.thisObject))) {
                    p.args[0] = View.GONE;
                } else if (vis == View.VISIBLE && NAV_BG.containsKey(p.thisObject)) {
                    p.args[0] = View.INVISIBLE;   // 抖音滑动时会把底栏背景重新设为可见，这里一律拦住
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Drawable d = (Drawable) p.args[0];
                if (d != null && NAV_PAR.containsKey(p.thisObject)) {
                    if (!(d instanceof ColorDrawable && ((ColorDrawable) d).getColor() == 0)) {
                        NAV_PAR.put((View) p.thisObject, d);   // 记下抖音新设的背景，关闭功能时还原
                    }
                    p.args[0] = null;
                }
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setBackgroundColor", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (NAV_PAR.containsKey(p.thisObject)) p.args[0] = Color.TRANSPARENT;
            }
        });
        hookPendantDrag();
        XC_MethodHook transHook = new XC_MethodHook() {   // 抖音自己给挂件设平移（回前台的动画、切页复位）时，位置差得多才纠正
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (FITS.containsKey(p.thisObject)) {   // 抖音把防裁切视频的水平位移复位成 0 时，换成居中值
                    View v = (View) p.thisObject;
                    if (p.method.getName().equals("setTranslationX") && v.getParent() instanceof View) p.args[0] = fitTx(v, (View) v.getParent());
                    return;
                }
                if (savedPos == null) return;
                float[] st = DRAG.get(p.thisObject);
                if (st == null || st[4] != 0f) return;
                View v = (View) p.thisObject;
                long now = SystemClock.uptimeMillis();
                long[] an = ANIM.get(v);
                if (an == null) { an = new long[]{now, 0}; ANIM.put(v, an); }
                if (now - an[0] > 300) { an[0] = now; an[1] = 0; }
                an[1]++;
                if (an[1] > 5) return;   // 300ms 内连着设了好几帧：抖音正在做动画（长按两侧倍速时挂件会动一下），这几帧不抢，免得来回抽搐
                float want = p.method.getName().equals("setTranslationX") ? savedPos[0] - v.getLeft() : savedPos[1] - v.getTop();
                float ask = (Float) p.args[0];
                if (Math.abs(ask - want) <= 8f * v.getResources().getDisplayMetrics().density) return;   // 差几 dp 的小幅位移也让过去
                p.args[0] = want;
            }
        };
        XposedHelpers.findAndHookMethod(View.class, "setTranslationX", float.class, transHook);
        XposedHelpers.findAndHookMethod(View.class, "setTranslationY", float.class, transHook);
        XC_MethodHook scaleHook = new XC_MethodHook() {   // 抖音把被我们缩放过的视频画面的缩放复位成 1 时，直接换成我们的缩放，不会闪一下全屏裁切
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Float f = FITS.get(p.thisObject);
                if (f != null && (Float) p.args[0] == 1f) {
                    View v = (View) p.thisObject;
                    if (v.getParent() instanceof View && v.getWidth() > ((View) v.getParent()).getWidth() + 2) p.args[0] = f;
                }
            }
        };
        XposedHelpers.findAndHookMethod(View.class, "setScaleX", float.class, scaleHook);
        XposedHelpers.findAndHookMethod(View.class, "setScaleY", float.class, scaleHook);
        XposedHelpers.findAndHookMethod(View.class, "setContentDescription", CharSequence.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {   // 抖音靠改描述标记选中的标签
                CharSequence d = (CharSequence) p.args[0];
                if (d != null && tabCls != null && p.thisObject.getClass() == tabCls && d.toString().startsWith("已选中")) onTabSelected((View) p.thisObject);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setSelected", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if ((Boolean) p.args[0] && tabCls != null && p.thisObject.getClass() == tabCls) onTabSelected((View) p.thisObject);
            }
        });
    }

    static void attach(final View decor) {
        if (ATTACHED.containsKey(decor)) return;
        ATTACHED.put(decor, true);
        final android.view.ViewTreeObserver vto = decor.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() { schedule(decor); }
        });
        if (!MAIN.containsKey(decor)) {   // 弹窗（如长按菜单）：第一帧绘制前同步扫描，被隐藏的控件不会先闪出来
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                @Override
                public boolean onPreDraw() {
                    decor.getViewTreeObserver().removeOnPreDrawListener(this);
                    scan(decor);
                    return true;
                }
            });
        }
        else {   // 主窗口：刚恢复的前 3 秒，绘制前（至少隔 60ms）扫一遍；这一轮有新隐藏就放弃这一帧重新布局，被挤到下面的作者名不会先出现一下再往下跳
            final long t0 = SystemClock.uptimeMillis();
            vto.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                long last;

                @Override
                public boolean onPreDraw() {
                    long now = SystemClock.uptimeMillis();
                    if (now - t0 > 3000) {
                        decor.getViewTreeObserver().removeOnPreDrawListener(this);
                        return true;
                    }
                    if (now - last < 60) return true;
                    last = now;
                    int before = matched;
                    scan(decor);
                    return matched == before;
                }
            });
        }
        schedule(decor);
    }

    /**
     * 抖音不同页面/版本的倍速提示结构并不一致：有时使用 LongPressFastSpeedGuideView，
     * 有时使用直接包含提示文字的 LinearLayout（如“下滑松手锁定 2 倍速”或“快进中”）。
     * 只检查直接子 TextView，避免把整棵 DecorView 等祖先容器误识别成信号。
     */
    /** 提示视图自己 VISIBLE 不代表看得见：抖音常把它留在 INVISIBLE/透明的父容器里（ViewDump 里 bottom_layout vis=4），必须看整条祖先链。 */
    static boolean speedSignalShown(View v) {
        if (!v.isShown()) return false;
        for (View x = v; x.getAlpha() > 0.05f; ) {
            if (!(x.getParent() instanceof View)) return true;
            x = (View) x.getParent();
        }
        return false;
    }

    static boolean isSpeedSignalView(View view) {
        if (view.getClass().getName().endsWith("LongPressFastSpeedGuideView")) return true;
        if (!(view instanceof ViewGroup)) return false;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (!(child instanceof TextView)) continue;
            CharSequence value = ((TextView) child).getText();
            if (value == null) continue;
            String text = value.toString().trim();
            if (text.contains("下滑松手锁定 2 倍速") || text.contains("快进中")) return true;
        }
        return false;
    }

    static void hidePendantForSpeed() {
        speedPendantHidden = true;
        settingPendantVisibility = true;
        try {
            for (View v : new ArrayList<View>(PENDANTS.keySet())) {
                if (v == null || !v.isAttachedToWindow()) continue;
                PENDANT_VIS.putIfAbsent(v, v.getVisibility());
                v.setVisibility(View.INVISIBLE);
            }
        } finally {
            settingPendantVisibility = false;
        }
    }

    static void showPendantAfterSpeed() {
        if (!speedPendantHidden) return;
        speedPendantHidden = false;
        settingPendantVisibility = true;
        try {
            for (Map.Entry<View, Integer> e : new ArrayList<>(PENDANT_VIS.entrySet())) {
                View v = e.getKey();
                Integer visibility = PENDANT_VIS.remove(v);
                if (v != null && visibility != null && v.isAttachedToWindow()) v.setVisibility(visibility);
            }
        } finally {
            settingPendantVisibility = false;
        }
    }

    static void pruneSpeedGuides() {
        for (View v : new ArrayList<View>(SPEED_GUIDES.keySet())) {
            if (v == null || !speedSignalShown(v)) SPEED_GUIDES.remove(v);
        }
        if (speedPendantHidden && SPEED_GUIDES.isEmpty()) showPendantAfterSpeed();
    }

    static boolean on(String key, boolean def) {
        return sp == null ? def : sp.getBoolean(key, def);
    }

    static void schedule(final View root) {
        if (PENDING.containsKey(root)) return;
        PENDING.put(root, true);
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PENDING.remove(root);
                try {
                    scan(root);
                    status();
                    if (on("dump", false)) dump(root);
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        }, MAIN.containsKey(root) ? (hasLive(root, 0) ? 60 : 250) : 30);   // 直播间里元素多、变得快，扫得更勤   // Toast、弹出提示这类小窗口扫得更快，被隐藏的提示几乎不会先闪一下
    }

    static void scan(View root) {
        if (!root.isAttachedToWindow()) return;
        if (sp != null && sp.hasFileChanged()) {
            sp.reload();
            NOMATCH.clear();   // 开关变了：规则集合变了，指纹作废
        }
        Ctx c = new Ctx();
        c.sw = root.getResources().getDisplayMetrics().widthPixels;
        c.sh = root.getResources().getDisplayMetrics().heightPixels;
        c.density = root.getResources().getDisplayMetrics().density;
        c.nav = on("nav_transparent", true);
        c.center = on("center_tabs", true);
        c.extend = on("extend_feed", true);
        c.fit = on("fit_video", false);
        myName = sp == null ? "" : sp.getString("my_name", "").trim();
        c.overlay = !MAIN.containsKey(root);
        c.root = root;
        c.live = hasLive(root, 0);
        c.disc = on("r_右下角唱片", true);
        c.pendant = sp == null ? 1f : sp.getFloat("pendant_scale", 1f);
        for (Rules.R r : Rules.ALL) if (on(r.key(), true)) c.rules.add(r);
        scans++;
        lastRoot = root.getClass().getName();
        if (scans == 1) XposedBridge.log("DyHide: first scan, rules=" + c.rules.size());
        if (!c.nav) restoreNav();
        walk(root, c);
        if (MAIN.containsKey(root) && !c.tabs.isEmpty()) {
            lastTabs.clear();
            for (View t : c.tabs) lastTabs.add(new WeakReference<View>(t));
            selectVisibleTab(c.tabs);
        }
        boolean clearOn = false;
        for (Rules.R x : c.rules) clearOn |= x.mode == Rules.CLEAR;
        if (!clearOn) restoreBg();
    }

    /**
     * 返回第一条“匹配并且条件都满足”的规则。条件（直播窗口、veto、need、altNeed）必须在这里一并判断：
     * 否则文字相同的前一条规则匹配上但条件不满足时，会把后面真正适用的规则挡住（例如底部“热点”被顶部“热点”挡住）。
     */
    static Rules.R firstMatch(View v, Ctx c) {
        CharSequence t = viewText(v);
        CharSequence d = v.getContentDescription();
        String cls = v.getClass().getName();
        String id = Rules.NEED_ID ? Rules.idName(v) : null;
        for (Rules.R r : c.rules) {
            if ((r.overlayOnly && !c.overlay) || !r.matchView(v, cls, id, t, d)) continue;
            if (r.live ? !c.live : c.inLive > 0) continue;
            if (r.veto != null && ancestor(v, r.veto) != null) continue;
            if (r.skipMine && isMine(v)) continue;
            boolean viaAlt = r.altAnc != null && r.viaAlt(v, t, d);
            if (viaAlt) {
                if (r.altNeed != null && ancestor(v, r.altNeed, 10) == null) continue;
            } else if (r.closes && r.viaAlt(v, t, d) && DIALOG.containsKey(c.root)) {
                return r;   // 对话框里靠文字命中：直接关掉，不看 need
            } else if (r.need != null && ancestor(v, r.need, r.depth) == null) {
                continue;
            }
            return r;
        }
        return null;
    }

    /** 向上最多 6 层找祖先：suffix 是类名结尾，或 "#"+资源ID名。 */
    static View ancestor(View v, String suffix) {
        return ancestor(v, suffix, 6);
    }

    static View ancestor(View v, String suffix, int depth) {
        boolean byId = suffix.charAt(0) == '#';
        ViewParent p = v.getParent();
        for (int i = 0; i < depth && p instanceof View; i++, p = p.getParent()) {
            if (byId ? suffix.substring(1).equals(Rules.idName((View) p)) : p.getClass().getName().endsWith(suffix)) return (View) p;
        }
        return null;
    }

    /**
     * 抖音搜索页的“猜你想搜”由 Lynx 渲染，文字节点不是 TextView；
     * 对 Lynx 节点补读无障碍节点文本，普通 View 仍走原来的轻量路径。
     */
    static CharSequence viewText(View v) {
        if (v instanceof TextView) return ((TextView) v).getText();
        String name = v.getClass().getName();
        if (!name.startsWith("com.lynx.tasm.")) return null;
        AccessibilityNodeInfo info = null;
        try {
            info = v.createAccessibilityNodeInfo();
            if (info == null) return null;
            CharSequence value = info.getText();
            if (value == null || value.length() == 0) value = info.getContentDescription();
            return value;
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (info != null) try { info.recycle(); } catch (Throwable ignored) { }
        }
    }

    static void walk(View v, Ctx c) {
        String cn = v.getClass().getName();
        // 首次扫描时也要识别已经处于 VISIBLE 的提示，不能只依赖后续 setVisibility 回调。
        pruneSpeedGuides();
        if (isSpeedSignalView(v)) {
            if (speedSignalShown(v)) {
                SPEED_GUIDES.put(v, true);
                hidePendantForSpeed();
            } else {
                SPEED_GUIDES.remove(v);
                pruneSpeedGuides();
            }
        }
        if (cn.endsWith("BottomSpace")) fixSpace(v, c);
        if (cn.endsWith("CoinPendantView")) pendant(v, c);
        if (cn.endsWith("HomeTopTabItemViewNew")) {
            c.tabs.add(v);
            tabCls = v.getClass();
        }
        if (v.getVisibility() == View.GONE) {
            WeakReference<View> w = HIDDEN.get(v);
            if (w == null) return;
            View src = w.get();
            if (src != null && firstMatch(src, c) != null) return;
            // 来源文字已变化（控件被复用）或规则被关闭：恢复显示
            HIDDEN.remove(v);
            int[] size = SIZE.remove(v);
            if (size != null) {
                ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                lp.width = size[0];
                lp.height = size[1];
                lp.setMargins(size[2], size[3], size[4], size[5]);
                v.setLayoutParams(lp);
            }
            v.setVisibility(View.VISIBLE);
        }
        Rules.R r;
        CharSequence mt = viewText(v), md = v.getContentDescription();
        int key = 31 * (31 * (31 * (31 * (mt == null ? 0 : mt.toString().hashCode()) + (md == null ? 0 : md.toString().hashCode())) + ctxSig(v)) + (c.live ? 1 : 0)) + (c.inLive > 0 ? 2 : 0) + (c.overlay ? 4 : 0);
        Integer seen = NOMATCH.get(v);
        if (seen != null && seen == key) {
            r = null;
        } else {
            r = firstMatch(v, c);
            if (r == null) NOMATCH.put(v, key);
        }
        if (r != null && r.live && !c.live) r = null;
        if (r != null && !r.live && c.inLive > 0) r = null;
        CharSequence vt = viewText(v);
        boolean alt = r != null && r.altAnc != null && r.viaAlt(v, vt, v.getContentDescription());   // 靠 or(...) 的文字命中，走另一条定位路径
        if (alt && r.altNeed != null && ancestor(v, r.altNeed, 10) == null) {   // 不在要求的容器里（比如不是评论区）：这次命中作废
            r = null;
            alt = false;
        }
        if (r != null && r.veto != null && ancestor(v, r.veto) != null) r = null;
        if (r != null && (r.mode == Rules.DISMISS || (r.closes && r.viaAlt(v, vt, v.getContentDescription()))) && v.getHeight() > 0) {   // 靠文字命中的控件在对话框里：直接关掉对话框（只认文字，不认 sel，免得误关别的对话框）
            WeakReference<Dialog> w = DIALOG.get(c.root);
            final Dialog d = w == null ? null : w.get();
            if (d != null) {
                c.root.setAlpha(0f);   // 先让它看不见，再关
                matched++;
                handler().post(new Runnable() {
                    @Override
                    public void run() { d.dismiss(); }
                });
                return;
            }
            if (r.mode == Rules.DISMISS) r = null;
        }
        if (r != null && !alt && r.need != null && ancestor(v, r.need, r.depth) == null) r = null;
        if (r != null && r.mode == Rules.CLEARUP) {   // 清掉最近的 anc 祖先（和它同类的父容器）的背景，继续往下扫
            View b = ancestor(v, r.anc, r.depth);
            if (b != null) {
                clearBg(b);
                if (b.getParent() instanceof View && b.getParent().getClass().getName().endsWith(r.anc)) clearBg((View) b.getParent());
            }
            r = null;
        }
        if (r != null && r.mode == Rules.CLEAR) {   // 只清背景，继续往下扫
            if (alt) {   // 靠文字命中（合集条的各种样式）：从最近的 anc 祖先起，整棵栏里所有整宽的背景层都清掉
                View bar = ancestor(v, r.altAnc, r.depth);
                if (bar != null) clearTree(bar, bar.getWidth(), 0);
            } else {
                clearBg(v);
            }
            r = null;
        }
        if (r != null && r.mode == Rules.ROOT) {   // 整个提示窗口：透明并挪到屏幕外（不改可见性，免得窗口重新布局跑到屏幕上方）；Activity 自己的窗口永远不动
            if (!MAIN.containsKey(c.root) && c.root.getTranslationX() > -10000f) {
                c.root.setAlpha(0f);
                c.root.setTranslationX(-20000f);
                matched++;
            }
            return;
        }
        View target = null;
        if (r != null && r.mode != Rules.DISMISS && (r.mode == Rules.TEXT_ONLY || v.getHeight() > 0)) {
            View up = !alt ? null : "@poi".equals(r.altAnc) ? poiBox(v, c) : ancestor(v, r.altAnc, r.depth);
            target = alt ? (up != null ? up : v) : climb(v, r, c);
            if (target != null && touchesSearch(target)) target = null;   // 搜索框永远不隐藏
        }
        if (target != null) {
            matched++;
            HIDDEN.put(target, new WeakReference<View>(v));
            if (target.getVisibility() != View.GONE) {
                target.setVisibility(View.GONE);
                // RecyclerView 里的条目 GONE 后仍会占位（宽高 + 条目间距），需要把宽高和间距都收成 0，否则后面的条目会被推偏
                if (isRecycler(target.getParent()) && target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) target.getLayoutParams();
                    int[] d = decor(target);
                    SIZE.put(target, new int[]{lp.width, lp.height, lp.leftMargin, lp.topMargin, lp.rightMargin, lp.bottomMargin});
                    lp.width = 0;
                    lp.height = 0;
                    lp.setMargins(-d[0], -d[1], -d[2], -d[3]);   // 外边距 + 分隔装饰 = 0
                    target.setLayoutParams(lp);
                }
            }
            return;
        }
        if (v instanceof ViewGroup) {
            if (c.nav && cn.endsWith("MainBottomTabContainer")) fixNav((ViewGroup) v, c, 0);
            ViewGroup g = (ViewGroup) v;
            boolean liveCls = cn.contains(".live.") || cn.contains("LiveSub") || cn.contains("LiveMeasure") || cn.endsWith("LiveFrameLayout");
            if (liveCls) c.inLive++;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c);
            if (liveCls) c.inLive--;
            if (v instanceof GridLayout) reflowGrid((GridLayout) v);
            if (cn.endsWith("MainTabStripScrollView")) centerTabs(v, c);
            if (cn.endsWith("FeedRightScaleView")) shiftColumn(v, c);
            if (cn.endsWith("VideoPinchViewContainer")) fitVideo(g, c);
        }
    }

    static String myName = "";

    /** 控件所在容器链（最多 6 层）的指纹：need / altNeed 都看容器，换了容器“没命中”的缓存就要作废。 */
    static int ctxSig(View v) {
        int h = 0;
        ViewParent p = v.getParent();
        for (int i = 0; i < 6 && p instanceof View; i++, p = p.getParent()) h = 31 * h + System.identityHashCode(p.getClass());
        return h;
    }

    /** 这个控件（含子孙）里有没有文字包含“我的昵称”。 */
    static boolean isMine(View v) {
        if (myName.isEmpty()) return false;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.toString().contains(myName)) return true;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (isMine(g.getChildAt(i))) return true;
        }
        return false;
    }

    /** 顶部标签项现在是不是选中状态（选中时抖音会把描述改成“已选中，xx，按钮”）。 */
    static boolean selected(View tab) {
        CharSequence d = tab.getContentDescription();
        return tab.isSelected() || (d != null && d.toString().startsWith("已选中"));
    }

    static int prevSel = -1;
    static Class<?> tabCls;
    static final List<WeakReference<View>> lastTabs = new ArrayList<>();

    /** 顶部标签项被选中的瞬间（刚滑进某一页）：选中的是被隐藏的，就跳到下一个没被隐藏的；否则记下当前页。 */
    static void onTabSelected(final View tab) {
        int idx = -1;
        for (int i = 0; i < lastTabs.size(); i++) if (lastTabs.get(i).get() == tab) { idx = i; break; }
        if (idx < 0) return;
        if (!HIDDEN.containsKey(tab)) {
            prevSel = idx;
            return;
        }
        int dir = prevSel >= 0 && idx < prevSel ? -1 : 1;   // 从哪个方向滑进来的，就继续往那个方向找
        int to = idx + dir;
        while (to >= 0 && to < lastTabs.size() && (lastTabs.get(to).get() == null || HIDDEN.containsKey(lastTabs.get(to).get()))) to += dir;
        if (to < 0 || to >= lastTabs.size()) return;
        final View target = lastTabs.get(to).get();
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (selected(tab) && target != null) target.performClick();   // 等松手、翻页落定后再点，避免和手势打架
            }
        }, 150);
    }

    /**
     * 隐藏了顶部「直播」等标签后，左右滑动仍会滑进被隐藏的那一页。每次扫描看一下当前选中的顶部标签：
     * 如果选中的是被隐藏的，就顺着刚才滑动的方向点一下下一个没被隐藏的标签（等同于用手点它），
     * 这样不用碰抖音的 ViewPager 内部实现。
     */
    static void selectVisibleTab(List<View> tabs) {
        int sel = -1;
        for (int i = 0; i < tabs.size(); i++) if (selected(tabs.get(i))) { sel = i; break; }
        if (sel < 0) return;
        if (!HIDDEN.containsKey(tabs.get(sel))) {
            prevSel = sel;
            return;
        }
        int dir = prevSel >= 0 && sel < prevSel ? -1 : 1;
        int to = sel + dir;
        while (to >= 0 && to < tabs.size() && HIDDEN.containsKey(tabs.get(to))) to += dir;
        if (to < 0 || to >= tabs.size()) return;
        final View target = tabs.get(to);
        handler().post(new Runnable() {
            @Override
            public void run() { target.performClick(); }
        });
    }

    static final Map<View, Float> FITS = new WeakHashMap<>();   // 被我们缩放过的视频画面 → 当时设的缩放值
    static final Map<View, Float> FIT_ORIG_TX = new WeakHashMap<>(); // 缩放前的视频水平位移，用于关闭功能时还原
    static final Map<View, Boolean> FIT_LISTENED = new WeakHashMap<>();

    /**
     * 9:16 视频不裁切：抖音把它放大到比容器还宽（左右被裁），这里缩回到刚好等于容器宽度，上下留黑边。
     * 每次扫描、以及画面自己重新布局的同一帧里（后台切回前台时抖音会重排视频），都按“容器宽度 ÷ 画面宽度”重新算缩放和居中位移。
     */
    static void fitVideo(ViewGroup box, Ctx c) {
        for (int i = 0; i < box.getChildCount(); i++) {
            View vid = box.getChildAt(i);
            if (vid.getWidth() == 0 || vid.getHeight() == 0) continue;
            if (!c.fit || Math.abs((float) vid.getWidth() / vid.getHeight() - 9f / 16f) >= 0.012f) {
                releaseFit(vid);
                continue;
            }
            if (FIT_LISTENED.put(vid, true) == null) {
                vid.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
                    if (FITS.containsKey(v) && v.getWidth() > 0 && v.getParent() instanceof View) fitNow(v, (View) v.getParent());
                });
            }
            fitNow(vid, box);
        }
    }

    /** 容器处于缩放动画/临时窄宽度时不动；否则缩到容器宽度并居中。画面已经不比容器宽（被抖音重新布局成适配宽度）时，撤掉旧缩放，否则左右会出现黑边。 */
    static void fitNow(View vid, View box) {
        int target = box.getWidth(), w = vid.getWidth();
        if (target <= 0 || box.getScaleX() != 1f || box.getScaleY() != 1f) return;
        if (w <= target + 2) {
            releaseFit(vid);
            return;
        }
        float scale = (float) target / w;
        FIT_ORIG_TX.putIfAbsent(vid, vid.getTranslationX());
        FITS.put(vid, scale);
        vid.setPivotX(w / 2f);
        vid.setPivotY(vid.getHeight() / 2f);
        if (vid.getScaleX() != scale) {
            vid.setScaleX(scale);
            vid.setScaleY(scale);
        }
        vid.setTranslationX(fitTx(vid, box));   // 缩放支点在视频中心，把中心对齐容器中心
    }

    static float fitTx(View vid, View box) {
        return box.getWidth() / 2f - (vid.getLeft() + vid.getWidth() / 2f);
    }

    static void releaseFit(View vid) {
        if (FITS.remove(vid) == null) return;
        vid.setScaleX(1f);
        vid.setScaleY(1f);
        Float tx = FIT_ORIG_TX.remove(vid);
        if (tx != null) vid.setTranslationX(tx);
    }

    /**
     * 地点卡片（评论区上方“城市 | 地点名”、或“N万人打卡”那种）整块的范围：从命中的文字往上，
     * 取“宽度不到屏幕 90%、高度不到屏幕 25%”的最大一层。上到评论列表那一层（整宽）就停，
     * 所以收掉的正好是卡片本身，不会把整个评论区也抹掉。
     */
    static View poiBox(View v, Ctx c) {
        View best = v;
        ViewParent q = v.getParent();
        for (int i = 0; i < 8 && q instanceof View; i++) {
            View a = (View) q;
            if (a.getWidth() > c.sw * 0.9f || a.getHeight() > c.sh * 0.25f) break;
            best = a;
            q = a.getParent();
        }
        return best;
    }


    static boolean has(View v, String cls, int depth) {
        if (v.getClass().getName().contains(cls)) return true;
        if (depth < 30 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (has(g.getChildAt(i), cls, depth + 1)) return true;
        }
        return false;
    }

    /** 窗口是不是直播间：最上面 3 层里有直播的根容器（LiveFrameLayout）。首页里的“直播”标签页不算——它的外层是普通容器。 */
    static boolean hasLive(View v, int depth) {
        if (v.getClass().getName().endsWith("LiveFrameLayout")) return true;
        if (depth < 3 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasLive(g.getChildAt(i), depth + 1)) return true;
        }
        return false;
    }

    /** 整个窗口里有没有已开启的“整窗隐藏”规则要隐藏的文字（Toast / 弹出提示 / 对话框式提示）。 */
    static boolean blocked(View v) {
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.length() > 0) {
                for (Rules.R r : Rules.ALL) if (r.mode == Rules.ROOT && on(r.key(), true) && r.textHit(t)) return true;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (blocked(g.getChildAt(i))) return true;
        }
        return false;
    }

    /** 父容器是（或继承自）RecyclerView：类名里带 RecyclerView 即可。 */
    static boolean isRecycler(ViewParent p) {
        for (Class<?> k = p.getClass(); k != null; k = k.getSuperclass()) if (k.getName().contains("RecyclerView")) return true;
        return false;
    }

    /** 目标本身是搜索框（输入框 / id 含 search），或里面包着搜索框：不隐藏。 */
    static boolean touchesSearch(View t) {
        String id = Rules.idName(t);
        if (t instanceof android.widget.EditText || (id != null && id.toLowerCase().contains("search"))) return true;
        if (t instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) t;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch.getVisibility() != View.GONE && touchesSearch(ch)) return true;
            }
        }
        return false;
    }

    // ---------- 找到“整个入口”并隐藏 ----------
    static View climb(View v, Rules.R r, Ctx c) {
        if (r.mode == Rules.TEXT_ONLY) return v;
        if (r.mode == Rules.BOX) {   // 往上取宽、高都不超限的最大祖先：整张卡片 / 整个图标格子
            View best = v, safe = null;
            ViewParent q = v.getParent();
            for (int i = 0; i < 12 && q instanceof View; i++) {
                View a = (View) q;
                if (a.getWidth() > c.sw * r.bw || a.getHeight() > c.sh * r.bh) break;
                best = a;
                if (!touchesSearch(a)) safe = a;   // 一路往上，记住“不含搜索框”的最大那一层：往里取到搜索框整块就不会被抹掉
                if (isRecycler(a.getParent())) break;   // 到列表条目的根就停，整条内容一起收，不碰整个列表
                q = a.getParent();
            }
            return safe != null ? safe : best;
        }
        if (r.mode == Rules.PARENT) {   // 按类名找到 anc，隐藏它的父容器
            View a = ancestor(v, r.anc, r.depth);
            if (a != null && a.getParent() instanceof View) return (View) a.getParent();
        }
        if (r.mode == Rules.CHILD) {   // 广告/汽水听栏：只收掉 MeasureOnceFrameLayout 下包着它的那一块，同栏的相关搜索、合集条不受影响
            View bar = ancestor(v, r.anc, r.depth);
            if (bar != null) {
                View x = v;
                while (x.getParent() != bar) x = (View) x.getParent();
                return x;
            }
        }
        if (r.mode == Rules.CARD) {   // 整张卡片：最近的 MeasureOnceFrameLayout；它的外层如果只装着它，连外层一起收掉，不留空位
            View card = ancestor(v, "MeasureOnceFrameLayout", r.depth);
            if (card != null && card.getHeight() < c.sh * 0.3f) {
                if (card.getParent() instanceof ViewGroup && ((ViewGroup) card.getParent()).getChildCount() == 1
                        && ((View) card.getParent()).getHeight() <= card.getHeight() + 8 * c.density) return (View) card.getParent();
                return card;
            }
        }
        // UP：指定祖先；长按菜单里的条目：隐藏整行（图标+文字+分隔线）
        View up = ancestor(v, r.mode == Rules.UP ? r.anc : "LongPressPanelCommonItemView");
        if (up != null) return up;
        if (r.mode == Rules.UP) return v;
        // 常用功能这类系统 GridLayout：隐藏整个单元（图标+文字）
        View cell = v;
        for (int i = 0; i < 4 && cell.getParent() instanceof ViewGroup; i++) {
            if (cell.getParent() instanceof GridLayout) return cell;
            cell = (View) cell.getParent();
        }
        int h = v.getHeight();
        View cur = v;
        for (int i = 0; i < 4 && cur.getParent() instanceof ViewGroup; i++) {
            ViewGroup g = (ViewGroup) cur.getParent();
            String n = g.getClass().getName();
            if (n.contains("RecyclerView") || n.contains("ScrollView") || n.contains("ViewPager")
                    || n.contains("CardModuleView") || n.contains("RoundedFrameLayout")
                    || g instanceof android.widget.AbsListView) break;
            int same = 0, kids = 0;
            for (int k = 0; k < g.getChildCount(); k++) {
                View ch = g.getChildAt(k);
                if (ch.getVisibility() == View.GONE) continue;
                kids++;
                if (ch.getClass() == cur.getClass()) same++;   // cur 已经是列表里的一项
            }
            if (same >= 2 || kids > 3 || g.getWidth() > c.sw * 0.9f || g.getHeight() > h * 3.5f + 16 * c.density) break;
            cur = g;
        }
        return cur;
    }

    /** 清掉控件及与它同高的父容器、与它同宽的子容器的背景（按钮等内部小控件的背景保留）。 */
    static void clearTree(View v, int barWidth, int depth) {
        if (v.getWidth() >= barWidth * 0.85f) strip(v);
        if (depth < 5 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch.getVisibility() != View.GONE && ch.getWidth() >= barWidth * 0.85f) clearTree(ch, barWidth, depth + 1);
            }
        }
    }

    static void clearBg(View v) {
        strip(v);
        if (v.getParent() instanceof View && ((View) v.getParent()).getHeight() <= v.getHeight() * 1.5f) strip((View) v.getParent());
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (g.getChildAt(i).getWidth() >= v.getWidth() * 0.9f) strip(g.getChildAt(i));
            }
        }
    }

    static void strip(View x) {
        Drawable b = x.getBackground();
        if (b != null) {
            BG_ORIG.put(x, b);
            x.setBackground(null);
        }
    }

    static void restoreBg() {
        for (Map.Entry<View, Drawable> e : new ArrayList<>(BG_ORIG.entrySet())) e.getKey().setBackground(e.getValue());
        BG_ORIG.clear();
    }

    static boolean hasDesc(View v, String d) {
        if (v.getVisibility() != View.VISIBLE) return false;
        if (d.contentEquals(String.valueOf(v.getContentDescription()))) return true;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (hasDesc(g.getChildAt(i), d)) return true;
        }
        return false;
    }

    /** 右侧点赞/评论/收藏/分享一列：唱片行隐藏后，整体下移该行的高度，补上空位。 */
    static void shiftColumn(View col, Ctx c) {
        float dy = 0f;
        if (c.disc) {
            ViewGroup p = (ViewGroup) col.getParent();
            for (int i = 0; i < p.getChildCount(); i++) {
                View s = p.getChildAt(i);
                // 唱片行里是"听抖音"按钮（占着原来的位置）时，不下移
                if (s.getClass().getName().endsWith("FpsControlFrameLayout") && !hasDesc(s, "听抖音")) dy = s.getHeight();
            }
        }
        if (col.getTranslationY() != dy) col.setTranslationY(dy);
    }

    // ---------- 网格重排：隐藏后把剩下的单元顺序补位 ----------
    static GridLayout.Spec specAt(GridLayout.Spec old, int start) {
        GridLayout.Alignment a = (GridLayout.Alignment) XposedHelpers.getObjectField(old, "alignment");
        return GridLayout.spec(start, 1, a, XposedHelpers.getFloatField(old, "weight"));
    }

    static void reflowGrid(GridLayout g) {
        int cols = g.getColumnCount();
        if (cols <= 0) return;
        int n = g.getChildCount();
        boolean any = false;
        StringBuilder sig = new StringBuilder();
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            if (HIDDEN.containsKey(ch)) any = true;
            sig.append(ch.getVisibility() == View.GONE ? '0' : '1');
        }
        String now = any ? sig.toString() : "";
        String prev = GRID_SIG.get(g);
        if (now.equals(prev == null ? "" : prev)) return;
        GRID_SIG.put(g, now);
        gridFixed++;
        int k = 0;
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) ch.getLayoutParams();
            if (!any) {
                Object[] o = ORIG_SPECS.remove(ch);
                if (o != null) {
                    lp.rowSpec = (GridLayout.Spec) o[0];
                    lp.columnSpec = (GridLayout.Spec) o[1];
                    ch.setLayoutParams(lp);
                }
                continue;
            }
            if (ch.getVisibility() == View.GONE) continue;
            if (!ORIG_SPECS.containsKey(ch)) ORIG_SPECS.put(ch, new Object[]{lp.rowSpec, lp.columnSpec});
            lp.rowSpec = specAt(lp.rowSpec, k / cols);
            lp.columnSpec = specAt(lp.columnSpec, k % cols);
            ch.setLayoutParams(lp);
            k++;
        }
    }

    // ---------- 顶部标签：隐藏后剩下的居中 ----------
    static void centerTabs(View strip, Ctx c) {
        ViewGroup rl = (ViewGroup) ((ViewGroup) strip).getChildAt(0);
        boolean anyHidden = false;
        int minL = Integer.MAX_VALUE, maxR = Integer.MIN_VALUE;
        int[] loc = new int[2];
        for (int i = 0; i < rl.getChildCount(); i++) {
            View it = rl.getChildAt(i);
            if (!it.getClass().getName().contains("TabItem")) continue;
            if (it.getVisibility() == View.GONE) {
                anyHidden |= HIDDEN.containsKey(it);
            } else if (it.getWidth() > 0) {
                it.getLocationOnScreen(loc);
                minL = Math.min(minL, loc[0]);
                maxR = Math.max(maxR, loc[0] + it.getWidth());
            }
        }
        if (!c.center || !anyHidden || minL == Integer.MAX_VALUE) {
            if (CENTERED.remove(strip) != null) strip.setTranslationX(0f);
            return;
        }
        View bar = strip;
        for (int i = 0; i < 6 && bar.getParent() instanceof View; i++) {
            bar = (View) bar.getParent();
            if (bar.getClass().getName().endsWith("MainTitleBar")) break;
        }
        int[] bl = new int[2];
        bar.getLocationOnScreen(bl);
        float d = (bl[0] + bar.getWidth() / 2f) - (minL + maxR) / 2f;
        if (Math.abs(d) > 2f) {
            strip.setTranslationX(strip.getTranslationX() + d);
            CENTERED.put(strip, true);
            centerFixed++;
        }
    }

    // ---------- 底栏透明：容器背景清空，背景图/分割线设为 INVISIBLE（并拦截抖音重新设回可见/背景） ----------
    static void fixNav(ViewGroup g, Ctx c, int depth) {
        stripNav(g);
        for (int i = 0; i < g.getChildCount(); i++) {
            View ch = g.getChildAt(i);
            String n = ch.getClass().getName();
            if (n.endsWith("BottomTab") || n.endsWith("PublishButton")) continue;   // 图标和文字保持不透明
            if (ch instanceof ViewGroup) {
                if (depth < 4) fixNav((ViewGroup) ch, c, depth + 1);
            } else if (ch.getVisibility() == View.VISIBLE && ch.getWidth() >= c.sw * 0.9f) {
                NAV_BG.put(ch, View.VISIBLE);
                ch.setVisibility(View.INVISIBLE);
                navFixed++;
            }
        }
    }

    static void stripNav(View x) {
        if (NAV_PAR.containsKey(x)) return;
        Drawable b = x.getBackground();
        NAV_PAR.put(x, b);   // 没有背景的容器也登记，抖音之后再设背景时同样会被拦住
        if (b != null) {
            x.setBackground(null);
            navFixed++;
        }
    }

    static void restoreNav() {
        for (View x : new ArrayList<View>(NAV_BG.keySet())) {
            Integer o = NAV_BG.remove(x);
            if (o != null) x.setVisibility(o);
        }
        for (Map.Entry<View, Drawable> e : new ArrayList<>(NAV_PAR.entrySet())) {
            NAV_PAR.remove(e.getKey());
            e.getKey().setBackground(e.getValue());
        }
    }

    // ---------- 红包挂件缩放（贴哪边就以哪边的中点为轴，缩放后仍贴边） ----------
    /** 红包挂件拖拽状态：downRawX, downRawY, 按下时 translationX, translationY, 是否正在拖。 */
    static final Map<View, float[]> DRAG = new WeakHashMap<>();
    static float[] savedPos;   // 拖放后挂件左上角在父容器里的绝对位置 x、y；null = 没拖过，保持抖音原位置（用绝对位置：抖音把挂件的布局位置挪动后也能原样放回去）

    static Context app() {
        return (Application) XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
    }

    static SharedPreferences posPrefs() {
        return app().getSharedPreferences("dyhide_pendant", Context.MODE_PRIVATE);
    }

    /** 拖拽钩子：挂件被手指拖动超过 touch slop 后，改为跟手移动并吃掉后续事件；没拖动的点按照常交给抖音。 */
    static void hookPendantDrag() {
        XposedBridge.hookMethod(XposedHelpers.findMethodExact(ViewGroup.class, "dispatchTouchEvent", MotionEvent.class), new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) throws Throwable {
                float[] s = DRAG.get(p.thisObject);
                if (s == null) return;
                View v = (View) p.thisObject;
                MotionEvent e = (MotionEvent) p.args[0];
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    s[0] = e.getRawX();
                    s[1] = e.getRawY();
                    s[2] = v.getTranslationX();
                    s[3] = v.getTranslationY();
                    s[4] = 0f;
                    return;
                }
                if (a == MotionEvent.ACTION_MOVE && s[4] == 0f
                        && Math.hypot(e.getRawX() - s[0], e.getRawY() - s[1]) > ViewConfiguration.get(v.getContext()).getScaledTouchSlop()) {
                    s[4] = 1f;
                    MotionEvent cancel = MotionEvent.obtain(e);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    ViewGroup g = (ViewGroup) v;
                    for (int i = 0; i < g.getChildCount(); i++) g.getChildAt(i).dispatchTouchEvent(cancel);   // 让挂件里的按钮放弃这次点按
                    cancel.recycle();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (s[4] == 0f) return;
                if (a == MotionEvent.ACTION_MOVE) {
                    View par = (View) v.getParent();
                    float tx = Math.max(-v.getLeft(), Math.min(par.getWidth() - v.getWidth() - v.getLeft(), s[2] + e.getRawX() - s[0]));
                    float ty = Math.max(-v.getTop(), Math.min(par.getHeight() - v.getHeight() - v.getTop(), s[3] + e.getRawY() - s[1]));
                    v.setTranslationX(tx);
                    v.setTranslationY(ty);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    s[4] = 0f;
                    savedPos = new float[]{v.getLeft() + v.getTranslationX(), v.getTop() + v.getTranslationY()};
                    posPrefs().edit().putFloat("ax", savedPos[0]).putFloat("ay", savedPos[1]).apply();
                }
                p.setResult(true);
            }
        });
    }

    /** 每次扫描把拖放过的位置重新套上（抖音自己会把挂件挪回去）；设置页点“重置位置”则清掉。 */
    static void applyPendantPos(View v) {
        SharedPreferences pp = posPrefs();
        long reset = sp == null ? 0 : sp.getLong("pendant_reset", 0);
        if (pp.getLong("reset_seen", 0) != reset) {
            pp.edit().clear().putLong("reset_seen", reset).apply();
            savedPos = null;
            v.setTranslationX(0f);
            v.setTranslationY(0f);
            return;
        }
        if (savedPos == null && pp.contains("ax")) savedPos = new float[]{pp.getFloat("ax", 0f), pp.getFloat("ay", 0f)};
        else if (savedPos == null && pp.contains("tx")) savedPos = new float[]{v.getLeft() + pp.getFloat("tx", 0f), v.getTop() + pp.getFloat("ty", 0f)};   // 旧版保存的是偏移量
        placePendant(v);
    }

    static void placePendant(View v) {
        float[] s = DRAG.get(v);
        if (savedPos == null || s == null || s[4] != 0f) return;
        float tx = savedPos[0] - v.getLeft(), ty = savedPos[1] - v.getTop();
        float eps = 8f * v.getResources().getDisplayMetrics().density;   // 差几 dp 不动：避免和抖音自己的小动画互相拉扯
        if (Math.abs(v.getTranslationX() - tx) > eps || Math.abs(v.getTranslationY() - ty) > eps) {
            v.setTranslationX(tx);
            v.setTranslationY(ty);
        }
    }

    static void pendant(View v, Ctx c) {
        PENDANTS.put(v, true);
        // 倍速期间新创建的红包挂件尚无历史状态；按正常可见状态作为恢复基线，避免记录模块隐藏后的 INVISIBLE。
        if (speedPendantHidden) {
            PENDANT_VIS.putIfAbsent(v, View.VISIBLE);
            settingPendantVisibility = true;
            try { v.setVisibility(View.INVISIBLE); }
            finally { settingPendantVisibility = false; }
        }
        if (v.getWidth() == 0) return;
        if (!DRAG.containsKey(v)) {
            DRAG.put(v, new float[5]);
            v.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {   // 抖音一重新布局（切页、回前台）就在同一帧里放回去，不会先跳一下
                @Override
                public void onLayoutChange(View view, int l, int t, int r, int b, int ol, int ot, int or, int ob) { placePendant(view); }
            });
        }
        applyPendantPos(v);
        boolean was = PENDANT.containsKey(v);
        if (c.pendant == 1f && !was) return;
        boolean right = v.getLeft() + v.getTranslationX() + v.getWidth() / 2f > c.sw / 2f;
        Boolean prev = PENDANT.get(v);
        if (prev == null || prev != right) {
            v.setPivotX(right ? v.getWidth() : 0f);
            v.setPivotY(v.getHeight() / 2f);
            PENDANT.put(v, right);
        }
        if (v.getScaleX() != c.pendant) {
            v.setScaleX(c.pendant);
            v.setScaleY(c.pendant);
        }
        if (c.pendant == 1f) PENDANT.remove(v);
    }

    /** RecyclerView 条目四周的分隔装饰宽度（左、上、右、下）；取不到就当 0。 */
    static int[] decor(View item) {
        try {
            Object lm = XposedHelpers.callMethod(item.getParent(), "getLayoutManager");
            return new int[]{(Integer) XposedHelpers.callMethod(lm, "getLeftDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getTopDecorationHeight", item),
                    (Integer) XposedHelpers.callMethod(lm, "getRightDecorationWidth", item),
                    (Integer) XposedHelpers.callMethod(lm, "getBottomDecorationHeight", item)};
        } catch (Throwable t) {   // 方法名被混淆时才会走到这里
            return new int[4];
        }
    }

    /** 视频区域底部的占位（BottomSpace，高度=底栏）收起，视频铺满到底栏下方。 */
    static void fixSpace(View v, Ctx c) {
        if (c.nav && c.extend) {
            if (!SPACE.containsKey(v)) SPACE.put(v, v.getVisibility());
            if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
        } else {
            Integer o = SPACE.remove(v);
            if (o != null) v.setVisibility(o);
        }
    }

    // ---------- 状态 / 调试 ----------
    static void write(String name, String text) throws Exception {
        FileOutputStream o = new FileOutputStream(new File(app().getExternalFilesDir(null), name));
        try { o.write(text.getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
    }

    /** viewdump 直接写到 内部存储/Download。Android 10+ 走 MediaStore（同名文件原地覆盖），更低版本直接写文件。 */
    static void download(String name, String text) throws Exception {
        Context ctx = app();
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (android.os.Build.VERSION.SDK_INT < 29) {
            FileOutputStream o = new FileOutputStream(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name));
            try { o.write(bytes); } finally { o.close(); }
            return;
        }
        ContentResolver cr = ctx.getContentResolver();
        Uri col = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        Uri uri = null;
        Cursor q = cr.query(col, new String[]{MediaStore.MediaColumns._ID},
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                new String[]{name, "Download/"}, null);
        try { if (q != null && q.moveToFirst()) uri = ContentUris.withAppendedId(col, q.getLong(0)); } finally { if (q != null) q.close(); }
        if (uri == null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/");
            uri = cr.insert(col, v);
        }
        java.io.OutputStream o = cr.openOutputStream(uri, "wt");
        try { o.write(bytes); } finally { o.close(); }
    }

    static void status() throws Exception {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatus < 5000) return;
        lastStatus = now;
        write("dyhide_status.txt", "scans=" + scans + "\nhidden_hits=" + matched + "\nnav_fixes=" + navFixed
                + "\ngrid_reflows=" + gridFixed + "\ntab_centerings=" + centerFixed
                + "\nlast_root=" + lastRoot + "\nsdk=" + android.os.Build.VERSION.SDK_INT + "\n");
    }

    static void dump(View root) throws Exception {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_DUMP.get(root);
        if (last != null && now - last < 3000) return;
        LAST_DUMP.put(root, now);
        StringBuilder sb = new StringBuilder();
        sb.append("root=").append(root.getClass().getName()).append(' ')
                .append(root.getWidth()).append('x').append(root.getHeight()).append('\n');
        dumpNode(root, 0, sb);
        download((hasLive(root, 0) ? "viewdump_live_" + (System.identityHashCode(root) & 3) : has(root, "SearchMiddlePageRecyclerView", 0) ? "viewdump_search" : has(root, "ProfileBubbleLayout", 0) ? "viewdump_profile" : "viewdump_" + (System.identityHashCode(root) & 15)) + ".txt", sb.toString());   // 直播、搜索页、主页各自固定文件名，不会被别的窗口覆盖   // 直播窗口单独存，不会被别的窗口覆盖
    }

    static void dumpNode(View v, int depth, StringBuilder sb) {
        if (sb.length() > 600000) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            String n;
            try { n = v.getResources().getResourceEntryName(id); } catch (Throwable t) { n = Integer.toHexString(id); }
            sb.append(" #").append(n);
        }
        if (v instanceof TextView && ((TextView) v).getText().length() > 0)
            sb.append(" text=\"").append(cut(((TextView) v).getText())).append('"');
        if (v.getContentDescription() != null)
            sb.append(" desc=\"").append(cut(v.getContentDescription())).append('"');
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
                .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
        if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
        if (HIDDEN.containsKey(v)) sb.append(" HIDDEN");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpNode(g.getChildAt(i), depth + 1, sb);
        }
    }

    static String cut(CharSequence s) {
        String x = s.toString().replace('\n', ' ');
        return x.length() > 40 ? x.substring(0, 40) : x;
    }
}
