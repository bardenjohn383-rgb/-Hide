package com.dyhide;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    static final String TARGET = "com.ss.android.ugc.aweme";
    static final String MODULE = "com.dyhide";
    static Handler H;
    static final Map<View, Boolean> PENDING = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, WeakReference<View>> HIDDEN = Collections.synchronizedMap(new WeakHashMap<View, WeakReference<View>>());
    static final Map<View, Long> LAST_DUMP = new WeakHashMap<>();
    static final Map<View, Boolean> ATTACHED = Collections.synchronizedMap(new WeakHashMap<View, Boolean>());
    static final Map<View, String> GRID_SIG = new WeakHashMap<>();
    static final Map<View, Object[]> ORIG_SPECS = new WeakHashMap<>();
    static final Map<View, Boolean> CENTERED = new WeakHashMap<>();
    static final Map<View, Integer> SPACE = Collections.synchronizedMap(new WeakHashMap<View, Integer>());
    static final Map<View, int[]> SIZE = new WeakHashMap<>();
    static final Map<View, Boolean> NAV_TOUCHED = new WeakHashMap<>();
    static XSharedPreferences sp;
    static int scans, matched, navFixed, gridFixed, centerFixed;
    static long lastStatus;
    static String lastRoot = "";

    static synchronized Handler handler() {
        if (H == null) H = new Handler(Looper.getMainLooper());
        return H;
    }

    static final class Ctx {
        int sw, sh;
        float density;
        boolean nav, center, extend, overlay;
        List<Rules.R> rules = new ArrayList<>();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TARGET.equals(lp.packageName)) return;
        sp = new XSharedPreferences(MODULE, "config");
        sp.makeWorldReadable();
        XposedBridge.log("DyHide: loaded in " + lp.processName + " sdk=" + android.os.Build.VERSION.SDK_INT);
        Class<?> vri = XposedHelpers.findClass("android.view.ViewRootImpl", lp.classLoader);
        Set<XC_MethodHook.Unhook> u = XposedBridge.hookAllMethods(vri, "performTraversals", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                schedule((View) XposedHelpers.getObjectField(p.thisObject, "mView"));
            }
        });
        XposedBridge.log("DyHide: performTraversals hooks=" + u.size());
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                attach(((Activity) p.thisObject).getWindow().getDecorView());
            }
        });
        XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                attach(((Dialog) p.thisObject).getWindow().getDecorView());
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (((Integer) p.args[0]) != View.GONE
                        && (HIDDEN.containsKey(p.thisObject) || SPACE.containsKey(p.thisObject))) {
                    p.args[0] = View.GONE;
                }
            }
        });
    }

    static void attach(final View decor) {
        if (ATTACHED.containsKey(decor)) return;
        ATTACHED.put(decor, true);
        decor.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() { schedule(decor); }
        });
        schedule(decor);
    }

    static boolean on(String key, boolean def) {
        return sp == null ? def : sp.getBoolean(key, def);
    }

    static void schedule(final View root) {
        if (PENDING.containsKey(root)) return;
        PENDING.put(root, true);
        handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PENDING.remove(root);
                try { scan(root); } catch (Throwable t) { XposedBridge.log(t); }
            }
        }, 250);
    }

    static void scan(View root) throws Exception {
        if (!root.isAttachedToWindow()) return;
        if (sp != null && sp.hasFileChanged()) sp.reload();
        Ctx c = new Ctx();
        c.sw = root.getResources().getDisplayMetrics().widthPixels;
        c.sh = root.getResources().getDisplayMetrics().heightPixels;
        c.density = root.getResources().getDisplayMetrics().density;
        c.nav = on("nav_transparent", true);
        c.center = on("center_tabs", true);
        c.extend = on("extend_feed", true);
        c.overlay = !(root.getContext() instanceof Activity) || root.getClass().getName().contains("Popup");
        for (Rules.R r : Rules.ALL) if (on(r.key(), true)) c.rules.add(r);
        scans++;
        lastRoot = root.getClass().getName();
        if (scans == 1) XposedBridge.log("DyHide: first scan, rules=" + c.rules.size());
        if (!c.nav) restoreNav();
        walk(root, c);
        status();
        if (on("dump", true)) dump(root);
    }

    static Rules.R firstMatch(View v, Ctx c) {
        CharSequence t = v instanceof TextView ? ((TextView) v).getText() : null;
        CharSequence d = v.getContentDescription();
        String cls = v.getClass().getName();
        String id = Rules.NEED_ID ? Rules.idName(v) : null;
        for (Rules.R r : c.rules) {
            if ((!r.overlayOnly || c.overlay) && r.matchView(cls, id, t, d)) return r;
        }
        return null;
    }

    static void walk(View v, Ctx c) {
        if (v.getClass().getName().endsWith("BottomSpace")) fixSpace(v, c);
        if (v.getVisibility() == View.GONE) {
            WeakReference<View> w = HIDDEN.get(v);
            if (w == null) return;
            View src = w.get();
            if (src != null && firstMatch(src, c) != null) return;
            // 来源文字已变化（控件被复用）或规则被关闭：恢复显示
            HIDDEN.remove(v);
            int[] size = SIZE.remove(v);
            if (size != null) {
                ViewGroup.LayoutParams lp = v.getLayoutParams();
                lp.width = size[0];
                lp.height = size[1];
                v.setLayoutParams(lp);
            }
            v.setVisibility(View.VISIBLE);
        }
        Rules.R r = firstMatch(v, c);
        if (r != null && (r.mode == Rules.TEXT_ONLY || v.getHeight() > 0)) {
            View target = climb(v, r, c);
            matched++;
            HIDDEN.put(target, new WeakReference<View>(v));
            if (target.getVisibility() != View.GONE) {
                target.setVisibility(View.GONE);
                // RecyclerView 里的条目 GONE 后仍会占位，需要把宽高收成 0
                if (target.getParent().getClass().getName().contains("RecyclerView")) {
                    ViewGroup.LayoutParams lp = target.getLayoutParams();
                    SIZE.put(target, new int[]{lp.width, lp.height});
                    lp.width = 0;
                    lp.height = 0;
                    target.setLayoutParams(lp);
                }
            }
            return;
        }
        if (c.nav && v instanceof TextView && "首页".contentEquals(((TextView) v).getText())) fixNav(v, c);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c);
            if (v instanceof GridLayout) reflowGrid((GridLayout) v);
            if (v.getClass().getName().endsWith("MainTabStripScrollView")) centerTabs(v, c);
        }
    }

    // ---------- 找到“整个入口”并隐藏 ----------
    static View climb(View v, Rules.R r, Ctx c) {
        if (r.mode == Rules.TEXT_ONLY) return v;
        if (r.mode == Rules.CARD) {
            View a = v;
            while (a.getParent() instanceof View && !a.getClass().getName().endsWith("RoundedFrameLayout")) a = (View) a.getParent();
            return a.getClass().getName().endsWith("RoundedFrameLayout") ? a : v;
        }
        // 常用功能这类系统 GridLayout：隐藏整个单元（图标+文字）
        View cell = v;
        for (int i = 0; i < 4 && cell.getParent() instanceof ViewGroup; i++) {
            if (cell.getParent() instanceof GridLayout) return cell;
            cell = (View) cell.getParent();
        }
        int h = v.getHeight();
        View cur = v;
        for (int i = 0; i < 4 && cur.getParent() instanceof ViewGroup; i++) {
            ViewGroup g = (ViewGroup) cur.getParent();
            String n = g.getClass().getName();
            if (n.contains("RecyclerView") || n.contains("ScrollView") || n.contains("ViewPager")
                    || n.contains("CardModuleView") || n.contains("RoundedFrameLayout")
                    || g instanceof android.widget.AbsListView) break;
            int same = 0, kids = 0;
            for (int k = 0; k < g.getChildCount(); k++) {
                View ch = g.getChildAt(k);
                if (ch.getVisibility() == View.GONE) continue;
                kids++;
                if (ch.getClass() == cur.getClass()) same++;   // cur 已经是列表里的一项
            }
            if (same >= 2 || kids > 3 || g.getWidth() > c.sw * 0.9f || g.getHeight() > h * 3.5f + 16 * c.density) break;
            cur = g;
        }
        return cur;
    }

    // ---------- 网格重排：隐藏后把剩下的单元顺序补位 ----------
    static GridLayout.Spec specAt(GridLayout.Spec old, int start) {
        GridLayout.Alignment a = (GridLayout.Alignment) XposedHelpers.getObjectField(old, "alignment");
        return GridLayout.spec(start, 1, a, XposedHelpers.getFloatField(old, "weight"));
    }

    static void reflowGrid(GridLayout g) {
        int cols = g.getColumnCount();
        if (cols <= 0) return;
        int n = g.getChildCount();
        boolean any = false;
        StringBuilder sig = new StringBuilder();
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            if (HIDDEN.containsKey(ch)) any = true;
            sig.append(ch.getVisibility() == View.GONE ? '0' : '1');
        }
        String now = any ? sig.toString() : "";
        String prev = GRID_SIG.get(g);
        if (now.equals(prev == null ? "" : prev)) return;
        GRID_SIG.put(g, now);
        gridFixed++;
        int k = 0;
        for (int i = 0; i < n; i++) {
            View ch = g.getChildAt(i);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) ch.getLayoutParams();
            if (!any) {
                Object[] o = ORIG_SPECS.remove(ch);
                if (o != null) {
                    lp.rowSpec = (GridLayout.Spec) o[0];
                    lp.columnSpec = (GridLayout.Spec) o[1];
                    ch.setLayoutParams(lp);
                }
                continue;
            }
            if (ch.getVisibility() == View.GONE) continue;
            if (!ORIG_SPECS.containsKey(ch)) ORIG_SPECS.put(ch, new Object[]{lp.rowSpec, lp.columnSpec});
            lp.rowSpec = specAt(lp.rowSpec, k / cols);
            lp.columnSpec = specAt(lp.columnSpec, k % cols);
            ch.setLayoutParams(lp);
            k++;
        }
    }

    // ---------- 顶部标签：隐藏后剩下的居中 ----------
    static void centerTabs(View strip, Ctx c) {
        ViewGroup rl = (ViewGroup) ((ViewGroup) strip).getChildAt(0);
        boolean anyHidden = false;
        int minL = Integer.MAX_VALUE, maxR = Integer.MIN_VALUE;
        int[] loc = new int[2];
        for (int i = 0; i < rl.getChildCount(); i++) {
            View it = rl.getChildAt(i);
            if (!it.getClass().getName().contains("TabItem")) continue;
            if (it.getVisibility() == View.GONE) {
                anyHidden |= HIDDEN.containsKey(it);
            } else if (it.getWidth() > 0) {
                it.getLocationOnScreen(loc);
                minL = Math.min(minL, loc[0]);
                maxR = Math.max(maxR, loc[0] + it.getWidth());
            }
        }
        if (!c.center || !anyHidden || minL == Integer.MAX_VALUE) {
            if (CENTERED.remove(strip) != null) strip.setTranslationX(0f);
            return;
        }
        View bar = strip;
        for (int i = 0; i < 6 && bar.getParent() instanceof View; i++) {
            bar = (View) bar.getParent();
            if (bar.getClass().getName().endsWith("MainTitleBar")) break;
        }
        int[] bl = new int[2];
        bar.getLocationOnScreen(bl);
        float d = (bl[0] + bar.getWidth() / 2f) - (minL + maxR) / 2f;
        if (Math.abs(d) > 2f) {
            strip.setTranslationX(strip.getTranslationX() + d);
            CENTERED.put(strip, true);
            centerFixed++;
        }
    }

    // ---------- 底栏透明：背景是一张 ImageView + 一条分割线，不是容器背景 ----------
    static void fixNav(View v, Ctx c) {
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        if (loc[1] < c.sh * 0.8f) return;
        View cur = v;
        for (int i = 0; i < 12; i++) {
            ViewParent p = cur.getParent();
            if (!(p instanceof ViewGroup)) break;
            ViewGroup pv = (ViewGroup) p;
            if (pv.getHeight() > c.sh * 0.2f) break;
            Drawable bg = pv.getBackground();
            if (bg != null && !(bg instanceof ColorDrawable && ((ColorDrawable) bg).getColor() == 0)) {
                pv.setBackgroundColor(Color.TRANSPARENT);
                navFixed++;
            }
            for (int k = 0; k < pv.getChildCount(); k++) {
                View ch = pv.getChildAt(k);
                if (ch == cur || ch.getAlpha() == 0f || ch.getVisibility() == View.GONE) continue;
                boolean wide = ch.getWidth() >= c.sw * 0.9f;
                boolean bgImage = ch instanceof ImageView && wide && ch.getHeight() >= pv.getHeight() * 0.8f;
                boolean divider = wide && ch.getHeight() > 0 && ch.getHeight() <= 4 * c.density && !(ch instanceof ViewGroup);
                boolean bgView = wide && ch.getClass() == View.class && ch.getBackground() != null
                        && ch.getHeight() >= pv.getHeight() * 0.8f;
                if (bgImage || divider || bgView) {
                    ch.setAlpha(0f);
                    NAV_TOUCHED.put(ch, true);
                    navFixed++;
                }
            }
            cur = pv;
        }
    }

    /** 视频区域底部的占位（BottomSpace，高度=底栏）收起，视频铺满到底栏下方。 */
    static void fixSpace(View v, Ctx c) {
        if (c.nav && c.extend) {
            if (!SPACE.containsKey(v)) SPACE.put(v, v.getVisibility());
            if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
        } else {
            Integer o = SPACE.remove(v);
            if (o != null) v.setVisibility(o);
        }
    }

    static void restoreNav() {
        if (NAV_TOUCHED.isEmpty()) return;
        for (View x : new ArrayList<View>(NAV_TOUCHED.keySet())) x.setAlpha(1f);
        NAV_TOUCHED.clear();
    }

    // ---------- 状态 / 调试 ----------
    static File outDir() throws Exception {
        Application app = (Application) Class.forName("android.app.ActivityThread")
                .getMethod("currentApplication").invoke(null);
        return app.getExternalFilesDir(null);
    }

    static void write(String name, String text) throws Exception {
        FileOutputStream o = new FileOutputStream(new File(outDir(), name));
        try { o.write(text.getBytes(StandardCharsets.UTF_8)); } finally { o.close(); }
    }

    static void status() throws Exception {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatus < 5000) return;
        lastStatus = now;
        write("dyhide_status.txt", "scans=" + scans + "\nhidden_hits=" + matched + "\nnav_fixes=" + navFixed
                + "\ngrid_reflows=" + gridFixed + "\ntab_centerings=" + centerFixed
                + "\nlast_root=" + lastRoot + "\nsdk=" + android.os.Build.VERSION.SDK_INT + "\n");
    }

    static void dump(View root) throws Exception {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_DUMP.get(root);
        if (last != null && now - last < 3000) return;
        LAST_DUMP.put(root, now);
        StringBuilder sb = new StringBuilder();
        sb.append("root=").append(root.getClass().getName()).append(' ')
                .append(root.getWidth()).append('x').append(root.getHeight()).append('\n');
        dumpNode(root, 0, sb);
        write("viewdump_" + (System.identityHashCode(root) & 15) + ".txt", sb.toString());
    }

    static void dumpNode(View v, int depth, StringBuilder sb) {
        if (sb.length() > 600000) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            String n;
            try { n = v.getResources().getResourceEntryName(id); } catch (Throwable t) { n = Integer.toHexString(id); }
            sb.append(" #").append(n);
        }
        if (v instanceof TextView && ((TextView) v).getText().length() > 0)
            sb.append(" text=\"").append(cut(((TextView) v).getText())).append('"');
        if (v.getContentDescription() != null)
            sb.append(" desc=\"").append(cut(v.getContentDescription())).append('"');
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        sb.append(" [").append(l[0]).append(',').append(l[1]).append(' ')
                .append(v.getWidth()).append('x').append(v.getHeight()).append(']');
        if (v.getVisibility() != View.VISIBLE) sb.append(" vis=").append(v.getVisibility());
        if (HIDDEN.containsKey(v)) sb.append(" HIDDEN");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpNode(g.getChildAt(i), depth + 1, sb);
        }
    }

    static String cut(CharSequence s) {
        String x = s.toString().replace('\n', ' ');
        return x.length() > 40 ? x.substring(0, 40) : x;
    }
}
