package com.dyhide;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RenderEffect;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.HapticFeedbackConstants;
import android.view.PixelCopy;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    static int BG, CARD, INK, SUB, ACCENT, OFF, HAIR;
    static boolean dark;
    static final long IN = 210, OUT = 210;   // Figma 转场：Move In 280ms Ease Out；Move Out 240ms Ease In；不回弹
    static final float DIM = 0.35f;          // 底层页面的深色遮罩最大不透明度
    static final String VOL = "3.3";
    static final long RIPPLE = 200;           // 所有点击波纹统一：200ms 快速扩散
    static final int REQ_EXPORT = 11, REQ_IMPORT = 12;
    static final String[] TABS = {"规则", "外观", "设置"};
    static final String[] TAB_EN = {"RULES", "APPEARANCE", "SETTINGS"};

    static void palette(boolean d) {
        dark = d;
        // 哑光纸：暖灰白 / 炭黑；点缀色取酒红 / 暗金，克制不跳
        BG = d ? 0xFF141311 : 0xFFEFEBE3;
        CARD = d ? 0xFF1E1C19 : 0xFFF8F5EF;
        INK = d ? 0xFFEBE5D9 : 0xFF1C1B18;
        SUB = d ? 0xFF958D7F : 0xFF7B756B;
        ACCENT = d ? 0xFFC9A66B : 0xFF7D3A2E;
        OFF = d ? 0xFF3A3630 : 0xFFD0C9BB;
        HAIR = d ? 0x24EBE5D9 : 0x261C1B18;
    }

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    /** 可按压的容器：按下内容缩到 96%，松手时弹簧回弹（先略超过 100% 再落回）；波纹从手指按下的位置扩散。 */
    private static final class Press extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float rx, ry, radius, alpha;
        private ValueAnimator grow, fade, spring;

        Press(Context c, View content, int width, Runnable click) {
            super(c);
            setWillNotDraw(false);
            addView(content, new LayoutParams(width, -2));
            setOnClickListener(v -> click.run());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (alpha > 0f) {
                paint.setAlpha((int) (alpha * 46));
                canvas.drawCircle(rx, ry, radius, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) down(e.getX(), e.getY());
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) up();
            return super.onTouchEvent(e);
        }

        private void down(float x, float y) {
            if (fade != null) fade.cancel();
            if (spring != null) spring.cancel();
            paint.setColor(dark ? Color.WHITE : Color.BLACK);
            rx = x;
            ry = y;
            alpha = 1f;
            grow = ValueAnimator.ofFloat(0f, (float) Math.hypot(Math.max(x, getWidth() - x), Math.max(y, getHeight() - y)));
            grow.setDuration(RIPPLE);
            grow.setInterpolator(new DecelerateInterpolator());
            grow.addUpdateListener(a -> { radius = (float) a.getAnimatedValue(); invalidate(); });
            grow.start();
            getChildAt(0).animate().cancel();
            getChildAt(0).animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
        }

        private void up() {
            fade = ValueAnimator.ofFloat(alpha, 0f);
            fade.setDuration(220);
            fade.addUpdateListener(a -> { alpha = (float) a.getAnimatedValue(); invalidate(); });
            fade.start();
            final View c = getChildAt(0);
            c.animate().cancel();
            final float from = c.getScaleX();
            spring = ValueAnimator.ofFloat(0f, 0.5f);   // 数值为秒；欠阻尼弹簧：x(t) = 1 - (1-from)·e^(-ζω0t)·(cos ωd·t + ζω0/ωd·sin ωd·t)
            spring.setDuration(500);
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                double w0 = 2 * Math.PI * 3.2, z = 0.42, wd = w0 * Math.sqrt(1 - z * z);
                float s = a.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t)));
                c.setScaleX(s);
                c.setScaleY(s);
            });
            spring.start();
        }
    }

    /** 半透明的纸：底色 + 柔和高光 + 极细纸纹颗粒 + 右上角渐隐的半调网点 + 底部淡淡的压暗。 */
    private static final class Paper extends Drawable {
        private final Paint fill = new Paint(), glow = new Paint(), shade = new Paint(), grain = new Paint();
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), star = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path sp = new Path();
        private final float d;

        Paper(float density) {
            d = density;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, 0.8f * d));
            line.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            star.setColor(ACCENT);
            fill.setColor(BG);
            int n = 128;
            int[] px = new int[n * n];
            Random r = new Random(7);
            int rgb = dark ? 0xFFFFFF : 0x000000;
            for (int i = 0; i < px.length; i++) {
                if (r.nextInt(100) < 38) px[i] = ((2 + r.nextInt(dark ? 9 : 11)) << 24) | rgb;
            }
            grain.setShader(new BitmapShader(Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888),
                    Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            dot.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            dot.setAlpha(dark ? 22 : 26);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float w = Math.max(1, b.width()), h = Math.max(1, b.height());
            int hi = dark ? 0x1AC9A66B : 0x80FFFFFF, hi0 = dark ? 0x00C9A66B : 0x00FFFFFF;
            glow.setShader(new RadialGradient(w * 0.9f, 0f, w * 1.1f, hi, hi0, Shader.TileMode.CLAMP));
            int lo = dark ? 0x40000000 : 0x14503A1E;
            shade.setShader(new LinearGradient(0f, h * 0.65f, 0f, h, lo & 0x00FFFFFF, lo, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, fill);
            c.drawRect(b, glow);
            c.drawRect(b, shade);
            // 半调网点：错行排布，越靠右上角越大，向内渐隐
            float sp = 10 * d, maxR = 2.6f * d, reach = b.width() * 0.95f;
            int row = 0;
            for (float y = 0; y < reach; y += sp * 0.5f, row++) {
                for (float x = (row % 2) * sp * 0.5f; x < reach; x += sp) {
                    float t = 1f - (float) Math.hypot(x, y) / reach;
                    if (t <= 0f) continue;
                    float r = maxR * t * t;
                    if (r >= 0.35f * d) c.drawCircle(b.right - x, b.top + y, r, dot);
                }
            }
            ornaments(c, b);
            c.drawRect(b, grain);
        }

        /** 杂志版式小元素：四角套准十字、左下同心弧、左缘刻度尺、散落的四角星。 */
        private void ornaments(Canvas c, Rect b) {
            line.setAlpha(dark ? 60 : 64);
            float m = 12 * d, k = 7 * d;
            float[][] corner = {{b.left + m, b.top + m}, {b.right - m, b.top + m}, {b.left + m, b.bottom - m}, {b.right - m, b.bottom - m}};
            for (float[] q : corner) {
                c.drawLine(q[0] - k, q[1], q[0] + k, q[1], line);
                c.drawLine(q[0], q[1] - k, q[0], q[1] + k, line);
                c.drawCircle(q[0], q[1], 3.5f * d, line);
            }
            line.setAlpha(dark ? 26 : 30);
            for (int i = 1; i <= 5; i++) c.drawCircle(b.left - 20 * d, b.bottom - 170 * d, 34 * d * i, line);
            line.setAlpha(dark ? 50 : 56);
            float y0 = b.top + b.height() * 0.38f;
            for (int i = 0; i < 18; i++) {
                float y = y0 + i * 12 * d, len = (i % 4 == 0 ? 9 : 4) * d;
                c.drawLine(b.left, y, b.left + len, y, line);
            }
            star.setAlpha(dark ? 120 : 90);
            star(c, b.left + b.width() * 0.14f, b.top + b.height() * 0.30f, 8 * d);
            star(c, b.left + b.width() * 0.88f, b.top + b.height() * 0.56f, 6 * d);
            star(c, b.left + b.width() * 0.34f, b.top + b.height() * 0.74f, 4.5f * d);
            star(c, b.left + b.width() * 0.76f, b.top + b.height() * 0.86f, 7 * d);
            // 散点：十字、空心圆（固定种子，每次画在同一处）
            Random rnd = new Random(5);
            for (int i = 0; i < 14; i++) {
                float x = b.left + (0.06f + 0.88f * rnd.nextFloat()) * b.width(), y = b.top + (0.04f + 0.92f * rnd.nextFloat()) * b.height(), r = (2.5f + 2.5f * rnd.nextFloat()) * d;
                line.setAlpha(dark ? 46 : 52);
                if (i % 2 == 0) {
                    c.drawLine(x - r, y, x + r, y, line);
                    c.drawLine(x, y - r, x, y + r, line);
                } else {
                    c.drawCircle(x, y, r, line);
                }
            }
            // 右下角斜线影线、左下角半调网点
            line.setAlpha(dark ? 30 : 34);
            for (int i = 0; i < 9; i++) c.drawLine(b.right - 110 * d + i * 12 * d, b.bottom - 10 * d, b.right - 10 * d, b.bottom - 110 * d + i * 12 * d, line);
            float reach = b.width() * 0.5f, spc = 10 * d;
            int row = 0;
            for (float yy = 0; yy < reach; yy += spc * 0.5f, row++) {
                for (float xx = (row % 2) * spc * 0.5f; xx < reach; xx += spc) {
                    float t = 1f - (float) Math.hypot(xx, yy) / reach;
                    if (t > 0f && 2f * d * t * t >= 0.35f * d) c.drawCircle(b.left + xx, b.bottom - yy, 2f * d * t * t, dot);
                }
            }
        }

        private void star(Canvas c, float x, float y, float r) {
            sp.reset();
            sp.moveTo(x, y - r);
            sp.quadTo(x, y, x + r, y);
            sp.quadTo(x, y, x, y + r);
            sp.quadTo(x, y, x - r, y);
            sp.quadTo(x, y, x, y - r);
            c.drawPath(sp, star);
        }

        @Override
        public void setAlpha(int a) {}

        @Override
        public void setColorFilter(ColorFilter f) {}

        @Override
        public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    /**
     * 所有页面共用的滚动容器：
     * 1) 到顶/到底后继续拖，整页按距离（带阻尼）纵向拉伸，松手弹簧回位；
     * 2) 翻（甩）到顶部或底部时，整页弹一下回位，只弹一次；
     * 3) 滑动遮罩：内容滑到上下边缘时渐隐消失，离开边缘越远遮得越实，到顶/到底处无遮罩。
     */
    private static final class PullScroll extends ScrollView {
        View col;
        private final Paint maskTop = new Paint(), maskBot = new Paint();
        private final float d = getResources().getDisplayMetrics().density;
        private final android.graphics.Matrix m = new android.graphics.Matrix();
        private float startY, sign = 1f, act;
        private boolean pulling;
        private ValueAnimator spring;

        PullScroll(Context c) {
            super(c);
            maskTop.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            maskBot.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            maskTop.setShader(new LinearGradient(0f, 0f, 0f, 1f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
            maskBot.setShader(new LinearGradient(0f, 0f, 0f, 1f, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        }

        /** 最近的滚动方向与力度：往下滑为正，往上滑为负，逐帧衰减回 0。 */
        private final Runnable decay = new Runnable() {
            @Override
            public void run() {
                act *= 0.93f;
                if (Math.abs(act) < 0.01f) act = 0f;
                else postOnAnimation(this);
                invalidate();
            }
        };

        @Override
        protected void dispatchDraw(Canvas c) {
            int y = getScrollY(), h = getHeight();
            float kt = Math.min(1f, y / (48 * d)), kb = Math.min(1f, Math.max(0f, col.getHeight() - h - y) / (48 * d));
            if (kt <= 0f && kb <= 0f) {
                super.dispatchDraw(c);
                return;
            }
            // 滑动遮罩：往下滑时底部遮罩变高，内容从遮罩里逐渐显现；往上滑时顶部同理；停下后遮罩缓缓收回
            float tb = (36 + 160 * Math.max(0f, -act)) * d, bb = (120 + 200 * Math.max(0f, act)) * d;
            int layer = c.saveLayer(0f, y, getWidth(), y + h, null);
            super.dispatchDraw(c);
            c.translate(0f, y);
            m.setScale(1f, tb);
            maskTop.getShader().setLocalMatrix(m);
            m.setScale(1f, bb);
            m.postTranslate(0f, h - bb);
            maskBot.getShader().setLocalMatrix(m);
            maskTop.setAlpha((int) (255 * kt));
            maskBot.setAlpha((int) (255 * kb));
            c.drawRect(0f, 0f, getWidth(), tb, maskTop);
            c.drawRect(0f, h - bb, getWidth(), h, maskBot);
            c.restoreToCount(layer);
        }

        private void stretch(float s) {
            col.setPivotX(col.getWidth() / 2f);
            col.setPivotY(sign > 0 ? 0f : col.getHeight());
            col.setScaleY(s);
        }

        /** 欠阻尼弹簧回到 1：先越过一点再落回，肉眼只见一次回弹。 */
        private void springBack(final float from) {
            if (spring != null) spring.cancel();
            spring = ValueAnimator.ofFloat(0f, 0.7f);   // 数值为秒
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(v -> {
                float t = (float) v.getAnimatedValue();
                double w0 = 2 * Math.PI * 2.4, z = 0.6, wd = w0 * Math.sqrt(1 - z * z);
                stretch(v.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t))));
            });
            spring.setDuration(700);
            spring.start();
        }

        @Override
        protected void onScrollChanged(int l, int t, int ol, int ot) {
            super.onScrollChanged(l, t, ol, ot);
            act = Math.max(-1f, Math.min(1f, act + (t - ot) / (getHeight() * 0.25f)));
            removeCallbacks(decay);
            postOnAnimation(decay);
            if (pulling) return;
            int max = Math.max(0, col.getHeight() - getHeight());
            boolean top = t == 0 && ot > 0, bottom = max > 0 && t == max && ot < max;
            if (!top && !bottom) return;
            sign = top ? 1f : -1f;
            springBack(1f + Math.min(0.16f, Math.max(0.06f, Math.abs(t - ot) / (getHeight() * 0.8f))));
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (spring != null) spring.cancel();
                pulling = false;
                startY = e.getRawY();
            } else if (a == MotionEvent.ACTION_MOVE && !pulling) {
                float dy = e.getRawY() - startY;
                int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
                boolean top = dy > slop && !canScrollVertically(-1), bottom = dy < -slop && !canScrollVertically(1);
                if (top || bottom) {
                    pulling = true;
                    sign = top ? 1f : -1f;
                    startY = e.getRawY();
                    if (spring != null) spring.cancel();
                    MotionEvent c = MotionEvent.obtain(e);
                    c.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(c);   // 列表自己的滚动/点击放弃这次触摸
                    c.recycle();
                }
            }
            if (!pulling) return super.dispatchTouchEvent(e);
            if (a == MotionEvent.ACTION_MOVE) {
                float pull = Math.max(0f, sign * (e.getRawY() - startY));
                stretch(1f + 0.30f * (1f - (float) Math.exp(-pull / (getHeight() * 0.35f))));
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                pulling = false;
                springBack(col.getScaleY());
            }
            return true;
        }
    }

    private interface Change { void on(float v, boolean done); }

    /** 0..1 的滑杆：细轨道 + 空心圆钮 + 三个刻度。 */
    private static final class Slider extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final Change cb;
        private final String[] marks;
        private float v;

        Slider(Context c, float density, float v, String[] marks, Change cb) {
            super(c);
            d = density;
            this.v = v;
            this.marks = marks;
            this.cb = cb;
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setTextSize(11 * d);
        }

        void set(float x) {
            v = x;
            invalidate();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(60 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float pad = 12 * d, cy = 22 * d, x0 = pad, x1 = getWidth() - pad, x = x0 + (x1 - x0) * v;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * d);
            p.setColor(OFF);
            c.drawLine(x0, cy, x1, cy, p);
            p.setColor(ACCENT);
            c.drawLine(x0, cy, x, cy, p);
            p.setStrokeWidth(1 * d);
            p.setColor(SUB);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f;
                c.drawLine(tx, cy + 14 * d, tx, cy + 19 * d, p);
            }
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f, w = p.measureText(marks[i]);
                c.drawText(marks[i], i == 0 ? tx - 4 * d : i == 1 ? tx - w / 2f : tx - w + 4 * d, cy + 36 * d, p);
            }
            p.setColor(CARD);
            c.drawCircle(x, cy, 10 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(ACCENT);
            c.drawCircle(x, cy, 10 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) getParent().requestDisallowInterceptTouchEvent(true);
            float pad = 12 * d;
            v = Math.max(0f, Math.min(1f, (e.getX() - pad) / Math.max(1f, getWidth() - 2 * pad)));
            invalidate();
            cb.on(v, a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL);
            return true;
        }
    }

    /** 返回箭头图标。 */
    private static final class Arrow extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        Arrow(Context c, float density) {
            super(c);
            d = density;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(2.2f * d);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(44 * d), Math.round(44 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, s = 9 * d;
            paint.setColor(INK);
            c.drawLine(cx - s, cy, cx + s, cy, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy - s * 0.65f, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy + s * 0.65f, paint);
        }
    }

    /** 开关：起步时前沿先走、横向拉长成胶囊；后沿滞后跟上，落位时压回原宽（略压窄再回弹），不像一张贴纸。 */
    private static final class Toggle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        boolean checked;
        private float l, r, cp;   // 圆点左右边缘(px)、轨道颜色进度
        private ValueAnimator anim;

        Toggle(Context c, boolean on, float density) {
            super(c);
            d = density;
            checked = on;
            l = (on ? 24f : 4f) * d;
            r = l + 24 * d;
            cp = on ? 1f : 0f;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(52 * d), Math.round(32 * d));
        }

        void set(boolean on) {
            checked = on;
            if (anim != null) anim.cancel();
            final float l0 = l, r0 = r, l1 = (on ? 24f : 4f) * d, r1 = l1 + 24 * d, c0 = cp, c1 = on ? 1f : 0f;
            final boolean right = l1 > l0;
            final OvershootInterpolator squash = new OvershootInterpolator(2.2f);
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(460);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                float t = a.getAnimatedFraction();
                float x = Math.min(1f, t / 0.7f);
                float lead = 1f - (1f - x) * (1f - x) * (1f - x);
                float trail = squash.getInterpolation(Math.max(0f, (t - 0.15f) / 0.85f));
                l = l0 + (l1 - l0) * (right ? trail : lead);
                r = r0 + (r1 - r0) * (right ? lead : trail);
                cp = c0 + (c1 - c0) * lead;
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            paint.setColor((Integer) new ArgbEvaluator().evaluate(Math.max(0f, Math.min(1f, cp)), OFF, ACCENT));
            rect.set(0, 0, getWidth(), h);
            c.drawRoundRect(rect, h / 2, h / 2, paint);
            paint.setColor(Color.WHITE);
            rect.set(l, 4 * d, r, h - 4 * d);
            c.drawRoundRect(rect, 12 * d, 12 * d, paint);
        }
    }

    /**
     * 底部导航（约 400ms）：选中项背后的胶囊像水滴流向新位置——前沿先到，后沿慢半拍用带轻微回弹的弹簧跟上，
     * 途中被拉长、高度略扁；新选中的图标先缩小再弹回，文字颜色渐变。
     */
    private static final class NavBar extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF(), cap = new RectF();
        private final Path clip = new Path();
        private final float d;
        private final IntConsumer onSelect;
        private float rx, ry, rr, ra;   // 点击波纹：圆心、半径、透明度
        private ValueAnimator rip;
        private final float[] left = new float[3], wid = new float[3], tl = new float[3], tw = new float[3], edge = new float[2];
        private int to;
        private float sPos, sL, sR, t = 1f;   // 起点：布局位置、胶囊左右边缘；t：0..1 进度
        private ValueAnimator anim;

        NavBar(Context c, float density, IntConsumer onSelect) {
            super(c);
            d = density;
            this.onSelect = onSelect;
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setTextSize(14 * d);
            paint.setFakeBoldText(true);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(80 * d) + getPaddingBottom());
        }

        private void layout(float pos, float[] l, float[] w) {
            float small = 56 * d, big = 132 * d, x = (getWidth() - (2 * small + big)) / 2f;
            for (int i = 0; i < 3; i++) {
                w[i] = small + (big - small) * Math.max(0f, 1f - Math.abs(pos - i));
                l[i] = x;
                x += w[i];
            }
        }

        private float pos() {
            return sPos + (to - sPos) * (1f - (1f - t) * (1f - t) * (1f - t));
        }

        /** 欠阻尼弹簧（ζ=0.67，约 6% 回弹），u 为 0..1 的归一化时间。 */
        private static float spring(float u) {
            if (u >= 1f) return 1f;
            double s = u * 0.35, z = 0.67, w0 = 20.2, wd = w0 * Math.sqrt(1 - z * z);
            return (float) (1 - Math.exp(-z * w0 * s) * (Math.cos(wd * s) + z * w0 / wd * Math.sin(wd * s)));
        }

        /** 当前胶囊的左右边缘：行进方向的前沿快速到位，后沿延迟 12% 后用弹簧跟上。 */
        private void edges(float[] o) {
            layout(to, tl, tw);
            float tL = tl[to], tR = tl[to] + tw[to];
            float lead = 1f - (float) Math.pow(1f - Math.min(1f, t / 0.65f), 3);
            float lag = spring(Math.max(0f, (t - 0.12f) / 0.88f));
            boolean right = tL >= sL;
            o[0] = sL + (tL - sL) * (right ? lag : lead);
            o[1] = sR + (tR - sR) * (right ? lead : lag);
        }

        /** 新选中图标：先缩到 78%，再带一点回弹弹回 100%。 */
        private float pop() {
            if (t >= 1f) return 1f;
            if (t < 0.3f) {
                float u = t / 0.3f;
                return 1f - 0.22f * (1f - (1f - u) * (1f - u));
            }
            double s = (t - 0.3f) / 0.7f;
            return (float) (1 - 0.22 * Math.exp(-3.5 * s) * Math.cos(2 * Math.PI * 1.1 * s));
        }

        void select(int i, boolean animate) {
            if (anim != null) anim.cancel();
            if (!animate) {
                to = i;
                sPos = i;
                t = 1f;
                invalidate();
                return;
            }
            float p = pos();
            edges(edge);
            sPos = p;
            sL = edge[0];
            sR = edge[1];
            to = i;
            t = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(400);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float capW = 244 * d + 24 * d, cy = 40 * d, p = pos();
            cap.set((getWidth() - capW) / 2f, 8 * d, (getWidth() + capW) / 2f, 72 * d);
            paint.setStyle(Paint.Style.STROKE);   // 整条底栏全透明，只留一圈细线勾出胶囊
            paint.setStrokeWidth(Math.max(1f, 1f * d));
            paint.setColor(SUB);
            paint.setAlpha(dark ? 120 : 110);
            c.drawRoundRect(cap, 32 * d, 32 * d, paint);
            if (ra > 0f) {
                clip.reset();
                clip.addRoundRect(cap, 32 * d, 32 * d, Path.Direction.CW);
                c.save();
                c.clipPath(clip);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(dark ? Color.WHITE : Color.BLACK);
                paint.setAlpha((int) (ra * 46));
                c.drawCircle(rx, ry, rr, paint);
                c.restore();
            }
            paint.setStyle(Paint.Style.FILL);
            layout(p, left, wid);
            edges(edge);
            float flat = 0.10f * (float) Math.sin(Math.PI * Math.min(1f, t / 0.75f));   // 途中高度略扁
            float ph = 44 * d * (1f - flat);
            paint.setColor(ACCENT);
            paint.setAlpha(dark ? 56 : 36);
            rect.set(edge[0], cy - ph / 2f, edge[1], cy + ph / 2f);
            c.drawRoundRect(rect, ph / 2f, ph / 2f, paint);
            for (int i = 0; i < 3; i++) {
                float w = Math.max(0f, 1f - Math.abs(p - i));
                int col = (Integer) new ArgbEvaluator().evaluate(w, SUB, ACCENT);
                float gap = 8 * d * w, group = 22 * d + gap + paint.measureText(TABS[i]) * w;
                float gx = left[i] + (wid[i] - group) / 2f;
                c.save();
                if (i == to) {
                    float sc = pop();
                    c.scale(sc, sc, gx + 11 * d, cy);
                }
                icon(c, i, gx + 11 * d, cy, col);
                c.restore();
                if (w > 0.05f) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    paint.setAlpha((int) (255 * w));
                    c.save();
                    c.clipRect(left[i], 0, left[i] + wid[i], getHeight());
                    c.drawText(TABS[i], gx + 22 * d + gap, cy + 5 * d, paint);
                    c.restore();
                }
            }
        }

        private void icon(Canvas c, int i, float cx, float cy, int col) {
            float s = 11 * d;
            paint.setColor(col);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * d);
            if (i == 0) {
                for (int k = -1; k <= 1; k++) c.drawLine(cx - s, cy + k * 6 * d, cx + s * (k == 0 ? 0.5f : 1f), cy + k * 6 * d, paint);
            } else if (i == 1) {
                c.drawCircle(cx, cy, s, paint);
                paint.setStyle(Paint.Style.FILL);
                rect.set(cx - s, cy - s, cx + s, cy + s);
                c.drawArc(rect, 90, 180, true, paint);
            } else {
                c.drawCircle(cx, cy, s * 0.45f, paint);
                for (int k = 0; k < 8; k++) {
                    float cos = (float) Math.cos(k * Math.PI / 4), sin = (float) Math.sin(k * Math.PI / 4);
                    c.drawLine(cx + cos * s * 0.75f, cy + sin * s * 0.75f, cx + cos * s, cy + sin * s, paint);
                }
            }
        }

        private void ripple(float x, float y) {
            rx = x;
            ry = y;
            final float max = (float) Math.hypot(Math.max(x - cap.left, cap.right - x), Math.max(y - cap.top, cap.bottom - y));
            if (rip != null) rip.cancel();
            rip = ValueAnimator.ofFloat(0f, 1f);
            rip.setDuration(RIPPLE * 8 / 5);   // 前 62% 时间扩散到最大（= RIPPLE），之后淡出
            rip.setInterpolator(new LinearInterpolator());
            rip.addUpdateListener(a -> {
                float u = a.getAnimatedFraction(), g = Math.min(1f, u / 0.62f);
                rr = max * (1f - (1f - g) * (1f - g) * (1f - g));
                ra = 1f - Math.max(0f, (u - 0.35f) / 0.65f);
                invalidate();
            });
            rip.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (!cap.contains(e.getX(), e.getY())) return false;   // 胶囊以外全透明，触摸直接落到页面上
                ripple(e.getX(), e.getY());
            } else if (a == MotionEvent.ACTION_UP) {
                for (int i = 0; i < 3; i++) if (e.getX() >= left[i] && e.getX() < left[i] + wid[i]) onSelect.accept(i);
            }
            return true;
        }
    }

    /** 深色模式切换：新主题从开关位置圆形扩散；切回时原路收回。叠加层是切换前的截图，开关处按胶囊形状抠空，露出实时的开关。 */
    private static final class Reveal extends View {
        private final Bitmap old;
        private final Path path = new Path();
        private final Paint erase = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF hole;
        private final float cx, cy, max;
        private final boolean expand;
        private float radius;

        Reveal(Context c, Bitmap old, RectF hole, boolean expand) {
            super(c);
            this.old = old;
            this.hole = hole;
            cx = hole.centerX();
            cy = hole.centerY();
            this.expand = expand;
            max = (float) Math.hypot(Math.max(cx, old.getWidth() - cx), Math.max(cy, old.getHeight() - cy));
            radius = expand ? 0f : max;
            erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        }

        void start() {
            ValueAnimator a = expand ? ValueAnimator.ofFloat(0f, max) : ValueAnimator.ofFloat(max, 0f);
            a.setDuration(540);
            a.setInterpolator(new AccelerateDecelerateInterpolator());
            a.addUpdateListener(v -> { radius = (float) v.getAnimatedValue(); invalidate(); });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    ((ViewGroup) getParent()).removeView(Reveal.this);
                    old.recycle();
                }
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            path.reset();
            path.addCircle(cx, cy, radius, Path.Direction.CW);
            int layer = c.saveLayer(0f, 0f, (float) getWidth(), (float) getHeight(), null);
            c.save();
            if (expand) c.clipOutPath(path);   // 圆内露出新主题（实时界面），圆外仍是旧截图
            else c.clipPath(path);             // 圆内是旧主题截图，随圆缩小被新主题取代
            c.drawBitmap(old, 0, 0, null);
            c.restore();
            // 开关本体：按胶囊抠空（带抗锯齿），边缘不再出现矩形的新旧主题接缝
            c.drawRoundRect(hole, hole.height() / 2f, hole.height() / 2f, erase);
            c.restoreToCount(layer);
        }
    }

    /** 页眉的条码装饰。 */
    private static final class Barcode extends View {
        private final Paint p = new Paint();
        private final float[] w = new float[24];
        private final float d;

        Barcode(Context c, float density) {
            super(c);
            d = density;
            Random r = new Random(11);
            for (int i = 0; i < w.length; i++) w[i] = (1 + r.nextInt(3)) * 0.8f;
        }

        @Override
        protected void onMeasure(int a, int b) {
            setMeasuredDimension(Math.round(64 * d), Math.round(14 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            p.setColor(SUB);
            p.setAlpha(150);
            float x = 0f;
            for (int i = 0; i < w.length && x < getWidth(); i++) {
                if (i % 2 == 0) c.drawRect(x, 0f, Math.min(getWidth(), x + w[i] * d), getHeight(), p);
                x += w[i] * d;
            }
        }
    }

    /** 卡片角落的半调网点（右下角向内渐隐）。 */
    private static final class CardArt extends Drawable {
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG), mark = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final float[][] spots;   // 每张卡片自己的几处点缀：x、y（占宽高的比例）、大小、形状

        CardArt(float density) {
            d = density;
            dot.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            dot.setAlpha(dark ? 26 : 30);
            mark.setStyle(Paint.Style.STROKE);
            mark.setStrokeWidth(Math.max(1f, 0.8f * d));
            mark.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            mark.setAlpha(dark ? 52 : 58);
            Random r = new Random();
            spots = new float[2 + r.nextInt(3)][];
            for (int i = 0; i < spots.length; i++) spots[i] = new float[]{0.05f + 0.9f * r.nextFloat(), 0.15f + 0.7f * r.nextFloat(), 2.5f + 2.5f * r.nextFloat(), r.nextInt(4)};
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            for (float[] q : spots) {
                float x = b.left + q[0] * b.width(), y = b.top + q[1] * b.height(), r = q[2] * d;
                if (q[3] == 0) {
                    c.drawLine(x - r, y, x + r, y, mark);
                    c.drawLine(x, y - r, x, y + r, mark);
                } else if (q[3] == 1) {
                    c.drawCircle(x, y, r, mark);
                } else if (q[3] == 2) {
                    c.drawLine(x - r, y, x, y - r, mark);
                    c.drawLine(x, y - r, x + r, y, mark);
                    c.drawLine(x + r, y, x, y + r, mark);
                    c.drawLine(x, y + r, x - r, y, mark);
                } else {
                    c.drawCircle(x, y, r * 0.35f, dot);
                }
            }
            float sp = 7 * d, reach = Math.min(b.width() * 0.5f, 120 * d);
            int row = 0;
            for (float y = 0; y < reach; y += sp * 0.5f, row++) {
                for (float x = (row % 2) * sp * 0.5f; x < reach; x += sp) {
                    float t = 1f - (float) Math.hypot(x, y) / reach;
                    if (t > 0f && 1.7f * d * t * t >= 0.3f * d) c.drawCircle(b.right - x, b.bottom - y, 1.7f * d * t * t, dot);
                }
            }
        }

        @Override
        public void setAlpha(int a) {}

        @Override
        public void setColorFilter(ColorFilter f) {}

        @Override
        public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** 全屏透明的火花层：盖在整个界面最上面，不挡触摸；彩蛋迸出的网点画在这里，不会被页面或页脚裁掉。 */
    private static final class Sparks extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();
        private final List<float[]> dots = new ArrayList<>();   // x, y, vx, vy, 剩余寿命(1→0), 半径, 色号
        private final float d;
        private long last;
        private boolean ticking;

        Sparks(Context c, float density) {
            super(c);
            d = density;
        }

        /** 屏幕坐标 → 本层坐标，再迸出 n 个点。 */
        void burstAt(float rawX, float rawY, int n, float speed) {
            int[] l = new int[2];
            getLocationOnScreen(l);
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2, v = speed * d * (0.35 + rnd.nextDouble() * 0.65);
                dots.add(new float[]{rawX - l[0], rawY - l[1], (float) (Math.cos(a) * v), (float) (Math.sin(a) * v) - 120 * d,
                        1f, (1.5f + rnd.nextFloat() * 3f) * d, rnd.nextInt(3)});
            }
            if (!ticking) {
                ticking = true;
                last = System.nanoTime();
                postOnAnimation(this::tick);
            }
        }

        private void tick() {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            for (Iterator<float[]> it = dots.iterator(); it.hasNext(); ) {
                float[] q = it.next();
                q[3] += 900 * d * dt;
                q[0] += q[2] * dt;
                q[1] += q[3] * dt;
                q[4] -= dt / 1.1f;
                if (q[4] <= 0f) it.remove();
            }
            invalidate();
            if (dots.isEmpty()) ticking = false;
            else postOnAnimation(this::tick);
        }

        @Override
        protected void onDraw(Canvas c) {
            for (float[] q : dots) {
                p.setColor(q[6] == 0 ? ACCENT : q[6] == 1 ? INK : SUB);
                p.setAlpha((int) (255 * q[4]));
                c.drawCircle(q[0], q[1], q[5] * (0.5f + 0.5f * q[4]), p);
            }
        }
    }

    /** 隐藏彩蛋：页脚里一枚几乎看不见的 ✦，自身背景全透明。点一下迸出一圈网点，按住拖动拖出一串；连点 7 下触发大迸发。 */
    private static final class Egg extends View {
        private static int taps;
        private static long lastTap;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Sparks sparks;
        private final float d;
        private final Runnable found;

        Egg(Context c, float density, Sparks sparks, Runnable found) {
            super(c);
            d = density;
            this.sparks = sparks;
            this.found = found;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(96 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            p.setTextSize(16 * d);
            p.setColor(SUB);
            p.setAlpha(70);
            c.drawText("✦", (getWidth() - p.measureText("✦")) / 2f, getHeight() / 2f + 6 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                long now = System.currentTimeMillis();
                taps = now - lastTap > 1500 ? 1 : taps + 1;
                lastTap = now;
                if (taps >= 7) {
                    taps = 0;
                    sparks.burstAt(e.getRawX(), e.getRawY(), 90, 520);
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    found.run();
                } else {
                    sparks.burstAt(e.getRawX(), e.getRawY(), 22, 300);
                }
            } else if (a == MotionEvent.ACTION_MOVE) {
                sparks.burstAt(e.getRawX(), e.getRawY(), 2, 120);
            }
            return true;
        }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private NavBar nav;
    private Sparks sparks;
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;
    private View scrim;                      // 夹在底层页和上层页之间的深色遮罩
    private ValueAnimator anim;              // 当前转场动画（同一时间只有一个）
    private View tTop, tUnder;
    private float tw;
    private boolean cand, dragging;
    private float x0, y0, dragX;
    private VelocityTracker vt;
    private boolean animateDark;   // 重建后的深色开关从旧状态起步，播放一次切换动画

    private SharedPreferences shared;   // 激活后抖音读取的那份（MODE_WORLD_READABLE，LSPosed 会把它放到另一个位置）：cfg 的镜像
    private final SharedPreferences.OnSharedPreferenceChangeListener mirror = (p, key) -> syncShared(key);

    /** 把本地配置 cfg 同步到 shared：key 为 null 时整份覆盖，否则只同步这一个键。 */
    private void syncShared(String key) {
        Map<String, ?> all = cfg.getAll();
        SharedPreferences.Editor e = shared.edit();
        if (key == null) e.clear();
        else if (!all.containsKey(key)) e.remove(key);
        for (Map.Entry<String, ?> x : all.entrySet()) {
            if (key != null && !key.equals(x.getKey())) continue;
            putAny(e, x.getKey(), x.getValue());
        }
        e.apply();
    }

    private static void putAny(SharedPreferences.Editor e, String k, Object v) {
        if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else if (v instanceof Float) e.putFloat(k, (Float) v);
        else if (v instanceof Long) e.putLong(k, (Long) v);
        else if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof String) e.putString(k, (String) v);
    }

    @Override
    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = getSharedPreferences("config_local", MODE_PRIVATE);   // 界面读写的唯一一份，激活前后都是它
        if (isModuleActive()) {
            // 必须抢在任何 MODE_PRIVATE 打开 "config" 之前：同一进程里先打开的那个模式决定文件权限，
            // 先以私有模式打开，抖音那边就读不到这份配置了（所有开关全部失效）
            shared = getSharedPreferences("config", MODE_WORLD_READABLE);
        }
        if (!cfg.contains("migrated")) {   // 一次性：把旧版本留下的配置并进来（旧的本地那份优先，激活期间那份补缺）
            Map<String, Object> merged = new java.util.HashMap<>();
            if (shared != null) merged.putAll(shared.getAll());
            merged.putAll(getSharedPreferences("config", MODE_PRIVATE).getAll());
            SharedPreferences.Editor e = cfg.edit();
            for (Map.Entry<String, Object> x : merged.entrySet()) putAny(e, x.getKey(), x.getValue());
            e.putBoolean("migrated", true).apply();
        }
        if (shared != null) {
            syncShared(null);
            cfg.registerOnSharedPreferenceChangeListener(mirror);
        }
        density = getResources().getDisplayMetrics().density;
        palette(cfg.getBoolean("dark", false));
        build();
        if (b == null && !isModuleActive()) showInactive();   // 只在全新启动时提示；旋转屏幕等重建（b != null）不再重复弹
    }

    /** 恒为 false；模块生效时，在本应用自己的进程里被 MainHook 钩成 true（要求 LSPosed 作用域里勾选本模块）。 */
    static boolean isModuleActive() {
        return false;
    }

    /** 未激活：半透明卡片提示，“去激活”跳到 LSPosed 里本模块的页面，“请稍后”关闭。 */
    private void showInactive() {
        final ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        final FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(0x80000000);
        ov.setClickable(true);   // 挡住下面的触摸
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);   // 不透明
        bg.setCornerRadius(dp(28));
        card.setBackground(bg);
        card.addView(text("模块未激活", 21, INK, false));
        card.addView(text("请在LSPosed中激活此模块后重新打开", 18, SUB, false), lp(0, 10, 0, 18));
        LinearLayout btns = new LinearLayout(this);   // 按钮行占满标题和说明以下的全部高度，卡片里不留空白
        btns.addView(pill("去激活", true, () -> {
            decor.removeView(ov);
            openLsposed();
        }), new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout.LayoutParams later = new LinearLayout.LayoutParams(0, -1, 1f);
        later.leftMargin = dp(12);
        btns.addView(pill("请稍后", false, () -> decor.removeView(ov)), later);
        card.addView(btns, new LinearLayout.LayoutParams(-1, 0, 1f));
        DisplayMetrics dm = getResources().getDisplayMetrics();   // 4:3 的卡片再放大 1.5 倍：宽 = 屏幕短边 − 64dp，高 = 宽 × 3/4，横竖屏一样大
        int w = Math.min(dm.widthPixels, dm.heightPixels) - dp(64);
        ov.addView(card, new FrameLayout.LayoutParams(w, w * 3 / 4, Gravity.CENTER));
        ov.setAlpha(0f);
        decor.addView(ov, new FrameLayout.LayoutParams(-1, -1));
        ov.animate().alpha(1f).setDuration(200).start();
    }

    private View pill(String label, boolean primary, Runnable go) {
        TextView t = text(label, 21, primary ? Color.WHITE : INK, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(30));
        if (primary) g.setColor(ACCENT);
        else g.setStroke(Math.max(1, Math.round(dp(1) * 3.4f)), SUB);
        t.setBackground(g);
        Press p = new Press(this, t, -1, go);
        t.getLayoutParams().height = -1;   // Press 默认把内容按文字高度排，这里撑满整行，按钮才是真的“粗”
        return p;
    }

    private void openLsposed() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setClassName("org.lsposed.manager", "org.lsposed.manager.ui.activity.MainActivity");
        i.setData(Uri.parse("module://" + getPackageName() + ":0"));   // LSPosed 管理器的“模块页面”深链接
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {   // 管理器不在 / 入口不同：退回直接打开 LSPosed
            Intent l = getPackageManager().getLaunchIntentForPackage("org.lsposed.manager");
            if (l == null) toast("没找到 LSPosed 管理器，请手动打开");
            else startActivity(l);
        }
    }

    /** 按当前调色板重建整个界面（首次启动和切换深浅色时调用），回到当前标签的首页。 */
    private void build() {
        stacks.clear();
        refreshers.clear();
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        scrim = new View(this);
        scrim.setBackgroundColor(Color.BLACK);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        nav = new NavBar(this, density, this::switchTab);
        if (Build.VERSION.SDK_INT >= 28) {
            nav.setOutlineAmbientShadowColor(0x12000000);
            nav.setOutlineSpotShadowColor(0x1A000000);
        }
        root.addView(nav, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));   // 浮在页面上方，整条透明
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, 0);
            nav.setPadding(0, 0, 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        sparks = new Sparks(this, density);
        root.addView(sparks, new FrameLayout.LayoutParams(-1, -1));   // 最上层、透明、不拦触摸
        setContentView(root);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        Page p = rootPage(tab);
        stacks.get(tab).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        nav.select(tab, false);
        syncBack();
    }

    private void setDark(final boolean on, final RectF hole) {
        final View decor = getWindow().getDecorView();
        final Bitmap old = Bitmap.createBitmap(decor.getWidth(), decor.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.request(getWindow(), old, res -> {
            cfg.edit().putBoolean("dark", on).apply();
            palette(on);
            animateDark = true;
            build();
            if (res == PixelCopy.SUCCESS) {
                Reveal ov = new Reveal(this, old, hole, on);
                ((ViewGroup) decor).addView(ov, new FrameLayout.LayoutParams(-1, -1));
                ov.start();
            }
        }, new Handler(Looper.getMainLooper()));
    }

    // ---------- 导航：Figma 原型转场。进入 Move In（从右侧，210ms Ease Out），退出 Move Out（向右，210ms Ease In），
    // 底层页面不动，只叠一层渐变的深色遮罩；p = 上层页面的进入进度（0 在屏幕外，1 完全进入），动画和拖拽手势都驱动同一个 p。 ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void park(View v) {
        v.setVisibility(View.GONE);
        v.setTranslationX(0);
        v.setAlpha(1f);
    }

    private void setP(float p) {
        tTop.setTranslationX(tw * (1f - p));
        scrim.setAlpha(DIM * p);
    }

    /** 摆好转场现场：底层可见，遮罩在它上面，上层页面在遮罩上面。 */
    private void prepare(View top, View under, float p) {
        if (anim != null) anim.end();
        tw = content.getWidth();
        tTop = top;
        tUnder = under;
        under.animate().cancel();
        top.animate().cancel();
        under.setTranslationX(0);
        under.setAlpha(1f);
        under.setVisibility(View.VISIBLE);
        top.setAlpha(1f);
        top.setVisibility(View.VISIBLE);
        top.bringToFront();
        content.removeView(scrim);
        content.addView(scrim, content.getChildCount() - 1, new FrameLayout.LayoutParams(-1, -1));
        setP(p);
    }

    private void animateTo(float to, long base, PathInterpolator ip, final Runnable done) {
        float from = tTop.getTranslationX() == 0f ? 1f : 1f - tTop.getTranslationX() / tw;
        anim = ValueAnimator.ofFloat(from, to);
        anim.setDuration(Math.max(80, Math.round(base * Math.abs(to - from))));   // 按剩余距离折算时长
        anim.setInterpolator(ip);
        anim.addUpdateListener(a -> setP((float) a.getAnimatedValue()));
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                anim = null;
                setP(to);
                content.removeView(scrim);
                done.run();
            }
        });
        anim.start();
    }

    private static final PathInterpolator EASE_OUT = new PathInterpolator(0f, 0f, 0.58f, 1f);
    private static final PathInterpolator EASE_IN = new PathInterpolator(0.42f, 0f, 1f, 1f);

    private void push(final Page p) {
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        prepare(p.view, old.view, 0f);
        animateTo(1f, IN, EASE_OUT, () -> old.view.setVisibility(View.GONE));
        syncBack();
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (st.size() <= keep) return;
        if (anim != null) anim.end();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        float p = dragging ? 1f - topPage.view.getTranslationX() / tw : 1f;
        prepare(topPage.view, target.view, p);
        animateTo(0f, OUT, EASE_IN, () -> content.removeView(topPage.view));
        syncBack();
    }

    /** 底栏切换：新页面沿点击方向轻推并淡入，旧页面反向轻移并淡出，整体约 400ms。 */
    private void switchTab(int to) {
        if (to == tab) return;
        final float dir = to > tab ? 1f : -1f;
        final View from = top(tab).view;
        tab = to;
        nav.select(to, true);
        syncBack();
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        if (anim != null) anim.end();
        from.animate().cancel();
        in.animate().cancel();
        from.setVisibility(View.VISIBLE);
        from.setAlpha(1f);
        from.setTranslationX(0f);
        in.bringToFront();
        in.setVisibility(View.VISIBLE);
        in.setAlpha(0f);
        in.setTranslationX(dir * dp(36));
        from.animate().alpha(0f).translationX(-dir * dp(20)).setDuration(160)
                .setInterpolator(new DecelerateInterpolator(1.5f)).withEndAction(() -> park(from)).start();
        in.animate().alpha(1f).translationX(0f).setStartDelay(80).setDuration(320)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    /** 拖拽返回：在二级页面里向右拖，页面跟手滑出；松手时按进度和速度决定完成返回还是回到原位。 */
    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            cand = anim == null && stacks.get(tab).size() > 1;
            x0 = e.getRawX();
            y0 = e.getRawY();
            if (vt != null) vt.recycle();
            vt = VelocityTracker.obtain();
        }
        if (vt != null) vt.addMovement(e);
        if (cand && !dragging && a == MotionEvent.ACTION_MOVE) {
            float dx = e.getRawX() - x0, dy = Math.abs(e.getRawY() - y0);
            int slop = ViewConfiguration.get(this).getScaledTouchSlop();
            if (dx > slop && dx > dy * 1.5f) {
                dragging = true;
                dragX = e.getRawX();
                List<Page> st = stacks.get(tab);
                prepare(st.get(st.size() - 1).view, st.get(st.size() - 2).view, 1f);
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);   // 让里面的列表/按钮放弃这次触摸
                c.recycle();
            } else if (dy > slop) {
                cand = false;
            }
        }
        if (dragging) {
            if (a == MotionEvent.ACTION_MOVE) {
                setP(1f - Math.max(0f, Math.min(1f, (e.getRawX() - dragX) / tw)));
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                vt.computeCurrentVelocity(1000);
                float p = 1f - tTop.getTranslationX() / tw, v = vt.getXVelocity();
                boolean back = a == MotionEvent.ACTION_UP && (v > 1000f || (p < 0.5f && v > -1000f));
                if (back) {
                    popTo(stacks.get(tab).size() - 1);
                    dragging = false;
                } else {
                    dragging = false;
                    final View under = tUnder;
                    animateTo(1f, IN, EASE_OUT, () -> under.setVisibility(View.GONE));
                }
                cand = false;
            }
            return true;
        }
        return super.dispatchTouchEvent(e);
    }

    // ---------- 预测性返回：原路返回。手势进度直接驱动“进入动画”的反向——上层页面随手势沿进入的路径向右退出，
    // 底层遮罩同步变淡；松手返回则继续滑出，取消则滑回原位。仅 Android 14+；更低版本、三键导航走普通返回动画。 ----------
    private OnBackInvokedCallback backCb;
    private boolean predicting;

    private void syncBack() {
        if (Build.VERSION.SDK_INT < 34) return;
        boolean want = stacks.get(tab).size() > 1;
        if (want == (backCb != null)) return;
        OnBackInvokedDispatcher disp = getOnBackInvokedDispatcher();
        if (!want) {
            disp.unregisterOnBackInvokedCallback(backCb);
            backCb = null;
            return;
        }
        backCb = new OnBackAnimationCallback() {
            @Override
            public void onBackStarted(BackEvent e) {
                if (anim != null) anim.end();
                List<Page> st = stacks.get(tab);
                prepare(st.get(st.size() - 1).view, st.get(st.size() - 2).view, 1f);
                predicting = true;
            }

            @Override
            public void onBackProgressed(BackEvent e) {
                if (predicting) setP(1f - e.getProgress());
            }

            @Override
            public void onBackCancelled() {
                if (!predicting) return;
                predicting = false;
                final View under = tUnder;
                animateTo(1f, IN, EASE_OUT, () -> under.setVisibility(View.GONE));
            }

            @Override
            public void onBackInvoked() {
                dragging = predicting;   // 手势进行中：从当前位置接着滑出；三键导航直接走普通返回
                predicting = false;
                popTo(stacks.get(tab).size() - 1);
                dragging = false;
            }
        };
        disp.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCb);
    }

    @Override
    public void onBackPressed() {
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 备份 / 恢复 ----------
    private static final String[] EXTRA_KEYS = {"dark", "nav_transparent", "extend_feed", "center_tabs", "dump", "pendant_scale", "fit_video"};

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void exportBackup() {
        String name = "DyHide_backup_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".json";
        startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT);
    }

    private void importBackup() {
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT);
    }

    private Set<String> knownKeys() {
        Set<String> k = new HashSet<>(Arrays.asList(EXTRA_KEYS));
        for (Rules.R r : Rules.ALL) k.add(r.key());
        return k;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_EXPORT) {
                JSONObject prefs = new JSONObject();   // 导出当前生效的全部值（没改过的取默认值），恢复时才是完整还原
                for (Rules.R r : Rules.ALL) prefs.put(r.key(), cfg.getBoolean(r.key(), true));
                for (String k : EXTRA_KEYS) {
                    if (k.equals("pendant_scale")) prefs.put(k, Math.round(cfg.getFloat(k, 1f) * 100f) / 100.0);
                    else prefs.put(k, cfg.getBoolean(k, !k.equals("dark")));
                }
                JSONObject root = new JSONObject().put("app", "DyHide").put("version", VOL).put("prefs", prefs);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("已导出 " + prefs.length() + " 项设置");
            } else if (req == REQ_IMPORT) {
                String text;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    for (int n; (n = in.read(buf)) > 0; ) b.write(buf, 0, n);
                    text = new String(b.toByteArray(), StandardCharsets.UTF_8);
                }
                JSONObject p = new JSONObject(text).getJSONObject("prefs");
                Set<String> known = knownKeys();
                SharedPreferences.Editor ed = cfg.edit();
                int n = 0;
                for (Iterator<String> it = p.keys(); it.hasNext(); ) {   // 只在这里校验一次：未知项、类型不对的一律跳过
                    String k = it.next();
                    Object v = p.get(k);
                    if (!known.contains(k)) continue;
                    if (k.equals("pendant_scale") && v instanceof Number) {
                        ed.putFloat(k, Math.max(0.5f, Math.min(1.5f, ((Number) v).floatValue())));
                    } else if (v instanceof Boolean) {
                        ed.putBoolean(k, (Boolean) v);
                    } else {
                        continue;
                    }
                    n++;
                }
                ed.apply();
                palette(cfg.getBoolean("dark", false));
                build();
                toast("已恢复 " + n + " 项设置");
            }
        } catch (Exception e) {
            toast((req == REQ_EXPORT ? "导出失败：" : "恢复失败：") + e.getMessage());
        }
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", "选择要从信息流里抹去的元素。改动约 1 秒内在抖音生效，无需重启。", path, col -> {
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            int n = 0;
            col.addView(hair(), hairLp(32, 0));
            for (final String g : groups) {
                col.addView(magRow(++n, g, summary(g, null), () -> push(groupPage(g))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, "逐项开关，改动约 1 秒内生效。", path, col -> {
            int k = 0;
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) addGroup(col, single(switchRow(r.label, r.key(), true)), k++ == 0 ? 32 : 12);
            }
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            int n = 0;
            if (!subs.isEmpty()) col.addView(hair(), hairLp(40, 0));
            for (final String s : subs) {
                col.addView(magRow(++n, s, summary(g, s), () -> push(subPage(g, s))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
            if (g.equals("商城")) {   // 第二个板块：敬请期待
                col.addView(magRow(++n, "敬请期待", text("即将开放", 13, SUB, false), () -> push(soonPage())), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page soonPage() {
        List<String> path = new ArrayList<>(Arrays.asList("规则", "商城", "敬请期待"));
        return page("敬请期待", "", "", path, col -> col.addView(text("不要一臉期待的進來嘛この変態", 16, INK, false), lp(0, 24, 0, 0)));
    }

    private Page subPage(String g, String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, "逐项开关，改动约 1 秒内生效。", path, col -> {
            int n = 0, on = 0, longest = 0;
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) { n++; longest = Math.max(longest, r.shown().length()); if (cfg.getBoolean(r.key(), true)) on++; }
            }
            int k = 0;
            if (n >= 8) {   // 条目多的子页：顶部一键全部隐藏 / 全部恢复；按下后 50ms，下面所有开关一起播放切换动画
                final int total = n;
                final View[] bulk = new View[1];
                bulk[0] = actionRow(on == n ? "一键全部恢复显示" : "一键全部隐藏", on == n ? "关闭本页全部 " + n + " 项" : "开启本页全部 " + n + " 项", () -> {
                    int now = 0;
                    for (Rules.R r : Rules.ALL) if (g.equals(r.group) && s.equals(r.sub) && cfg.getBoolean(r.key(), true)) now++;
                    final boolean to = now != total;   // 现在全开 → 全部关；否则全部开
                    SharedPreferences.Editor ed = cfg.edit();
                    for (Rules.R r : Rules.ALL) if (g.equals(r.group) && s.equals(r.sub)) ed.putBoolean(r.key(), to);
                    ed.apply();
                    refreshAll();
                    LinearLayout mid = (LinearLayout) ((ViewGroup) bulk[0]).getChildAt(0);   // Press → 行 → 标题/说明
                    mid = (LinearLayout) mid.getChildAt(0);
                    ((TextView) mid.getChildAt(0)).setText(to ? "一键全部恢复显示" : "一键全部隐藏");
                    ((TextView) mid.getChildAt(1)).setText(to ? "关闭本页全部 " + total + " 项" : "开启本页全部 " + total + " 项");
                    content.postDelayed(() -> {
                        for (Rules.R r : Rules.ALL) {
                            Toggle t = live.get(r.key());
                            if (g.equals(r.group) && s.equals(r.sub) && t != null) t.set(to);
                        }
                    }, 50);
                });
                addGroup(col, single(bulk[0]), 32);
                k = 1;
            }
            LinearLayout pair = null;
            for (Rules.R r : Rules.ALL) {
                if (!g.equals(r.group) || !s.equals(r.sub)) continue;
                if (longest > 5) {   // 名字长：一行一张卡片
                    addGroup(col, single(switchRow(r.shown(), r.key(), true)), k++ == 0 ? 32 : 12);
                    continue;
                }
                if (pair == null || pair.getChildCount() == 2) {   // 名字短（如商品分类）：两列网格
                    pair = new LinearLayout(this);
                    addGroup(col, pair, k == 0 ? 32 : 12);
                    k = 1;
                }
                LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(0, -2, 1f);
                if (pair.getChildCount() == 1) cell.leftMargin = dp(12);
                pair.addView(single(switchRow(r.shown(), r.key(), true, true)), cell);
            }
            if (pair != null && pair.getChildCount() == 1) pair.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        });
    }

    /** 关于：两位开发者的卡片（圆角头像 + 名字，可带主页链接）+ 版本号、更新时间、GitHub。 */
    private Page aboutPage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置", "关于"));
        return page("关于", "关于", "两位开发者，一个小模块。", path, col -> {
            addGroup(col, single(devRow(R.drawable.dev_user, "用户8176973514541", "查看酷安主页 →", "https://www.coolapk.com/u/39895877")), 32);
            addGroup(col, single(devRow(R.drawable.dev_claude, "Claude", null, null)), 12);
            LinearLayout info = cardBody();
            info.addView(valueRow("版本号", num(VOL)));
            info.addView(valueRow("发布日期", num("2026年11月13日")));
            info.addView(actionRow("GitHub", "https://github.com/bardenjohn383-rgb/-Hide", () -> open("https://github.com/bardenjohn383-rgb/-Hide")));
            addGroup(col, wrapCard(info), 40);
            col.addView(text("免责声明：本软件完全免费，仅发布于上面的酷安主页和 GitHub，禁止任何形式的二次打包、收费与倒卖。如果你是花钱买到的，说明你被骗了，请立即申请退款并举报卖家；也请只从上面两个地址获取更新。", 13, SUB, false), lp(0, 20, 0, 0));
        });
    }

    /** 一位开发者：圆角头像 + 名字；link 不为 null 时整行可点，打开 url。 */
    private View devRow(int avatar, String name, String link, final String url) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        ImageView av = new ImageView(this);
        av.setImageResource(avatar);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), v.getWidth() * 0.28f);
            }
        });
        av.setClipToOutline(true);
        row.addView(av, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(text(name, 17, INK, false));
        if (link != null) mid.addView(text(link, 13, ACCENT, false), lp(0, 4, 0, 0));
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, -2, 1f);
        ml.leftMargin = dp(16);
        row.addView(mid, ml);
        return url == null ? row : new Press(this, row, -1, () -> open(url));
    }

    private void open(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", "主题、底栏与红包挂件，克制地调整。", path, col -> {
            LinearLayout theme = cardBody();
            theme.addView(darkRow());
            addGroup(col, wrapCard(theme), 32);
            LinearLayout a = cardBody();
            a.addView(switchRow("底栏背景全透明", "nav_transparent", true));
            a.addView(switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 40);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
            LinearLayout fit = cardBody();
            fit.addView(switchRow("9:16 视频不裁切", "fit_video", false));
            addGroup(col, wrapCard(fit), 40);
            col.addView(text("抖音会把 9:16 视频放大到比屏幕还宽、裁掉左右两边。打开后缩回到刚好等于屏幕宽度，完整显示，上下留黑边。只对 9:16 视频生效。", 13, SUB, false), lp(0, 12, 0, 0));
            addGroup(col, pendantCard(), 40);
            col.addView(text("红包挂件可在 0.5× – 1.5× 之间自由调节，松手后约 1 秒在抖音生效；在抖音里直接按住挂件拖动即可放到任意位置，「恢复默认」会同时还原大小和位置。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置"));
        return page("设置", "设置", "备份、统计与调试。", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            a.addView(valueRow("规则总数", total));
            a.addView(valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 32);
            LinearLayout bk = cardBody();
            bk.addView(actionRow("导出备份", "把全部开关、主题和挂件大小存成一个 JSON 文件", this::exportBackup));
            bk.addView(actionRow("恢复备份", "从备份文件还原，覆盖当前设置", this::importBackup));
            addGroup(col, wrapCard(bk), 40);
            LinearLayout b = cardBody();
            b.addView(switchRow("调试：导出控件树和状态文件", "dump", false));
            addGroup(col, wrapCard(b), 40);
            addGroup(col, single(actionRow("关于", "开发者、版本号与项目主页", () -> push(aboutPage()))), 40);
            col.addView(text("viewdump_*.txt 直接保存在 内部存储/Download；dyhide_status.txt 仍在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    /** 杂志内页：报头（品牌/卷期 + 发丝线）→ 短色条 → 衬线大标题 → 斜体导语 → 正文 → 版权页脚。 */
    private Page page(String crumb, String title, String deck, final List<String> path, Fill fill) {
        final PullScroll sv = new PullScroll(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);   // 回弹由 PullScroll 自己做
        sv.setBackground(new Paper(density));
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(28), dp(16), dp(28), dp(150));   // 底部留出浮动底栏的位置
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        sv.col = col;

        LinearLayout mast = new LinearLayout(this);
        mast.setGravity(Gravity.CENTER_VERTICAL);
        mast.setMinimumHeight(dp(44));
        if (path.size() >= 2) {   // 二级及以下页面：左上角返回键
            LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(-2, -2);
            back.leftMargin = -dp(10);
            mast.addView(new Press(this, new Arrow(this, density), -2, () -> popTo(path.size() - 1)), back);
        } else {
            TextView brand = text("DYHIDE", 12, INK, true);
            brand.setLetterSpacing(0.32f);
            mast.addView(brand);
        }
        mast.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView vol = text("VOL. " + VOL + "  ·  " + TAB_EN[tab], 11, SUB, false);
        vol.setLetterSpacing(0.18f);
        mast.addView(vol);
        col.addView(mast, lp(0, 0, 0, 0));
        col.addView(hair(), hairLp(0, 0));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 12, 0, 0));

        View bar = new View(this);
        bar.setBackgroundColor(ACCENT);
        LinearLayout deco = new LinearLayout(this);
        deco.setGravity(Gravity.CENTER_VERTICAL);
        deco.addView(bar, new LinearLayout.LayoutParams(dp(28), dp(3)));
        deco.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        deco.addView(new Barcode(this, density));
        col.addView(deco, lp(0, 40, 0, 16));
        TextView head = text(title, 44, INK, true);
        head.setTypeface(Typeface.create("serif", Typeface.BOLD));
        head.setLineSpacing(0, 1.0f);
        head.setVisibility(title.isEmpty() ? View.GONE : View.VISIBLE);
        col.addView(head, lp(0, 0, 0, 0));
        TextView dk = text(deck, 15, SUB, false);
        dk.setTypeface(Typeface.create("serif", Typeface.ITALIC));
        dk.setLineSpacing(0, 1.25f);
        dk.setVisibility(deck.isEmpty() ? View.GONE : View.VISIBLE);
        col.addView(dk, lp(0, 12, 24, 0));

        fill.fill(col);
        col.addView(colophon("关于".equals(crumb)), lp(0, 48, 0, 0));

        return new Page(sv, crumb);
    }

    /** 页脚；彩蛋只留在「关于」页。 */
    private View colophon(boolean egg) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        if (egg) c.addView(new Egg(this, density, sparks, () -> toast("✦ 彩蛋：愿你的信息流，只剩想看的。")), new LinearLayout.LayoutParams(-1, -2));
        c.addView(hair(), hairLp(0, 16));
        TextView t = text("DYHIDE  ·  抖音UI隐藏  ·  FIN", 11, SUB, false);
        t.setLetterSpacing(0.2f);
        c.addView(t);
        TextView free = text("免费软件 · 禁止倒卖 · 仅酷安 / GitHub 发布", 11, SUB, false);
        c.addView(free, lp(0, 6, 0, 0));
        return c;
    }

    private View hair() {
        View v = new View(this);
        v.setBackgroundColor(HAIR);
        return v;
    }

    private LinearLayout.LayoutParams hairLp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.5f)));
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (last) {
                row.addView(c);
            } else {
                c.setPadding(0, dp(8), 0, dp(8));
                row.addView(new Press(this, c, -2, () -> popTo(idx + 1)));
                row.addView(text("  ›  ", 14, SUB, false));
            }
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------
    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    /** 目录式入口：斜体衬线大号序号 + 衬线标题 + 摘要。整行可点。 */
    private View magRow(int n, String name, TextView sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(20), 0, dp(20));
        TextView num = text(String.format(Locale.US, "%02d", n), 40, ACCENT, true);
        num.setTypeface(Typeface.create("serif", Typeface.BOLD_ITALIC));
        num.setAlpha(0.5f);
        row.addView(num, new LinearLayout.LayoutParams(dp(68), -2));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(name, 24, INK, true);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        mid.addView(title);
        mid.addView(sub, lp(0, 4, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 22, SUB, false));
        return new Press(this, row, -1, go);
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        FrameLayout f = new FrameLayout(this);
        f.addView(row);
        return f;
    }

    private View switchRow(String label, final String key, boolean def) {
        return switchRow(label, key, def, false);
    }

    /** compact：用于两列网格里的窄卡片（边距 14dp、字号 15）。 */
    private final Map<String, Toggle> live = new java.util.HashMap<>();   // 当前页面上各开关（按键名），一键隐藏时用来播放切换动画

    private View switchRow(String label, final String key, boolean def, boolean compact) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(compact ? 14 : 20), dp(8), dp(compact ? 14 : 20), dp(8));
        TextView name = text(label, compact ? 15 : 16, INK, false);
        if (compact) name.setSingleLine(true);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, cfg.getBoolean(key, def), density);
        live.put(key, sw);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            sw.set(!sw.checked);
            cfg.edit().putBoolean(key, sw.checked).apply();
            refreshAll();
        });
    }

    /** 点一下执行动作的行：标题 + 说明 + 箭头。 */
    private View actionRow(String label, String hint, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(text(label, 16, INK, false));
        mid.addView(text(hint, 13, SUB, false), lp(0, 2, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 20, SUB, false));
        return new Press(this, row, -1, go);
    }

    private static String fmtScale(float x) {
        return String.format(Locale.US, "%.2f×", x);
    }

    /** 红包挂件大小：一行标题 + 当前倍数，点一下展开滑杆（0.5×–1.5×，默认 1.0×）和“恢复默认”，再点收起。 */
    private View pendantCard() {
        final float min = 0.5f, max = 1.5f;
        float init = cfg.getFloat("pendant_scale", 1f);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(20), dp(8), dp(20), dp(16));
        head.addView(text("红包挂件大小", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = num(fmtScale(init));
        val.setTextColor(ACCENT);
        head.addView(val);
        final TextView chev = text("▾", 16, SUB, false);
        head.addView(chev, new LinearLayout.LayoutParams(-2, -2));
        ((LinearLayout.LayoutParams) chev.getLayoutParams()).leftMargin = dp(12);

        final Slider sl = new Slider(this, density, (init - min) / (max - min), new String[]{"0.5×", "1.0×", "1.5×"}, (v, done) -> {
            float x = Math.round((min + v * (max - min)) * 100f) / 100f;
            val.setText(fmtScale(x));
            if (done) cfg.edit().putFloat("pendant_scale", x).apply();
        });
        FrameLayout sliderBox = new FrameLayout(this);
        sliderBox.setPadding(dp(20), 0, dp(20), 0);
        sliderBox.addView(sl, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.addView(sliderBox, new LinearLayout.LayoutParams(-1, -2));
        inner.addView(actionRow("恢复默认", "1.0×，位置回到抖音原处", () -> {
            cfg.edit().putFloat("pendant_scale", 1f).putLong("pendant_reset", System.currentTimeMillis()).apply();
            sl.set(0.5f);
            val.setText(fmtScale(1f));
        }));
        final FrameLayout panel = new FrameLayout(this);
        panel.addView(inner);
        panel.setVisibility(View.GONE);

        LinearLayout body = cardBody();
        body.addView(new Press(this, head, -1, () -> {
            final boolean open = panel.getVisibility() != View.VISIBLE;
            panel.measure(View.MeasureSpec.makeMeasureSpec(content.getWidth() - dp(56), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int full = panel.getMeasuredHeight(), from = open ? 0 : panel.getHeight();
            final ViewGroup.LayoutParams lp = panel.getLayoutParams();
            lp.height = from;
            panel.setVisibility(View.VISIBLE);
            ValueAnimator a = ValueAnimator.ofInt(from, open ? full : 0);
            a.setDuration(240);
            a.setInterpolator(new DecelerateInterpolator(1.6f));
            a.addUpdateListener(v -> {
                lp.height = (int) v.getAnimatedValue();
                panel.setLayoutParams(lp);
            });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    lp.height = -2;
                    panel.setVisibility(open ? View.VISIBLE : View.GONE);
                    panel.setLayoutParams(lp);
                }
            });
            a.start();
            chev.animate().rotation(open ? 180f : 0f).setDuration(240).start();
        }));
        body.addView(panel, new LinearLayout.LayoutParams(-1, -2));
        return wrapCard(body);
    }

    /** 深色模式：点击后新主题从开关位置圆形扩散（切回时原路收回）。 */
    private View darkRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text("深色模式", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, animateDark != dark, density);
        if (animateDark) {
            animateDark = false;
            sw.post(() -> sw.set(dark));
        }
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            int[] loc = new int[2];
            sw.getLocationInWindow(loc);
            setDark(!dark, new RectF(loc[0], loc[1], loc[0] + sw.getWidth(), loc[1] + sw.getHeight()));
        });
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    /**
     * 卡片：三层柔和阴影（紧、中、宽）代替边框；内容按圆角裁剪，所以行的波纹/按压范围正好对齐卡片边缘。
     * 首行上、末行下补 16dp，行与行之间内容间距为 16dp。
     */
    private View wrapCard(LinearLayout body) {
        View first = ((ViewGroup) body.getChildAt(0)).getChildAt(0);
        first.setPadding(first.getPaddingLeft(), dp(16), first.getPaddingRight(), first.getPaddingBottom());
        View last = ((ViewGroup) body.getChildAt(body.getChildCount() - 1)).getChildAt(0);
        last.setPadding(last.getPaddingLeft(), last.getPaddingTop(), last.getPaddingRight(), dp(16));

        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x0F000000, 0x17000000);
        shadowLayer(w, 8, 0x0A000000, 0x12000000);
        shadowLayer(w, 18, 0x07000000, 0x0F000000);
        body.setElevation(dp(19));
        body.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16));
                o.setAlpha(0f);   // 只用于裁剪，不产生阴影
            }
        });
        body.setClipToOutline(true);
        body.setBackground(new CardArt(density));
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(16));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 一个选项一张卡片。 */
    private View single(View row) {
        LinearLayout b = cardBody();
        b.addView(row);
        return wrapCard(b);
    }

    /** 不同组之间 32–48dp；卡片之间 12dp。 */
    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
