package com.dyhide;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RenderEffect;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.HapticFeedbackConstants;
import android.view.PixelCopy;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.widget.FrameLayout;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    static int BG, CARD, INK, SUB, ACCENT, OFF, HAIR;
    static boolean dark;
    static final long IN = 210, OUT = 210;   // Figma 转场：Move In 280ms Ease Out；Move Out 240ms Ease In；不回弹
    static final float DIM = 0.35f;          // 底层页面的深色遮罩最大不透明度
    static final String VOL = "1.4.0";
    static final long RIPPLE = 200;           // 所有点击波纹统一：200ms 快速扩散
    static final int REQ_EXPORT = 11, REQ_IMPORT = 12;
    static final String[] TABS = {"规则", "外观", "设置"};
    static final String[] TAB_EN = {"RULES", "APPEARANCE", "SETTINGS"};

    static void palette(boolean d) {
        dark = d;
        // 哑光纸：暖灰白 / 炭黑；点缀色取酒红 / 暗金，克制不跳
        BG = d ? 0xFF141311 : 0xFFEFEBE3;
        CARD = d ? 0xFF1E1C19 : 0xFFF8F5EF;
        INK = d ? 0xFFEBE5D9 : 0xFF1C1B18;
        SUB = d ? 0xFF958D7F : 0xFF7B756B;
        ACCENT = d ? 0xFFC9A66B : 0xFF7D3A2E;
        OFF = d ? 0xFF3A3630 : 0xFFD0C9BB;
        HAIR = d ? 0x24EBE5D9 : 0x261C1B18;
    }

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    /** 可按压的容器：按下内容缩到 96%，松手时弹簧回弹（先略超过 100% 再落回）；波纹从手指按下的位置扩散。 */
    private static final class Press extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float rx, ry, radius, alpha;
        private ValueAnimator grow, fade, spring;

        Press(Context c, View content, int width, Runnable click) {
            super(c);
            setWillNotDraw(false);
            addView(content, new LayoutParams(width, -2));
            setOnClickListener(v -> click.run());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (alpha > 0f) {
                paint.setAlpha((int) (alpha * 46));
                canvas.drawCircle(rx, ry, radius, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) down(e.getX(), e.getY());
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) up();
            return super.onTouchEvent(e);
        }

        private void down(float x, float y) {
            if (fade != null) fade.cancel();
            if (spring != null) spring.cancel();
            paint.setColor(dark ? Color.WHITE : Color.BLACK);
            rx = x;
            ry = y;
            alpha = 1f;
            grow = ValueAnimator.ofFloat(0f, (float) Math.hypot(Math.max(x, getWidth() - x), Math.max(y, getHeight() - y)));
            grow.setDuration(RIPPLE);
            grow.setInterpolator(new DecelerateInterpolator());
            grow.addUpdateListener(a -> { radius = (float) a.getAnimatedValue(); invalidate(); });
            grow.start();
            getChildAt(0).animate().cancel();
            getChildAt(0).animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
        }

        private void up() {
            fade = ValueAnimator.ofFloat(alpha, 0f);
            fade.setDuration(220);
            fade.addUpdateListener(a -> { alpha = (float) a.getAnimatedValue(); invalidate(); });
            fade.start();
            final View c = getChildAt(0);
            c.animate().cancel();
            final float from = c.getScaleX();
            spring = ValueAnimator.ofFloat(0f, 0.5f);   // 数值为秒；欠阻尼弹簧：x(t) = 1 - (1-from)·e^(-ζω0t)·(cos ωd·t + ζω0/ωd·sin ωd·t)
            spring.setDuration(500);
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                double w0 = 2 * Math.PI * 3.2, z = 0.42, wd = w0 * Math.sqrt(1 - z * z);
                float s = a.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t)));
                c.setScaleX(s);
                c.setScaleY(s);
            });
            spring.start();
        }
    }

    /** 半透明的纸：底色 + 柔和高光 + 极细纸纹颗粒 + 右上角渐隐的半调网点 + 底部淡淡的压暗。 */
    private static final class Paper extends Drawable {
        private final Paint fill = new Paint(), glow = new Paint(), shade = new Paint(), grain = new Paint();
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), star = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path sp = new Path();
        private final float d;

        Paper(float density) {
            d = density;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, 0.8f * d));
            line.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            star.setColor(ACCENT);
            fill.setColor(BG);
            int n = 128;
            int[] px = new int[n * n];
            Random r = new Random(7);
            int rgb = dark ? 0xFFFFFF : 0x000000;
            for (int i = 0; i < px.length; i++) {
                if (r.nextInt(100) < 38) px[i] = ((2 + r.nextInt(dark ? 9 : 11)) << 24) | rgb;
            }
            grain.setShader(new BitmapShader(Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888),
                    Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            dot.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            dot.setAlpha(dark ? 22 : 26);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float w = Math.max(1, b.width()), h = Math.max(1, b.height());
            int hi = dark ? 0x1AC9A66B : 0x80FFFFFF, hi0 = dark ? 0x00C9A66B : 0x00FFFFFF;
            glow.setShader(new RadialGradient(w * 0.9f, 0f, w * 1.1f, hi, hi0, Shader.TileMode.CLAMP));
            int lo = dark ? 0x40000000 : 0x14503A1E;
            shade.setShader(new LinearGradient(0f, h * 0.65f, 0f, h, lo & 0x00FFFFFF, lo, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, fill);
            c.drawRect(b, glow);
            c.drawRect(b, shade);
            // 半调网点：错行排布，越靠右上角越大，向内渐隐
            float sp = 10 * d, maxR = 2.6f * d, reach = b.width() * 0.95f;
            int row = 0;
            for (float y = 0; y < reach; y += sp * 0.5f, row++) {
                for (float x = (row % 2) * sp * 0.5f; x < reach; x += sp) {
                    float t = 1f - (float) Math.hypot(x, y) / reach;
                    if (t <= 0f) continue;
                    float r = maxR * t * t;
                    if (r >= 0.35f * d) c.drawCircle(b.right - x, b.top + y, r, dot);
                }
            }
            ornaments(c, b);
            c.drawRect(b, grain);
        }

        /** 杂志版式小元素：四角套准十字、左下同心弧、左缘刻度尺、散落的四角星。 */
        private void ornaments(Canvas c, Rect b) {
            line.setAlpha(dark ? 60 : 64);
            float m = 12 * d, k = 7 * d;
            float[][] corner = {{b.left + m, b.top + m}, {b.right - m, b.top + m}, {b.left + m, b.bottom - m}, {b.right - m, b.bottom - m}};
            for (float[] q : corner) {
                c.drawLine(q[0] - k, q[1], q[0] + k, q[1], line);
                c.drawLine(q[0], q[1] - k, q[0], q[1] + k, line);
                c.drawCircle(q[0], q[1], 3.5f * d, line);
            }
            line.setAlpha(dark ? 26 : 30);
            for (int i = 1; i <= 5; i++) c.drawCircle(b.left - 20 * d, b.bottom - 170 * d, 34 * d * i, line);
            line.setAlpha(dark ? 50 : 56);
            float y0 = b.top + b.height() * 0.38f;
            for (int i = 0; i < 18; i++) {
                float y = y0 + i * 12 * d, len = (i % 4 == 0 ? 9 : 4) * d;
                c.drawLine(b.left, y, b.left + len, y, line);
            }
            star.setAlpha(dark ? 120 : 90);
            star(c, b.left + b.width() * 0.14f, b.top + b.height() * 0.30f, 8 * d);
            star(c, b.left + b.width() * 0.88f, b.top + b.height() * 0.56f, 6 * d);
            star(c, b.left + b.width() * 0.34f, b.top + b.height() * 0.74f, 4.5f * d);
            star(c, b.left + b.width() * 0.76f, b.top + b.height() * 0.86f, 7 * d);
            // 散点：十字、空心圆（固定种子，每次画在同一处）
            Random rnd = new Random(5);
            for (int i = 0; i < 14; i++) {
                float x = b.left + (0.06f + 0.88f * rnd.nextFloat()) * b.width(), y = b.top + (0.04f + 0.92f * rnd.nextFloat()) * b.height(), r = (2.5f + 2.5f * rnd.nextFloat()) * d;
                line.setAlpha(dark ? 46 : 52);
                if (i % 2 == 0) {
                    c.drawLine(x - r, y, x + r, y, line);
                    c.drawLine(x, y - r, x, y + r, line);
                } else {
                    c.drawCircle(x, y, r, line);
                }
            }
            // 右下角斜线影线、左下角半调网点
            line.setAlpha(dark ? 30 : 34);
            for (int i = 0; i < 9; i++) c.drawLine(b.right - 110 * d + i * 12 * d, b.bottom - 10 * d, b.right - 10 * d, b.bottom - 110 * d + i * 12 * d, line);
            float reach = b.width() * 0.5f, spc = 10 * d;
            int row = 0;
            for (float yy = 0; yy < reach; yy += spc * 0.5f, row++) {
                for (float xx = (row % 2) * spc * 0.5f; xx < reach; xx += spc) {
                    float t = 1f - (float) Math.hypot(xx, yy) / reach;
                    if (t > 0f && 2f * d * t * t >= 0.35f * d) c.drawCircle(b.left + xx, b.bottom - yy, 2f * d * t * t, dot);
                }
            }
        }

        private void star(Canvas c, float x, float y, float r) {
            sp.reset();
            sp.moveTo(x, y - r);
            sp.quadTo(x, y, x + r, y);
            sp.quadTo(x, y, x, y + r);
            sp.quadTo(x, y, x - r, y);
            sp.quadTo(x, y, x, y - r);
            c.drawPath(sp, star);
        }

        @Override
        public void setAlpha(int a) {}

        @Override
        public void setColorFilter(ColorFilter f) {}

        @Override
        public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    /**
     * 所有页面共用的滚动容器：
     * 1) 到顶/到底后继续拖，整页按距离（带阻尼）纵向拉伸，松手弹簧回位；
     * 2) 翻（甩）到顶部或底部时，整页弹一下回位，只弹一次；
     * 3) 滑动遮罩：内容滑到上下边缘时渐隐消失，离开边缘越远遮得越实，到顶/到底处无遮罩。
     */
    private static final class PullScroll extends ScrollView {
        View col;
        private final Paint maskTop = new Paint(), maskBot = new Paint();
        private final float d = getResources().getDisplayMetrics().density;
        private final android.graphics.Matrix m = new android.graphics.Matrix();
        private float startY, sign = 1f, act;
        private boolean pulling;
        private ValueAnimator spring;

        PullScroll(Context c) {
            super(c);
            maskTop.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            maskBot.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            maskTop.setShader(new LinearGradient(0f, 0f, 0f, 1f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
            maskBot.setShader(new LinearGradient(0f, 0f, 0f, 1f, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        }

        /** 最近的滚动方向与力度：往下滑为正，往上滑为负，逐帧衰减回 0。 */
        private final Runnable decay = new Runnable() {
            @Override
            public void run() {
                act *= 0.93f;
                if (Math.abs(act) < 0.01f) act = 0f;
                else postOnAnimation(this);
                invalidate();
            }
        };

        @Override
        protected void dispatchDraw(Canvas c) {
            int y = getScrollY(), h = getHeight();
            float kt = Math.min(1f, y / (48 * d)), kb = Math.min(1f, Math.max(0f, col.getHeight() - h - y) / (48 * d));
            if (kt <= 0f && kb <= 0f) {
                super.dispatchDraw(c);
                return;
            }
            // 滑动遮罩：往下滑时底部遮罩变高，内容从遮罩里逐渐显现；往上滑时顶部同理；停下后遮罩缓缓收回
            float tb = (36 + 160 * Math.max(0f, -act)) * d, bb = (120 + 200 * Math.max(0f, act)) * d;
            int layer = c.saveLayer(0f, y, getWidth(), y + h, null);
            super.dispatchDraw(c);
            c.translate(0f, y);
            m.setScale(1f, tb);
            maskTop.getShader().setLocalMatrix(m);
            m.setScale(1f, bb);
            m.postTranslate(0f, h - bb);
            maskBot.getShader().setLocalMatrix(m);
            maskTop.setAlpha((int) (255 * kt));
            maskBot.setAlpha((int) (255 * kb));
            c.drawRect(0f, 0f, getWidth(), tb, maskTop);
            c.drawRect(0f, h - bb, getWidth(), h, maskBot);
            c.restoreToCount(layer);
        }

        private void stretch(float s) {
            col.setPivotX(col.getWidth() / 2f);
            col.setPivotY(sign > 0 ? 0f : col.getHeight());
            col.setScaleY(s);
        }

        /** 欠阻尼弹簧回到 1：先越过一点再落回，肉眼只见一次回弹。 */
        private void springBack(final float from) {
            if (spring != null) spring.cancel();
            spring = ValueAnimator.ofFloat(0f, 0.7f);   // 数值为秒
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(v -> {
                float t = (float) v.getAnimatedValue();
                double w0 = 2 * Math.PI * 2.4, z = 0.6, wd = w0 * Math.sqrt(1 - z * z);
                stretch(v.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t))));
            });
            spring.setDuration(700);
            spring.start();
        }

        @Override
        protected void onScrollChanged(int l, int t, int ol, int ot) {
            super.onScrollChanged(l, t, ol, ot);
            act = Math.max(-1f, Math.min(1f, act + (t - ot) / (getHeight() * 0.25f)));
            removeCallbacks(decay);
            postOnAnimation(decay);
            if (pulling) return;
            int max = Math.max(0, col.getHeight() - getHeight());
            boolean top = t == 0 && ot > 0, bottom = max > 0 && t == max && ot < max;
            if (!top && !bottom) return;
            sign = top ? 1f : -1f;
            springBack(1f + Math.min(0.16f, Math.max(0.06f, Math.abs(t - ot) / (getHeight() * 0.8f))));
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (spring != null) spring.cancel();
                pulling = false;
                startY = e.getRawY();
            } else if (a == MotionEvent.ACTION_MOVE && !pulling) {
                float dy = e.getRawY() - startY;
                int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
                boolean top = dy > slop && !canScrollVertically(-1), bottom = dy < -slop && !canScrollVertically(1);
                if (top || bottom) {
                    pulling = true;
                    sign = top ? 1f : -1f;
                    startY = e.getRawY();
                    if (spring != null) spring.cancel();
                    MotionEvent c = MotionEvent.obtain(e);
                    c.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(c);   // 列表自己的滚动/点击放弃这次触摸
                    c.recycle();
                }
            }
            if (!pulling) return super.dispatchTouchEvent(e);
            if (a == MotionEvent.ACTION_MOVE) {
                float pull = Math.max(0f, sign * (e.getRawY() - startY));
                stretch(1f + 0.30f * (1f - (float) Math.exp(-pull / (getHeight() * 0.35f))));
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                pulling = false;
                springBack(col.getScaleY());
            }
            return true;
        }
    }

    private interface Change { void on(float v, boolean done); }

    /** 0..1 的滑杆：细轨道 + 空心圆钮 + 三个刻度。 */
    private static final class Slider extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        static boolean touched;
        private final Change cb;
        private final String[] marks;
        private float v;

        Slider(Context c, float density, float v, String[] marks, Change cb) {
            super(c);
            d = density;
            this.v = v;
            this.marks = marks;
            this.cb = cb;
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setTextSize(11 * d);
        }

        void set(float x) {
            v = x;
            invalidate();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(60 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float pad = 12 * d, cy = 22 * d, x0 = pad, x1 = getWidth() - pad, x = x0 + (x1 - x0) * v;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * d);
            p.setColor(OFF);
            c.drawLine(x0, cy, x1, cy, p);
            p.setColor(ACCENT);
            c.drawLine(x0, cy, x, cy, p);
            p.setStrokeWidth(1 * d);
            p.setColor(SUB);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f;
                c.drawLine(tx, cy + 14 * d, tx, cy + 19 * d, p);
            }
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f, w = p.measureText(marks[i]);
                c.drawText(marks[i], i == 0 ? tx - 4 * d : i == 1 ? tx - w / 2f : tx - w + 4 * d, cy + 36 * d, p);
            }
            p.setColor(CARD);
            c.drawCircle(x, cy, 10 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(ACCENT);
            c.drawCircle(x, cy, 10 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                touched = true;   // 页面切换的左右滑动手势要避开滑杆
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            float pad = 12 * d;
            v = Math.max(0f, Math.min(1f, (e.getX() - pad) / Math.max(1f, getWidth() - 2 * pad)));
            invalidate();
            cb.on(v, a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL);
            return true;
        }
    }

    /** 返回箭头图标。 */
    private static final class Arrow extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        Arrow(Context c, float density) {
            super(c);
            d = density;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(2.2f * d);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(44 * d), Math.round(44 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, s = 9 * d;
            paint.setColor(INK);
            c.drawLine(cx - s, cy, cx + s, cy, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy - s * 0.65f, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy + s * 0.65f, paint);
        }
    }

    /** 开关：起步时前沿先走、横向拉长成胶囊；后沿滞后跟上，落位时压回原宽（略压窄再回弹），不像一张贴纸。 */
    private static final class Toggle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        boolean checked;
        private float l, r, cp;   // 圆点左右边缘(px)、轨道颜色进度
        private ValueAnimator anim;

        Toggle(Context c, boolean on, float density) {
            super(c);
            d = density;
            checked = on;
            l = (on ? 24f : 4f) * d;
            r = l + 24 * d;
            cp = on ? 1f : 0f;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(52 * d), Math.round(32 * d));
        }

        void set(boolean on) {
            checked = on;
            if (anim != null) anim.cancel();
            final float l0 = l, r0 = r, l1 = (on ? 24f : 4f) * d, r1 = l1 + 24 * d, c0 = cp, c1 = on ? 1f : 0f;
            final boolean right = l1 > l0;
            final OvershootInterpolator squash = new OvershootInterpolator(2.2f);
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(460);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                float t = a.getAnimatedFraction();
                float x = Math.min(1f, t / 0.7f);
                float lead = 1f - (1f - x) * (1f - x) * (1f - x);
                float trail = squash.getInterpolation(Math.max(0f, (t - 0.15f) / 0.85f));
                l = l0 + (l1 - l0) * (right ? trail : lead);
                r = r0 + (r1 - r0) * (right ? lead : trail);
                cp = c0 + (c1 - c0) * lead;
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            paint.setColor((Integer) new ArgbEvaluator().evaluate(Math.max(0f, Math.min(1f, cp)), OFF, ACCENT));
            rect.set(0, 0, getWidth(), h);
            c.drawRoundRect(rect, h / 2, h / 2, paint);
            paint.setColor(Color.WHITE);
            rect.set(l, 4 * d, r, h - 4 * d);
            c.drawRoundRect(rect, 12 * d, 12 * d, paint);
        }
    }

    /**
     * 底部导航（约 400ms）：选中项背后的胶囊像水滴流向新位置——前沿先到，后沿慢半拍用带轻微回弹的弹簧跟上，
     * 途中被拉长、高度略扁；新选中的图标先缩小再弹回，文字颜色渐变。
     */
    private static final class NavBar extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF(), cap = new RectF();
        private final Path clip = new Path();
        private final float d;
        private final IntConsumer onSelect;
        private float rx, ry, rr, ra;   // 点击波纹：圆心、半径、透明度
        private ValueAnimator rip;
        private final float[] left = new float[3], wid = new float[3], tl = new float[3], tw = new float[3], edge = new float[2];
        private int to;
        private float sPos, sL, sR, t = 1f;   // 起点：布局位置、胶囊左右边缘；t：0..1 进度
        private ValueAnimator anim;

        NavBar(Context c, float density, IntConsumer onSelect) {
            super(c);
            d = density;
            this.onSelect = onSelect;
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setTextSize(14 * d);
            paint.setFakeBoldText(true);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(80 * d) + getPaddingBottom());
        }

        private void layout(float pos, float[] l, float[] w) {
            float small = 56 * d, big = 132 * d, x = (getWidth() - (2 * small + big)) / 2f;
            for (int i = 0; i < 3; i++) {
                w[i] = small + (big - small) * Math.max(0f, 1f - Math.abs(pos - i));
                l[i] = x;
                x += w[i];
            }
        }

        private float pos() {
            return sPos + (to - sPos) * (1f - (1f - t) * (1f - t) * (1f - t));
        }

        /** 欠阻尼弹簧（ζ=0.67，约 6% 回弹），u 为 0..1 的归一化时间。 */
        private static float spring(float u) {
            if (u >= 1f) return 1f;
            double s = u * 0.35, z = 0.67, w0 = 20.2, wd = w0 * Math.sqrt(1 - z * z);
            return (float) (1 - Math.exp(-z * w0 * s) * (Math.cos(wd * s) + z * w0 / wd * Math.sin(wd * s)));
        }

        /** 当前胶囊的左右边缘：行进方向的前沿快速到位，后沿延迟 12% 后用弹簧跟上。 */
        private void edges(float[] o) {
            layout(to, tl, tw);
            float tL = tl[to], tR = tl[to] + tw[to];
            float lead = 1f - (float) Math.pow(1f - Math.min(1f, t / 0.65f), 3);
            float lag = spring(Math.max(0f, (t - 0.12f) / 0.88f));
            boolean right = tL >= sL;
            o[0] = sL + (tL - sL) * (right ? lag : lead);
            o[1] = sR + (tR - sR) * (right ? lead : lag);
        }

        /** 新选中图标：先缩到 78%，再带一点回弹弹回 100%。 */
        private float pop() {
            if (t >= 1f) return 1f;
            if (t < 0.3f) {
                float u = t / 0.3f;
                return 1f - 0.22f * (1f - (1f - u) * (1f - u));
            }
            double s = (t - 0.3f) / 0.7f;
            return (float) (1 - 0.22 * Math.exp(-3.5 * s) * Math.cos(2 * Math.PI * 1.1 * s));
        }

        void select(int i, boolean animate) {
            if (anim != null) anim.cancel();
            if (!animate) {
                to = i;
                sPos = i;
                t = 1f;
                invalidate();
                return;
            }
            float p = pos();
            edges(edge);
            sPos = p;
            sL = edge[0];
            sR = edge[1];
            to = i;
            t = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(400);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float capW = 244 * d + 24 * d, cy = 40 * d, p = pos();
            cap.set((getWidth() - capW) / 2f, 8 * d, (getWidth() + capW) / 2f, 72 * d);
            paint.setStyle(Paint.Style.STROKE);   // 整条底栏全透明，只留一圈细线勾出胶囊
            paint.setStrokeWidth(Math.max(1f, 1f * d));
            paint.setColor(SUB);
            paint.setAlpha(dark ? 120 : 110);
            c.drawRoundRect(cap, 32 * d, 32 * d, paint);
            if (ra > 0f) {
                clip.reset();
                clip.addRoundRect(cap, 32 * d, 32 * d, Path.Direction.CW);
                c.save();
                c.clipPath(clip);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(dark ? Color.WHITE : Color.BLACK);
                paint.setAlpha((int) (ra * 46));
                c.drawCircle(rx, ry, rr, paint);
                c.restore();
            }
            paint.setStyle(Paint.Style.FILL);
            layout(p, left, wid);
            edges(edge);
            float flat = 0.10f * (float) Math.sin(Math.PI * Math.min(1f, t / 0.75f));   // 途中高度略扁
            float ph = 44 * d * (1f - flat);
            paint.setColor(ACCENT);
            paint.setAlpha(dark ? 56 : 36);
            rect.set(edge[0], cy - ph / 2f, edge[1], cy + ph / 2f);
            c.drawRoundRect(rect, ph / 2f, ph / 2f, paint);
            for (int i = 0; i < 3; i++) {
                float w = Math.max(0f, 1f - Math.abs(p - i));
                int col = (Integer) new ArgbEvaluator().evaluate(w, SUB, ACCENT);
                float gap = 8 * d * w, group = 22 * d + gap + paint.measureText(TABS[i]) * w;
                float gx = left[i] + (wid[i] - group) / 2f;
                c.save();
                if (i == to) {
                    float sc = pop();
                    c.scale(sc, sc, gx + 11 * d, cy);
                }
                icon(c, i, gx + 11 * d, cy, col);
                c.restore();
                if (w > 0.05f) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    paint.setAlpha((int) (255 * w));
                    c.save();
                    c.clipRect(left[i], 0, left[i] + wid[i], getHeight());
                    c.drawText(TABS[i], gx + 22 * d + gap, cy + 5 * d, paint);
                    c.restore();
                }
            }
        }

        private void icon(Canvas c, int i, float cx, float cy, int col) {
            float s = 11 * d;
            paint.setColor(col);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * d);
            if (i == 0) {
                for (int k = -1; k <= 1; k++) c.drawLine(cx - s, cy + k * 6 * d, cx + s * (k == 0 ? 0.5f : 1f), cy + k * 6 * d, paint);
            } else if (i == 1) {
                c.drawCircle(cx, cy, s, paint);
                paint.setStyle(Paint.Style.FILL);
                rect.set(cx - s, cy - s, cx + s, cy + s);
                c.drawArc(rect, 90, 180, true, paint);
            } else {
                c.drawCircle(cx, cy, s * 0.45f, paint);
                for (int k = 0; k < 8; k++) {
                    float cos = (float) Math.cos(k * Math.PI / 4), sin = (float) Math.sin(k * Math.PI / 4);
                    c.drawLine(cx + cos * s * 0.75f, cy + sin * s * 0.75f, cx + cos * s, cy + sin * s, paint);
                }
            }
        }

        private void ripple(float x, float y) {
            rx = x;
            ry = y;
            final float max = (float) Math.hypot(Math.max(x - cap.left, cap.right - x), Math.max(y - cap.top, cap.bottom - y));
            if (rip != null) rip.cancel();
            rip = ValueAnimator.ofFloat(0f, 1f);
            rip.setDuration(RIPPLE * 8 / 5);   // 前 62% 时间扩散到最大（= RIPPLE），之后淡出
            rip.setInterpolator(new LinearInterpolator());
            rip.addUpdateListener(a -> {
                float u = a.getAnimatedFraction(), g = Math.min(1f, u / 0.62f);
                rr = max * (1f - (1f - g) * (1f - g) * (1f - g));
                ra = 1f - Math.max(0f, (u - 0.35f) / 0.65f);
                invalidate();
            });
            rip.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (!cap.contains(e.getX(), e.getY())) return false;   // 胶囊以外全透明，触摸直接落到页面上
                ripple(e.getX(), e.getY());
            } else if (a == MotionEvent.ACTION_UP) {
                for (int i = 0; i < 3; i++) if (e.getX() >= left[i] && e.getX() < left[i] + wid[i]) onSelect.accept(i);
            }
            return true;
        }
    }

    /** 深色模式切换：新主题从开关位置圆形扩散；切回时原路收回。叠加层是切换前的截图，开关处按胶囊形状抠空，露出实时的开关。 */
    private static final class Reveal extends View {
        private final Bitmap old;
        private final Path path = new Path();
        private final Paint erase = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF hole;
        private final float cx, cy, max;
        private final boolean expand;
        private float radius;

        Reveal(Context c, Bitmap old, RectF hole, boolean expand) {
            super(c);
            this.old = old;
            this.hole = hole;
            cx = hole.centerX();
            cy = hole.centerY();
            this.expand = expand;
            max = (float) Math.hypot(Math.max(cx, old.getWidth() - cx), Math.max(cy, old.getHeight() - cy));
            radius = expand ? 0f : max;
            erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        }

        void start() {
            ValueAnimator a = expand ? ValueAnimator.ofFloat(0f, max) : ValueAnimator.ofFloat(max, 0f);
            a.setDuration(540);
            a.setInterpolator(new AccelerateDecelerateInterpolator());
            a.addUpdateListener(v -> { radius = (float) v.getAnimatedValue(); invalidate(); });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    ((ViewGroup) getParent()).removeView(Reveal.this);
                    old.recycle();
                }
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            path.reset();
            path.addCircle(cx, cy, radius, Path.Direction.CW);
            int layer = c.saveLayer(0f, 0f, (float) getWidth(), (float) getHeight(), null);
            c.save();
            if (expand) c.clipOutPath(path);   // 圆内露出新主题（实时界面），圆外仍是旧截图
            else c.clipPath(path);             // 圆内是旧主题截图，随圆缩小被新主题取代
            c.drawBitmap(old, 0, 0, null);
            c.restore();
            // 开关本体：按胶囊抠空（带抗锯齿），边缘不再出现矩形的新旧主题接缝
            c.drawRoundRect(hole, hole.height() / 2f, hole.height() / 2f, erase);
            c.restoreToCount(layer);
        }
    }

    /** 页眉的条码装饰。 */
    private static final class Barcode extends View {
        private final Paint p = new Paint();
        private final float[] w = new float[24];
        private final float d;

        Barcode(Context c, float density) {
            super(c);
            d = density;
            Random r = new Random(11);
            for (int i = 0; i < w.length; i++) w[i] = (1 + r.nextInt(3)) * 0.8f;
        }

        @Override
        protected void onMeasure(int a, int b) {
            setMeasuredDimension(Math.round(64 * d), Math.round(14 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            p.setColor(SUB);
            p.setAlpha(150);
            float x = 0f;
            for (int i = 0; i < w.length && x < getWidth(); i++) {
                if (i % 2 == 0) c.drawRect(x, 0f, Math.min(getWidth(), x + w[i] * d), getHeight(), p);
                x += w[i] * d;
            }
        }
    }

    /** 卡片角落的半调网点（右下角向内渐隐）。 */
    private static final class CardArt extends Drawable {
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG), mark = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final float[][] spots;   // 每张卡片自己的几处点缀：x、y（占宽高的比例）、大小、形状

        CardArt(float density) {
            d = density;
            dot.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            dot.setAlpha(dark ? 26 : 30);
            mark.setStyle(Paint.Style.STROKE);
            mark.setStrokeWidth(Math.max(1f, 0.8f * d));
            mark.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            mark.setAlpha(dark ? 52 : 58);
            Random r = new Random();
            spots = new float[2 + r.nextInt(3)][];
            for (int i = 0; i < spots.length; i++) spots[i] = new float[]{0.05f + 0.9f * r.nextFloat(), 0.15f + 0.7f * r.nextFloat(), 2.5f + 2.5f * r.nextFloat(), r.nextInt(4)};
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            for (float[] q : spots) {
                float x = b.left + q[0] * b.width(), y = b.top + q[1] * b.height(), r = q[2] * d;
                if (q[3] == 0) {
                    c.drawLine(x - r, y, x + r, y, mark);
                    c.drawLine(x, y - r, x, y + r, mark);
                } else if (q[3] == 1) {
                    c.drawCircle(x, y, r, mark);
                } else if (q[3] == 2) {
                    c.drawLine(x - r, y, x, y - r, mark);
                    c.drawLine(x, y - r, x + r, y, mark);
                    c.drawLine(x + r, y, x, y + r, mark);
                    c.drawLine(x, y + r, x - r, y, mark);
                } else {
                    c.drawCircle(x, y, r * 0.35f, dot);
                }
            }
            float sp = 7 * d, reach = Math.min(b.width() * 0.5f, 120 * d);
            int row = 0;
            for (float y = 0; y < reach; y += sp * 0.5f, row++) {
                for (float x = (row % 2) * sp * 0.5f; x < reach; x += sp) {
                    float t = 1f - (float) Math.hypot(x, y) / reach;
                    if (t > 0f && 1.7f * d * t * t >= 0.3f * d) c.drawCircle(b.right - x, b.bottom - y, 1.7f * d * t * t, dot);
                }
            }
        }

        @Override
        public void setAlpha(int a) {}

        @Override
        public void setColorFilter(ColorFilter f) {}

        @Override
        public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** 全屏透明的火花层：盖在整个界面最上面，不挡触摸；彩蛋迸出的网点画在这里，不会被页面或页脚裁掉。 */
    private static final class Sparks extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();
        private final List<float[]> dots = new ArrayList<>();   // x, y, vx, vy, 剩余寿命(1→0), 半径, 色号
        private final float d;
        private long last;
        private boolean ticking;

        Sparks(Context c, float density) {
            super(c);
            d = density;
        }

        /** 屏幕坐标 → 本层坐标，再迸出 n 个点。 */
        void burstAt(float rawX, float rawY, int n, float speed) {
            int[] l = new int[2];
            getLocationOnScreen(l);
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2, v = speed * d * (0.35 + rnd.nextDouble() * 0.65);
                dots.add(new float[]{rawX - l[0], rawY - l[1], (float) (Math.cos(a) * v), (float) (Math.sin(a) * v) - 120 * d,
                        1f, (1.5f + rnd.nextFloat() * 3f) * d, rnd.nextInt(3)});
            }
            if (!ticking) {
                ticking = true;
                last = System.nanoTime();
                postOnAnimation(this::tick);
            }
        }

        private void tick() {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            for (Iterator<float[]> it = dots.iterator(); it.hasNext(); ) {
                float[] q = it.next();
                q[3] += 900 * d * dt;
                q[0] += q[2] * dt;
                q[1] += q[3] * dt;
                q[4] -= dt / 1.1f;
                if (q[4] <= 0f) it.remove();
            }
            invalidate();
            if (dots.isEmpty()) ticking = false;
            else postOnAnimation(this::tick);
        }

        @Override
        protected void onDraw(Canvas c) {
            for (float[] q : dots) {
                p.setColor(q[6] == 0 ? ACCENT : q[6] == 1 ? INK : SUB);
                p.setAlpha((int) (255 * q[4]));
                c.drawCircle(q[0], q[1], q[5] * (0.5f + 0.5f * q[4]), p);
            }
        }
    }

    /** 隐藏彩蛋：页脚里一枚几乎看不见的 ✦，自身背景全透明。点一下迸出一圈网点，按住拖动拖出一串；连点 7 下触发大迸发。 */
    private static final class Egg extends View {
        private static int taps;
        private static long lastTap;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Sparks sparks;
        private final float d;
        private final Runnable found;

        Egg(Context c, float density, Sparks sparks, Runnable found) {
            super(c);
            d = density;
            this.sparks = sparks;
            this.found = found;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(96 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            p.setTextSize(16 * d);
            p.setColor(SUB);
            p.setAlpha(70);
            c.drawText("✦", (getWidth() - p.measureText("✦")) / 2f, getHeight() / 2f + 6 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                long now = System.currentTimeMillis();
                taps = now - lastTap > 1500 ? 1 : taps + 1;
                lastTap = now;
                if (taps >= 7) {
                    taps = 0;
                    sparks.burstAt(e.getRawX(), e.getRawY(), 90, 520);
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    found.run();
                } else {
                    sparks.burstAt(e.getRawX(), e.getRawY(), 22, 300);
                }
            } else if (a == MotionEvent.ACTION_MOVE) {
                sparks.burstAt(e.getRawX(), e.getRawY(), 2, 120);
            }
            return true;
        }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private NavBar nav;
    private Sparks sparks;
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;
    private View scrim;                      // 夹在底层页和上层页之间的深色遮罩
    private ValueAnimator anim;              // 当前转场动画（同一时间只有一个）
    private View tTop, tUnder;
    private float tw;
    private boolean cand, dragging;
    private float x0, y0, dragX;
    private VelocityTracker vt;
    private boolean animateDark;   // 重建后的深色开关从旧状态起步，播放一次切换动画
    private boolean navHidden;     // 键盘起来时底栏收起了没有

    private SharedPreferences shared;   // 激活后抖音读取的那份（MODE_WORLD_READABLE，LSPosed 会把它放到另一个位置）：cfg 的镜像
    private final SharedPreferences.OnSharedPreferenceChangeListener mirror = (p, key) -> syncShared(key);

    /** 把本地配置 cfg 同步到 shared：key 为 null 时整份覆盖，否则只同步这一个键。 */
    private void syncShared(String key) {
        Map<String, ?> all = cfg.getAll();
        SharedPreferences.Editor e = shared.edit();
        if (key == null) e.clear();
        else if (!all.containsKey(key)) e.remove(key);
        for (Map.Entry<String, ?> x : all.entrySet()) {
            if (key != null && !key.equals(x.getKey())) continue;
            putAny(e, x.getKey(), x.getValue());
        }
        e.apply();
    }

    private static void putAny(SharedPreferences.Editor e, String k, Object v) {
        if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else if (v instanceof Float) e.putFloat(k, (Float) v);
        else if (v instanceof Long) e.putLong(k, (Long) v);
        else if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof String) e.putString(k, (String) v);
    }

    @Override
    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);   // 键盘弹出时窗口整体上移/让高，输入框才不会被盖住
        cfg = getSharedPreferences("config_local", MODE_PRIVATE);   // 界面读写的唯一一份，激活前后都是它
        if (isModuleActive()) {
            // 必须抢在任何 MODE_PRIVATE 打开 "config" 之前：同一进程里先打开的那个模式决定文件权限，
            // 先以私有模式打开，抖音那边就读不到这份配置了（所有开关全部失效）
            shared = getSharedPreferences("config", MODE_WORLD_READABLE);
        }
        if (!cfg.contains("migrated")) {   // 一次性：把旧版本留下的配置并进来（旧的本地那份优先，激活期间那份补缺）
            Map<String, Object> merged = new java.util.HashMap<>();
            if (shared != null) merged.putAll(shared.getAll());
            merged.putAll(getSharedPreferences("config", MODE_PRIVATE).getAll());
            SharedPreferences.Editor e = cfg.edit();
            for (Map.Entry<String, Object> x : merged.entrySet()) putAny(e, x.getKey(), x.getValue());
            e.putBoolean("migrated", true).apply();
        }
        if (shared != null) {
            syncShared(null);
            cfg.registerOnSharedPreferenceChangeListener(mirror);
        }
        density = getResources().getDisplayMetrics().density;
        palette(cfg.getBoolean("dark", false));
        build();
        if (b == null && !isModuleActive()) showInactive();   // 只在全新启动时提示；旋转屏幕等重建（b != null）不再重复弹
    }

    /** 恒为 false；模块生效时，在本应用自己的进程里被 MainHook 钩成 true（要求 LSPosed 作用域里勾选本模块）。 */
    static boolean isModuleActive() {
        return false;
    }

    /** 未激活：半透明卡片提示，“去激活”跳到 LSPosed 里本模块的页面，“请稍后”关闭。 */
    private void showInactive() {
        final ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        final FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(0x80000000);
        ov.setClickable(true);   // 挡住下面的触摸
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);   // 不透明
        bg.setCornerRadius(dp(28));
        card.setBackground(bg);
        card.addView(text("模块未激活", 21, INK, false));
        card.addView(text("请在LSPosed中激活此模块后重新打开", 18, SUB, false), lp(0, 10, 0, 18));
        card.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));   // 把按钮顶到卡片底部
        LinearLayout btns = new LinearLayout(this);
        btns.addView(pill("去激活", true, () -> {
            decor.removeView(ov);
            openLsposed();
        }), new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout.LayoutParams later = new LinearLayout.LayoutParams(0, -1, 1f);
        later.leftMargin = dp(12);
        btns.addView(pill("请稍后", false, () -> decor.removeView(ov)), later);
        card.addView(btns, new LinearLayout.LayoutParams(-1, dp(52)));   // 按钮高度固定 52dp
        DisplayMetrics dm = getResources().getDisplayMetrics();   // 4:3 的卡片再放大 1.5 倍：宽 = 屏幕短边 − 64dp，高 = 宽 × 3/4，横竖屏一样大
        int w = Math.min(dm.widthPixels, dm.heightPixels) - dp(64);
        ov.addView(card, new FrameLayout.LayoutParams(w, w * 3 / 4, Gravity.CENTER));
        ov.setAlpha(0f);
        decor.addView(ov, new FrameLayout.LayoutParams(-1, -1));
        ov.animate().alpha(1f).setDuration(200).start();
    }

    private View pill(String label, boolean primary, Runnable go) {
        TextView t = text(label, 18, primary ? Color.WHITE : INK, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(26));
        if (primary) g.setColor(ACCENT);
        else g.setStroke(Math.max(1, Math.round(dp(1) * 2.2f)), SUB);
        t.setBackground(g);
        Press p = new Press(this, t, -1, go);
        t.getLayoutParams().height = -1;   // Press 默认把内容按文字高度排，这里撑满整行，按钮才是真的“粗”
        return p;
    }

    private void openLsposed() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setClassName("org.lsposed.manager", "org.lsposed.manager.ui.activity.MainActivity");
        i.setData(Uri.parse("module://" + getPackageName() + ":0"));   // LSPosed 管理器的“模块页面”深链接
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {   // 管理器不在 / 入口不同：退回直接打开 LSPosed
            Intent l = getPackageManager().getLaunchIntentForPackage("org.lsposed.manager");
            if (l == null) toast("没找到 LSPosed 管理器，请手动打开");
            else startActivity(l);
        }
    }

    /** 按当前调色板重建整个界面（首次启动和切换深浅色时调用），回到当前标签的首页。 */
    private void build() {
        stacks.clear();
        refreshers.clear();
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        scrim = new View(this);
        scrim.setBackgroundColor(Color.BLACK);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        nav = new NavBar(this, density, this::switchTab);
        if (Build.VERSION.SDK_INT >= 28) {
            nav.setOutlineAmbientShadowColor(0x12000000);
            nav.setOutlineSpotShadowColor(0x1A000000);
        }
        root.addView(nav, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));   // 浮在页面上方，整条透明
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int sb = ins.getSystemWindowInsetBottom();
            int imeH = 0;
            if (Build.VERSION.SDK_INT >= 30) imeH = ins.getInsets(WindowInsets.Type.ime()).bottom;   // 键盘高度：有的系统上 systemWindowInsetBottom 拿不到
            int b = Math.max(sb, imeH);
            boolean ime = b > dp(160);   // 键盘高度远大于导航栏：此时收起底栏，并让页面整体让出键盘的高度
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ime ? b : 0);
            nav.setPadding(0, 0, 0, ime ? 0 : b);   // 底栏显隐交给下面的可见区域判定，两处不抢
            if (ime) v.post(this::scrollInputIntoView);
            return ins;
        });
        root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            // 窗口在 adjustResize 下会自己让出键盘高度，拿不到键盘 inset 的时候靠可见区域判断：底部少了超过 150dp 就是键盘起来了
            Rect vis = new Rect();
            root.getWindowVisibleDisplayFrame(vis);
            boolean ime = vis.bottom > 0 && root.getResources().getDisplayMetrics().heightPixels - vis.bottom > dp(150);
            if (ime != navHidden) {
                navHidden = ime;
                nav.setVisibility(ime ? View.GONE : View.VISIBLE);   // 打字时收起底栏，别压着输入框
            }
            if (ime) scrollInputIntoView();
        });
        sparks = new Sparks(this, density);
        root.addView(sparks, new FrameLayout.LayoutParams(-1, -1));   // 最上层、透明、不拦触摸
        setContentView(root);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        Page p = rootPage(tab);
        stacks.get(tab).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        nav.select(tab, false);
        syncBack(true);
    }

    /**
     * 输入法展开时，把正在输入的输入框顶到键盘上面：直接按“输入框底边 + 一点余量 − 可见区域底边”算出差多少，
     * 再把所在的列表滚这么多。设置页里的“我的昵称”就靠这个，光标和正在打的字不会再被键盘盖住。
     */
    private void scrollInputIntoView() {
        View f = getCurrentFocus();
        if (!(f instanceof EditText) || f.getHeight() == 0) return;
        Rect vis = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(vis);
        int[] loc = new int[2];
        f.getLocationOnScreen(loc);
        int over = loc[1] + f.getHeight() + dp(28) - vis.bottom;
        if (over <= 0) return;
        ViewParent p = f.getParent();
        while (p instanceof View && !(p instanceof PullScroll)) p = p.getParent();
        if (p instanceof PullScroll) ((PullScroll) p).smoothScrollBy(0, over);
        else f.requestRectangleOnScreen(new Rect(0, 0, f.getWidth(), f.getHeight() + dp(28)), true);
    }

    private void setDark(final boolean on, final RectF hole) {
        final View decor = getWindow().getDecorView();
        final Bitmap old = Bitmap.createBitmap(decor.getWidth(), decor.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.request(getWindow(), old, res -> {
            cfg.edit().putBoolean("dark", on).apply();
            palette(on);
            animateDark = true;
            build();
            if (res == PixelCopy.SUCCESS) {
                Reveal ov = new Reveal(this, old, hole, on);
                ((ViewGroup) decor).addView(ov, new FrameLayout.LayoutParams(-1, -1));
                ov.start();
            }
        }, new Handler(Looper.getMainLooper()));
    }

    // ---------- 导航：Figma 原型转场。进入 Move In（从右侧，210ms Ease Out），退出 Move Out（向右，210ms Ease In），
    // 底层页面不动，只叠一层渐变的深色遮罩；p = 上层页面的进入进度（0 在屏幕外，1 完全进入），动画和拖拽手势都驱动同一个 p。 ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void park(View v) {
        v.setVisibility(View.GONE);
        v.setTranslationX(0);
        v.setAlpha(1f);
    }

    private void setP(float p) {
        float progress = Math.max(0f, Math.min(1f, p));
        tTop.setTranslationX(tw * (1f - progress));
        scrim.setAlpha(DIM * progress);
    }

    /** 摆好转场现场：底层可见，遮罩在它上面，上层页面在遮罩上面。 */
    private void prepare(View top, View under, float p) {
        if (anim != null) anim.end();
        tw = content.getWidth();
        tTop = top;
        tUnder = under;
        under.animate().cancel();
        top.animate().cancel();
        under.setTranslationX(0);
        under.setAlpha(1f);
        under.setVisibility(View.VISIBLE);
        top.setAlpha(1f);
        top.setVisibility(View.VISIBLE);
        top.bringToFront();
        content.removeView(scrim);
        content.addView(scrim, content.getChildCount() - 1, new FrameLayout.LayoutParams(-1, -1));
        setP(p);
    }

    private void animateTo(float to, long base, PathInterpolator ip, final Runnable done) {
        float from = tTop.getTranslationX() == 0f ? 1f : 1f - tTop.getTranslationX() / tw;
        anim = ValueAnimator.ofFloat(from, to);
        anim.setDuration(Math.max(80, Math.round(base * Math.abs(to - from))));   // 按剩余距离折算时长
        anim.setInterpolator(ip);
        anim.addUpdateListener(a -> setP((float) a.getAnimatedValue()));
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                anim = null;
                setP(to);
                content.removeView(scrim);
                done.run();
            }
        });
        anim.start();
    }

    private static final PathInterpolator EASE_OUT = new PathInterpolator(0f, 0f, 0.58f, 1f);
    private static final PathInterpolator EASE_IN = new PathInterpolator(0.42f, 0f, 1f, 1f);

    private void push(final Page p) {
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        prepare(p.view, old.view, 0f);
        animateTo(1f, IN, EASE_OUT, () -> old.view.setVisibility(View.GONE));
        syncBack(true);
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (st.size() <= keep) return;
        if (anim != null) anim.end();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        float p = dragging ? 1f - topPage.view.getTranslationX() / tw : 1f;
        prepare(topPage.view, target.view, p);
        animateTo(0f, OUT, EASE_IN, () -> {
            target.view.setTranslationX(0f);
            content.removeView(topPage.view);
        });
        syncBack(true);
    }

    /** 底栏切换：新页面沿点击方向轻推并淡入，旧页面反向轻移并淡出，整体约 400ms。 */
    private void switchTab(int to) {
        if (to == tab) return;
        final float dir = to > tab ? 1f : -1f;
        final View from = top(tab).view;
        tab = to;
        nav.select(to, true);
        syncBack(true);
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        if (anim != null) anim.end();
        from.animate().cancel();
        in.animate().cancel();
        from.setVisibility(View.VISIBLE);
        from.setAlpha(1f);
        from.setTranslationX(0f);
        in.bringToFront();
        in.setVisibility(View.VISIBLE);
        in.setAlpha(0f);
        in.setTranslationX(dir * dp(36));
        from.animate().alpha(0f).translationX(-dir * dp(20)).setDuration(160)
                .setInterpolator(new DecelerateInterpolator(1.5f)).withEndAction(() -> park(from)).start();
        in.animate().alpha(1f).translationX(0f).setStartDelay(80).setDuration(320)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    /** 拖拽返回：在二级页面里向右拖，页面跟手滑出；松手时按进度和速度决定完成返回还是回到原位。 */
    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            tabSwipe = anim == null && stacks.get(tab).size() == 1;   // 一级页面：左右滑动切换 规则 / 外观 / 设置
            Slider.touched = false;
            cand = anim == null && stacks.get(tab).size() > 1 && cfg.getBoolean("back_swipe", true);
            x0 = e.getRawX();
            y0 = e.getRawY();
            if (vt != null) vt.recycle();
            vt = VelocityTracker.obtain();
        }
        if (vt != null) vt.addMovement(e);
        if (cand && !dragging && a == MotionEvent.ACTION_MOVE) {
            float dx = e.getRawX() - x0, dy = Math.abs(e.getRawY() - y0);
            int slop = ViewConfiguration.get(this).getScaledTouchSlop();
            if (dx > slop && dx > dy * 1.5f) {
                dragging = true;
                dragX = e.getRawX();
                List<Page> st = stacks.get(tab);
                prepare(st.get(st.size() - 1).view, st.get(st.size() - 2).view, 1f);
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);   // 让里面的列表/按钮放弃这次触摸
                c.recycle();
            } else if (dy > slop) {
                cand = false;
            }
        }
        if (dragging) {
            if (a == MotionEvent.ACTION_MOVE) {
                setP(1f - Math.max(0f, Math.min(1f, (e.getRawX() - dragX) / tw)));
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                vt.computeCurrentVelocity(1000);
                float p = 1f - tTop.getTranslationX() / tw, v = vt.getXVelocity();
                boolean back = a == MotionEvent.ACTION_UP && (v > 1000f || (p < 0.5f && v > -1000f));
                if (back) {
                    popTo(stacks.get(tab).size() - 1);
                    dragging = false;
                } else {
                    dragging = false;
                    final View under = tUnder;
                    animateTo(1f, IN, EASE_OUT, () -> under.setVisibility(View.GONE));
                }
                cand = false;
            }
            return true;
        }
        if (tabSwipe && !tabDragging && !Slider.touched && a == MotionEvent.ACTION_MOVE) {   // 一级页面横向拖动 → 跟手切换页面
            float dx = e.getRawX() - x0, dy = Math.abs(e.getRawY() - y0);
            int to = tab + (dx < 0 ? 1 : -1);
            if (Math.abs(dx) > ViewConfiguration.get(this).getScaledTouchSlop() && Math.abs(dx) > dy * 1.5f && to >= 0 && to <= 2) {
                startTabDrag(to, e);
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);   // 页面里的列表停止纵向滚动，这次触摸只用来切页
                c.recycle();
            }
        }
        if (tabDragging) {
            if (a == MotionEvent.ACTION_MOVE) {
                tabFx(tabProgress(e));
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                vt.computeCurrentVelocity(1000);
                float p = tabProgress(e), v = -vt.getXVelocity() * tabDir;
                finishTabDrag(a == MotionEvent.ACTION_UP && (p > 0.5f || v > 1000f) && v > -1000f, p);   // 和二级页面整页右滑一样：过半或甩得够快就完成
            }
            return true;
        }
        boolean handled = super.dispatchTouchEvent(e);
        return handled;
    }

    // ---------- 预测性返回：原路返回。手势进度直接驱动“进入动画”的反向——上层页面随手势沿进入的路径向右退出，
    // 底层遮罩同步变淡；松手返回则继续滑出，取消则滑回原位。仅 Android 14+；更低版本、三键导航走普通返回动画。 ----------
    private boolean tabSwipe, tabDragging;
    private int tabTo;
    private float tabDir, tabX0;
    private View tabFrom, tabIn;

    /** 开始跟手切页：准备好目标页，初始状态和点击底栏切换时动画的起点一样。 */
    private void startTabDrag(int to, MotionEvent e) {
        if (anim != null) anim.end();
        tabDragging = true;
        tabTo = to;
        tabDir = to > tab ? 1f : -1f;
        tabX0 = e.getRawX();
        tabFrom = top(tab).view;
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        tabIn = top(to).view;
        if (tabIn.getParent() == null) content.addView(tabIn, new FrameLayout.LayoutParams(-1, -1));
        tabFrom.animate().cancel();
        tabIn.animate().cancel();
        tabFrom.setVisibility(View.VISIBLE);
        tabIn.bringToFront();
        tabIn.setVisibility(View.VISIBLE);
        tabFx(0f);
    }

    private float tabProgress(MotionEvent e) {
        return Math.max(0f, Math.min(1f, -(e.getRawX() - tabX0) * tabDir / content.getWidth()));
    }

    /** p：0..1，两页整体跟着手指横向平移（1:1，和二级页面整页右滑一样的跟手速度）：旧页被推出去，新页从另一侧进来。 */
    private void tabFx(float p) {
        float w = content.getWidth();
        tabFrom.setTranslationX(-tabDir * w * p);
        tabIn.setTranslationX(tabDir * w * (1f - p));
    }

    /** 松手：完成就把剩下的动画播完并切到目标页，否则退回原页。 */
    private void finishTabDrag(final boolean commit, float p) {
        final View from = tabFrom, in = tabIn;
        if (commit) {
            tab = tabTo;
            nav.select(tabTo, true);
            syncBack(true);
        }
        ValueAnimator a = ValueAnimator.ofFloat(p, commit ? 1f : 0f);
        a.setDuration(Math.max(80, Math.round(IN * Math.abs((commit ? 1f : 0f) - p))));   // 和二级页面一样：按剩余距离折算时长
        a.setInterpolator(EASE_OUT);
        a.addUpdateListener(v -> tabFx((float) v.getAnimatedValue()));
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                anim = null;
                tabDragging = false;
                park(commit ? from : in);
                if (!commit) {
                    from.setAlpha(1f);
                    from.setTranslationX(0f);
                }
            }
        });
        anim = a;
        a.start();
    }
    private OnBackInvokedCallback backCb;
    private boolean predicting;
    private int bkStart, bkProg, bkCancel, bkInvoke;   // 系统返回手势各事件收到的次数，关于页可看
    private float bkMax, bkStartX, bkDx, bkLastX;   // 进度峰值、起点触摸 x、触摸位移峰值、最后一次触摸 x
    private int bkEdge = -1;
    private TextView bkView;

    private void syncBack() { syncBack(false); }

    private void refreshBk() {
        if (bkView != null) bkView.setText("返回手势事件（长按复制）\n开始 " + bkStart + "　进度 " + bkProg + "　进度峰值 " + String.format("%.2f", bkMax)
                + "　位移峰值 " + Math.round(bkDx) + "px　取消 " + bkCancel + "　触发 " + bkInvoke
                + "\n起点x " + Math.round(bkStartX) + "　末点x " + Math.round(bkLastX) + "　边缘 " + (bkEdge == BackEvent.EDGE_LEFT ? "左" : bkEdge == BackEvent.EDGE_RIGHT ? "右" : "无"));
    }

    /**
     * 二级页面的返回手势（预测性返回）。
     * 注册在默认优先级：系统只对默认优先级的回调派发 onBackStarted / onBackProgressed 这些跟手事件，
     * 之前用的 OVERLAY 档在 Android 16/17 上拿不到跟手进度，手势就等于没反应（首页没注册回调，走系统默认，所以是好的）。
     * 每次进出页面、回到前台、窗口重新拿到焦点都重注册一遍，回调永远是最新那一个。
     */
    private void syncBack(boolean force) {
        if (Build.VERSION.SDK_INT < 34) return;
        boolean want = stacks.get(tab).size() > 1;
        OnBackInvokedDispatcher disp = getOnBackInvokedDispatcher();
        if (!want) {
            if (backCb != null) {
                try { disp.unregisterOnBackInvokedCallback(backCb); } catch (Throwable ignored) { }
                backCb = null;
            }
            return;
        }
        if (backCb != null) {
            // 已注册的回调在窗口焦点变化时仍然有效。不要为“刷新”而注销/重注册：
            // Android 16/17 可能正处于系统手势识别窗口，重新注册会丢失跟手进度事件。
            return;
        }
        backCb = new OnBackAnimationCallback() {
            /** onBackStarted 没派发或没来得及执行时，第一帧进度也能把现场摆好。 */
            private boolean begin() {
                if (predicting) return true;
                List<Page> st = stacks.get(tab);
                if (st.size() < 2) return false;
                prepare(st.get(st.size() - 1).view, st.get(st.size() - 2).view, 1f);
                predicting = true;
                return true;
            }

            @Override
            public void onBackStarted(BackEvent e) {
                bkStart++;
                bkStartX = e.getTouchX();
                bkEdge = e.getSwipeEdge();
                begin();
                refreshBk();
            }

            @Override
            public void onBackProgressed(BackEvent e) {
                bkProg++;
                bkLastX = e.getTouchX();
                float dx = Math.abs(bkLastX - bkStartX);
                bkMax = Math.max(bkMax, e.getProgress());
                bkDx = Math.max(bkDx, dx);
                // 这台机器的系统手势进度恒为 0，只能用手指位移自己算：页面跟着手指走
                if (begin()) setP(1f - Math.min(1f, Math.max(e.getProgress(), dx / tw)));
                refreshBk();
            }

            @Override
            public void onBackCancelled() {
                bkCancel++;
                refreshBk();
                if (!predicting) return;
                predicting = false;
                final View under = tUnder;
                animateTo(1f, IN, EASE_OUT, () -> under.setVisibility(View.GONE));
            }

            @Override
            public void onBackInvoked() {
                bkInvoke++;
                refreshBk();
                dragging = predicting;   // 手势进行中：从当前位置接着滑出；三键导航直接走普通返回
                predicting = false;
                List<Page> st = stacks.get(tab);
                if (st.size() > 1) popTo(st.size() - 1);
                dragging = false;
            }
        };
        disp.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCb);
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncBack(true);   // 每次回到前台重新注册一次，确保手势返回一直有效
        Toggle imm = live.get("immersion");   // 抖音里双击退出后，广播已经把这个开关关了：回来时界面跟上
        if (imm != null) imm.set(cfg.getBoolean("immersion", false));
    }

    @Override
    public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) syncBack(true);
    }

    @Override
    public void onBackPressed() {
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 备份 / 恢复 ----------
    private static final String[] EXTRA_KEYS = {"dark", "nav_transparent", "extend_feed", "center_tabs", "dump", "pendant_scale", "fit_video", "back_swipe"};

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void exportBackup() {
        String name = "DyHide_backup_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".json";
        startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT);
    }

    private void importBackup() {
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT);
    }

    private Set<String> knownKeys() {
        Set<String> k = new HashSet<>(Arrays.asList(EXTRA_KEYS));
        for (Rules.R r : Rules.ALL) k.add(r.key());
        return k;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_EXPORT) {
                JSONObject prefs = new JSONObject();   // 导出当前生效的全部值（没改过的取默认值），恢复时才是完整还原
                for (Rules.R r : Rules.ALL) prefs.put(r.key(), cfg.getBoolean(r.key(), true));
                for (String k : EXTRA_KEYS) {
                    if (k.equals("pendant_scale")) prefs.put(k, Math.round(cfg.getFloat(k, 1f) * 100f) / 100.0);
                    else prefs.put(k, cfg.getBoolean(k, !k.equals("dark")));
                }
                JSONObject root = new JSONObject().put("app", "DyHide").put("version", VOL).put("prefs", prefs);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("已导出 " + prefs.length() + " 项设置");
            } else if (req == REQ_IMPORT) {
                String text;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    for (int n; (n = in.read(buf)) > 0; ) b.write(buf, 0, n);
                    text = new String(b.toByteArray(), StandardCharsets.UTF_8);
                }
                JSONObject p = new JSONObject(text).getJSONObject("prefs");
                Set<String> known = knownKeys();
                SharedPreferences.Editor ed = cfg.edit();
                int n = 0;
                for (Iterator<String> it = p.keys(); it.hasNext(); ) {   // 只在这里校验一次：未知项、类型不对的一律跳过
                    String k = it.next();
                    Object v = p.get(k);
                    if (!known.contains(k)) continue;
                    if (k.equals("pendant_scale") && v instanceof Number) {
                        ed.putFloat(k, Math.max(0.5f, Math.min(1.5f, ((Number) v).floatValue())));
                    } else if (v instanceof Boolean) {
                        ed.putBoolean(k, (Boolean) v);
                    } else {
                        continue;
                    }
                    n++;
                }
                ed.apply();
                palette(cfg.getBoolean("dark", false));
                build();
                toast("已恢复 " + n + " 项设置");
            }
        } catch (Exception e) {
            toast((req == REQ_EXPORT ? "导出失败：" : "恢复失败：") + e.getMessage());
        }
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", "选择要从信息流里抹去的元素。改动立即在抖音生效，无需重启。", path, col -> {
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            int n = 0;
            col.addView(hair(), hairLp(32, 0));
            for (final String g : groups) {
                col.addView(magRow(++n, g, summary(g, null), () -> push(groupPage(g))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, "逐项开关，改动立即生效。", path, col -> {
            int k = 0;
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) addGroup(col, single(switchRow(r.label, r.key(), true)), k++ == 0 ? 32 : 12);
            }
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            int n = 0;
            if (!subs.isEmpty() && !g.equals("商城") || g.equals("主页")) col.addView(hair(), hairLp(40, 0));
            for (final String s : subs) {
                if (g.equals("商城")) {   // 商品分类直接放在商城页上，不再单独一个页面
                    fillSub(col, g, s);
                    continue;
                }
                col.addView(magRow(++n, s, summary(g, s), () -> push(subPage(g, s))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
            if (g.equals("主页")) {   // 敬请期待
                col.addView(magRow(++n, "敬请期待", text("即将开放", 13, SUB, false), () -> push(soonPage(g))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page soonPage(String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, "敬请期待"));
        return page("敬请期待", "", "", path, col -> col.addView(text("不要一臉期待的進來嘛この変態", 16, INK, false), lp(0, 24, 0, 0)));
    }

    private Page subPage(final String g, final String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, "逐项开关，改动立即生效。", path, col -> fillSub(col, g, s));
    }

    /** 一个子分组的全部开关（条目多时顶部带一键全部隐藏/恢复）。商城页直接内联用它，其他分组放在二级页面里。 */
    private void fillSub(LinearLayout col, final String g, final String s) {
            int n = 0, on = 0, longest = 0;
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) { n++; longest = Math.max(longest, r.shown().length()); if (cfg.getBoolean(r.key(), true)) on++; }
            }
            int k = 0;
            if (n >= 8) {   // 条目多的子页（商城页直接用它）：顶部一键全部隐藏 / 全部恢复；按下后 50ms，下面所有开关一起播放切换动画
                final int total = n;
                final View[] bulk = new View[1];
                bulk[0] = actionRow(on == n ? "一键全部恢复显示" : "一键全部隐藏", on == n ? "关闭本页全部 " + n + " 项" : "开启本页全部 " + n + " 项", () -> {
                    int now = 0;
                    for (Rules.R r : Rules.ALL) if (g.equals(r.group) && s.equals(r.sub) && cfg.getBoolean(r.key(), true)) now++;
                    final boolean to = now != total;   // 现在全开 → 全部关；否则全部开
                    SharedPreferences.Editor ed = cfg.edit();
                    for (Rules.R r : Rules.ALL) if (g.equals(r.group) && s.equals(r.sub)) ed.putBoolean(r.key(), to);
                    ed.apply();
                    refreshAll();
                    LinearLayout mid = (LinearLayout) ((ViewGroup) bulk[0]).getChildAt(0);   // Press → 行 → 标题/说明
                    mid = (LinearLayout) mid.getChildAt(0);
                    ((TextView) mid.getChildAt(0)).setText(to ? "一键全部恢复显示" : "一键全部隐藏");
                    ((TextView) mid.getChildAt(1)).setText(to ? "关闭本页全部 " + total + " 项" : "开启本页全部 " + total + " 项");
                    content.postDelayed(() -> {
                        for (Rules.R r : Rules.ALL) {
                            Toggle t = live.get(r.key());
                            if (g.equals(r.group) && s.equals(r.sub) && t != null) t.set(to);
                        }
                    }, 50);
                });
                addGroup(col, single(bulk[0]), 32);
                k = 1;
            }
            LinearLayout pair = null;
            for (Rules.R r : Rules.ALL) {
                if (!g.equals(r.group) || !s.equals(r.sub)) continue;
                if (longest > 5) {   // 名字长：一行一张卡片
                    addGroup(col, single(switchRow(r.shown(), r.key(), true)), k++ == 0 ? 32 : 12);
                    continue;
                }
                if (pair == null || pair.getChildCount() == 2) {   // 名字短（如商品分类）：两列网格
                    pair = new LinearLayout(this);
                    addGroup(col, pair, k == 0 ? 32 : 12);
                    k = 1;
                }
                LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(0, -2, 1f);
                if (pair.getChildCount() == 1) cell.leftMargin = dp(12);
                pair.addView(single(switchRow(r.shown(), r.key(), true, true)), cell);
            }
            if (pair != null && pair.getChildCount() == 1) pair.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
    }

    /** 关于：项目作者、Claude 与 ChatGPT AI 助手卡片 + 版本信息。 */
    private Page aboutPage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置", "关于"));
        return page("关于", "关于", "项目作者与 AI 助手。", path, col -> {
            addGroup(col, single(devRow(R.drawable.dev_user, "用户8176973514541", "查看酷安主页 →", "https://www.coolapk.com/u/39895877")), 32);
            addGroup(col, single(devRow(R.drawable.dev_claude, "Claude", "AI 助手", null)), 12);
            addGroup(col, single(devRow(R.drawable.dev_chatgpt, "ChatGPT", "AI 助手", null)), 12);
            LinearLayout info = cardBody();
            info.addView(valueRow("版本号", num(VOL)));
            info.addView(valueRow("发布日期", num("2026年11月26日")));
            info.addView(actionRow("GitHub", "https://github.com/bardenjohn383-rgb/-Hide", () -> open("https://github.com/bardenjohn383-rgb/-Hide")));
            addGroup(col, wrapCard(info), 40);
            col.addView(text("本软件完全免费，仅发布于上方的酷安主页和GitHub，禁止任何形式的二次打包、收费与倒卖。如果你是花钱买到的，说明你被骗了；本软件只从上方两个地址获取更新。", 13, SUB, false), lp(0, 20, 0, 0));
        });
    }

    /** 一位开发者：圆角头像 + 名字；link 不为 null 时整行可点，打开 url。 */
    private View devRow(int avatar, String name, String link, final String url) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        ImageView av = new ImageView(this);
        av.setImageResource(avatar);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), v.getWidth() * 0.28f);
            }
        });
        av.setClipToOutline(true);
        row.addView(av, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(text(name, 17, INK, false));
        if (link != null) mid.addView(text(link, 13, ACCENT, false), lp(0, 4, 0, 0));
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, -2, 1f);
        ml.leftMargin = dp(16);
        row.addView(mid, ml);
        return url == null ? row : new Press(this, row, -1, () -> open(url));
    }

    private void open(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", "主题、底栏与红包挂件，克制地调整。", path, col -> {
            LinearLayout theme = cardBody();
            theme.addView(darkRow());
            addGroup(col, wrapCard(theme), 32);
            LinearLayout bs = cardBody();
            bs.addView(switchRow("二级页面整页向右滑返回", "back_swipe", true));
            addGroup(col, wrapCard(bs), 40);
            col.addView(text("打开：在二级页面里向右滑动整页就能返回，页面跟手滑出，不用从边缘起滑。关闭：使用系统返回手势。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout a = cardBody();
            a.addView(switchRow("底栏背景全透明", "nav_transparent", true));
            a.addView(switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 40);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
            LinearLayout fit = cardBody();
            fit.addView(switchRow("视频防裁切", "fit_video", false));
            addGroup(col, wrapCard(fit), 40);
            col.addView(text("防止抖音铺满屏幕后裁掉视频左右两侧。此功能强制显示 9:16 视频完整内容，上下留有黑边，仅对 9:16 视频生效。", 13, SUB, false), lp(0, 12, 0, 0));
            final LinearLayout imm = cardBody();
            imm.addView(switchRow("沉浸模式", "immersion", false));
            final LinearLayout quick = new LinearLayout(this);   // 展开后才显示的“自定义快捷开关”
            quick.setOrientation(LinearLayout.VERTICAL);
            quick.setVisibility(View.GONE);
            quick.addView(switchRow("双击视频开启与关闭", "imm_dtap", false));
            quick.addView(switchRow("内置在抖音的长按菜单里", "imm_menu", false));
            imm.addView(quick);
            final TextView arrow = text("▾", 18, SUB, false);
            LinearLayout strip = new LinearLayout(this);   // 卡片底部整条：空白处 + 右下角的箭头，点哪里都展开（开关本身除外）
            strip.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            strip.setPadding(dp(20), dp(2), dp(20), dp(8));
            strip.addView(arrow);
            final boolean[] open = {false};
            final Runnable toggle = () -> {
                open[0] = !open[0];
                int w = imm.getWidth() > 0 ? imm.getWidth() : getResources().getDisplayMetrics().widthPixels - dp(40);
                quick.setVisibility(View.VISIBLE);   // 先可见才能量出展开后的高度
                quick.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                final int full = quick.getMeasuredHeight();
                ValueAnimator va = ValueAnimator.ofInt(quick.getHeight(), open[0] ? full : 0);
                va.setDuration(260);
                va.setInterpolator(new DecelerateInterpolator());
                va.addUpdateListener(a -> {
                    ViewGroup.LayoutParams lp = quick.getLayoutParams();
                    lp.height = (Integer) a.getAnimatedValue();
                    quick.setLayoutParams(lp);
                    quick.setAlpha(full == 0 ? 1f : lp.height / (float) full);
                });
                va.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator an) {
                        ViewGroup.LayoutParams lp = quick.getLayoutParams();
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                        quick.setLayoutParams(lp);
                        if (!open[0]) quick.setVisibility(View.GONE);
                    }
                });
                va.start();
                arrow.animate().rotation(open[0] ? 180f : 0f).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
            };
            imm.addView(new Press(this, strip, -1, toggle));
            addGroup(col, wrapCard(imm), 40);
            TextView desc = text("开启沉浸模式后，隐藏所有界面和状态栏；启用双击开关将屏蔽双击点赞功能；视频长按菜单后显示快捷开关。", 13, SUB, false);
            col.addView(new Press(this, desc, -1, toggle), lp(0, 12, 0, 0));   // 说明文字也能点开
            addGroup(col, pendantCard(), 40);
            col.addView(text("红包挂件可在0.5x-1.5x之间调节，修改后立即生效；已移除挂件拖动限制，拖动即可放到屏幕内任意位置。「恢复默认」会同时还原大小和位置。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置"));
        return page("设置", "设置", "备份、统计与调试。", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            a.addView(valueRow("规则总数", total));
            a.addView(valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 32);
            LinearLayout bk = cardBody();
            bk.addView(actionRow("导出备份", "把全部开关、主题和挂件大小存成一个 JSON 文件", this::exportBackup));
            bk.addView(actionRow("恢复备份", "从备份文件还原，覆盖当前设置", this::importBackup));
            addGroup(col, wrapCard(bk), 40);
            LinearLayout nm = cardBody();
            LinearLayout nmRow = new LinearLayout(this);
            nmRow.setOrientation(LinearLayout.VERTICAL);
            nmRow.setPadding(dp(20), dp(16), dp(20), dp(16));
            nmRow.addView(text("我的昵称", 16, INK, false));
            final EditText nameBox = new EditText(this);
            nameBox.setSingleLine();
            nameBox.setText(cfg.getString("my_name", ""));
            nameBox.setHint("填你自己的抖音昵称");
            nameBox.setHintTextColor(SUB);
            nameBox.setTextColor(INK);
            nameBox.setTextSize(15);
            nameBox.setBackground(null);
            nameBox.setPadding(0, dp(8), 0, 0);
            nameBox.setOnFocusChangeListener((fv, focused) -> {   // 输入法展开、页面让出高度之后，把输入框滚到可见位置（键盘起落有先后，多校正几次）
                if (!focused) return;
                for (int d : new int[]{120, 300, 550, 850}) fv.postDelayed(this::scrollInputIntoView, d);
            });
            nameBox.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) {}

                @Override public void onTextChanged(CharSequence c, int a, int b, int d) {}

                @Override
                public void afterTextChanged(Editable e) { cfg.edit().putString("my_name", e.toString().trim()).apply(); }
            });
            nmRow.addView(nameBox, new LinearLayout.LayoutParams(-1, -2));
            nm.addView(nmRow);
            addGroup(col, wrapCard(nm), 40);
            col.addView(text("视频底部「好友推荐过的视频」标签里如果是你自己（昵称一致），就不隐藏，只隐藏别人的；留空则全部隐藏。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("调试：导出控件树和状态文件", "dump", false));
            bkView = text("", 13, SUB, false);
            bkView.setPadding(dp(20), dp(8), dp(20), dp(16));
            bkView.setOnLongClickListener(v -> {
                ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("返回手势事件", bkView.getText().toString().replace("（长按复制）", "")));
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
                return true;
            });
            FrameLayout bkRow = new FrameLayout(this);   // wrapCard 要求每一行是 ViewGroup、内容在它的第一个子视图
            bkRow.addView(bkView);
            b.addView(bkRow);
            refreshBk();
            addGroup(col, wrapCard(b), 40);
            addGroup(col, single(actionRow("关于", "开发者、版本号与项目主页", () -> push(aboutPage()))), 40);
            col.addView(text("viewdump_*.txt 直接保存在 内部存储/Download；dyhide_status.txt 仍在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    /** 杂志内页：报头（品牌/卷期 + 发丝线）→ 短色条 → 衬线大标题 → 斜体导语 → 正文 → 版权页脚。 */
    private Page page(String crumb, String title, String deck, final List<String> path, Fill fill) {
        final PullScroll sv = new PullScroll(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);   // 回弹由 PullScroll 自己做
        sv.setBackground(new Paper(density));
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(28), dp(16), dp(28), dp(150));   // 底部留出浮动底栏的位置
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        sv.col = col;

        LinearLayout mast = new LinearLayout(this);
        mast.setGravity(Gravity.CENTER_VERTICAL);
        mast.setMinimumHeight(dp(44));
        if (path.size() >= 2) {   // 二级及以下页面：左上角返回键
            LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(-2, -2);
            back.leftMargin = -dp(10);
            mast.addView(new Press(this, new Arrow(this, density), -2, () -> popTo(path.size() - 1)), back);
        } else {
            TextView brand = text("DYHIDE", 12, INK, true);
            brand.setLetterSpacing(0.32f);
            mast.addView(brand);
        }
        mast.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView vol = text("VOL. " + VOL + "  ·  " + TAB_EN[tab], 11, SUB, false);
        vol.setLetterSpacing(0.18f);
        mast.addView(vol);
        col.addView(mast, lp(0, 0, 0, 0));
        col.addView(hair(), hairLp(0, 0));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 12, 0, 0));

        View bar = new View(this);
        bar.setBackgroundColor(ACCENT);
        LinearLayout deco = new LinearLayout(this);
        deco.setGravity(Gravity.CENTER_VERTICAL);
        deco.addView(bar, new LinearLayout.LayoutParams(dp(28), dp(3)));
        deco.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        deco.addView(new Barcode(this, density));
        col.addView(deco, lp(0, 40, 0, 16));
        TextView head = text(title, 44, INK, true);
        head.setTypeface(Typeface.create("serif", Typeface.BOLD));
        head.setLineSpacing(0, 1.0f);
        head.setVisibility(title.isEmpty() ? View.GONE : View.VISIBLE);
        col.addView(head, lp(0, 0, 0, 0));
        TextView dk = text(deck, 15, SUB, false);
        dk.setTypeface(Typeface.create("serif", Typeface.ITALIC));
        dk.setLineSpacing(0, 1.25f);
        dk.setVisibility(deck.isEmpty() ? View.GONE : View.VISIBLE);
        col.addView(dk, lp(0, 12, 24, 0));

        fill.fill(col);
        col.addView(colophon("关于".equals(crumb)), lp(0, 48, 0, 0));

        return new Page(sv, crumb);
    }

    /** 页脚；彩蛋只留在「关于」页。 */
    private View colophon(boolean egg) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        if (egg) c.addView(new Egg(this, density, sparks, () -> toast("✦ 彩蛋：愿你的信息流，只剩想看的。")), new LinearLayout.LayoutParams(-1, -2));
        c.addView(hair(), hairLp(0, 16));
        TextView t = text("DYHIDE  ·  抖音UI隐藏  ·  FIN", 11, SUB, false);
        t.setLetterSpacing(0.2f);
        c.addView(t);
        TextView free = text("开源软件 · 禁止倒卖 · 仅酷安 / GitHub 发布", 11, SUB, false);
        c.addView(free, lp(0, 6, 0, 0));
        return c;
    }

    private View hair() {
        View v = new View(this);
        v.setBackgroundColor(HAIR);
        return v;
    }

    private LinearLayout.LayoutParams hairLp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.5f)));
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (last) {
                row.addView(c);
            } else {
                c.setPadding(0, dp(8), 0, dp(8));
                row.addView(new Press(this, c, -2, () -> popTo(idx + 1)));
                row.addView(text("  ›  ", 14, SUB, false));
            }
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------
    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    /** 目录式入口：斜体衬线大号序号 + 衬线标题 + 摘要。整行可点。 */
    private View magRow(int n, String name, TextView sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(20), 0, dp(20));
        TextView num = text(String.format(Locale.US, "%02d", n), 40, ACCENT, true);
        num.setTypeface(Typeface.create("serif", Typeface.BOLD_ITALIC));
        num.setAlpha(0.5f);
        row.addView(num, new LinearLayout.LayoutParams(dp(68), -2));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(name, 24, INK, true);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        mid.addView(title);
        mid.addView(sub, lp(0, 4, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 22, SUB, false));
        return new Press(this, row, -1, go);
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        FrameLayout f = new FrameLayout(this);
        f.addView(row);
        return f;
    }

    private View switchRow(String label, final String key, boolean def) {
        return switchRow(label, key, def, false);
    }

    /** compact：用于两列网格里的窄卡片（边距 14dp、字号 15）。 */
    private final Map<String, Toggle> live = new java.util.HashMap<>();   // 当前页面上各开关（按键名），一键隐藏时用来播放切换动画

    private View switchRow(String label, final String key, boolean def, boolean compact) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(compact ? 14 : 20), dp(8), dp(compact ? 14 : 20), dp(8));
        TextView name = text(label, compact ? 15 : 16, INK, false);
        if (compact) name.setSingleLine(true);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, cfg.getBoolean(key, def), density);
        live.put(key, sw);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            sw.set(!sw.checked);
            SharedPreferences.Editor ed = cfg.edit().putBoolean(key, sw.checked);
            if (key.equals("immersion")) ed.putLong("immersion_ts", System.currentTimeMillis());   // 抖音那边的双击/菜单切换也带时间戳，谁新听谁的
            ed.apply();
            refreshAll();
        });
    }

    /** 点一下执行动作的行：标题 + 说明 + 箭头。 */
    private View actionRow(String label, String hint, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(text(label, 16, INK, false));
        mid.addView(text(hint, 13, SUB, false), lp(0, 2, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 20, SUB, false));
        return new Press(this, row, -1, go);
    }

    private static String fmtScale(float x) {
        return String.format(Locale.US, "%.2f×", x);
    }

    /** 红包挂件大小：一行标题 + 当前倍数，点一下展开滑杆（0.5×–1.5×，默认 1.0×）和“恢复默认”，再点收起。 */
    private View pendantCard() {
        final float min = 0.5f, max = 1.5f;
        float init = cfg.getFloat("pendant_scale", 1f);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(20), dp(8), dp(20), dp(16));
        head.addView(text("红包挂件大小", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = num(fmtScale(init));
        val.setTextColor(ACCENT);
        head.addView(val);
        final TextView chev = text("▾", 16, SUB, false);
        head.addView(chev, new LinearLayout.LayoutParams(-2, -2));
        ((LinearLayout.LayoutParams) chev.getLayoutParams()).leftMargin = dp(12);

        final Slider sl = new Slider(this, density, (init - min) / (max - min), new String[]{"0.5×", "1.0×", "1.5×"}, (v, done) -> {
            float x = Math.round((min + v * (max - min)) * 100f) / 100f;
            val.setText(fmtScale(x));
            cfg.edit().putFloat("pendant_scale", x).apply();   // 拖动过程中就写入，抖音下一次扫描就套用
        });
        FrameLayout sliderBox = new FrameLayout(this);
        sliderBox.setPadding(dp(20), 0, dp(20), 0);
        sliderBox.addView(sl, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.addView(sliderBox, new LinearLayout.LayoutParams(-1, -2));
        inner.addView(actionRow("恢复默认", "1.0×，位置回到抖音原处", () -> {
            cfg.edit().putFloat("pendant_scale", 1f).putLong("pendant_reset", System.currentTimeMillis()).apply();
            sl.set(0.5f);
            val.setText(fmtScale(1f));
        }));
        final FrameLayout panel = new FrameLayout(this);
        panel.addView(inner);
        panel.setVisibility(View.GONE);

        LinearLayout body = cardBody();
        body.addView(new Press(this, head, -1, () -> {
            final boolean open = panel.getVisibility() != View.VISIBLE;
            panel.measure(View.MeasureSpec.makeMeasureSpec(content.getWidth() - dp(56), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int full = panel.getMeasuredHeight(), from = open ? 0 : panel.getHeight();
            final ViewGroup.LayoutParams lp = panel.getLayoutParams();
            lp.height = from;
            panel.setVisibility(View.VISIBLE);
            ValueAnimator a = ValueAnimator.ofInt(from, open ? full : 0);
            a.setDuration(240);
            a.setInterpolator(new DecelerateInterpolator(1.6f));
            a.addUpdateListener(v -> {
                lp.height = (int) v.getAnimatedValue();
                panel.setLayoutParams(lp);
            });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    lp.height = -2;
                    panel.setVisibility(open ? View.VISIBLE : View.GONE);
                    panel.setLayoutParams(lp);
                }
            });
            a.start();
            chev.animate().rotation(open ? 180f : 0f).setDuration(240).start();
        }));
        body.addView(panel, new LinearLayout.LayoutParams(-1, -2));
        return wrapCard(body);
    }

    /** 深色模式：点击后新主题从开关位置圆形扩散（切回时原路收回）。 */
    private View darkRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text("深色模式", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, animateDark != dark, density);
        if (animateDark) {
            animateDark = false;
            sw.post(() -> sw.set(dark));
        }
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            int[] loc = new int[2];
            sw.getLocationInWindow(loc);
            setDark(!dark, new RectF(loc[0], loc[1], loc[0] + sw.getWidth(), loc[1] + sw.getHeight()));
        });
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    /**
     * 卡片：三层柔和阴影（紧、中、宽）代替边框；内容按圆角裁剪，所以行的波纹/按压范围正好对齐卡片边缘。
     * 首行上、末行下补 16dp，行与行之间内容间距为 16dp。
     */
    private View wrapCard(LinearLayout body) {
        View first = ((ViewGroup) body.getChildAt(0)).getChildAt(0);
        first.setPadding(first.getPaddingLeft(), dp(16), first.getPaddingRight(), first.getPaddingBottom());
        View last = ((ViewGroup) body.getChildAt(body.getChildCount() - 1)).getChildAt(0);
        last.setPadding(last.getPaddingLeft(), last.getPaddingTop(), last.getPaddingRight(), dp(16));

        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x0F000000, 0x17000000);
        shadowLayer(w, 8, 0x0A000000, 0x12000000);
        shadowLayer(w, 18, 0x07000000, 0x0F000000);
        body.setElevation(dp(19));
        body.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16));
                o.setAlpha(0f);   // 只用于裁剪，不产生阴影
            }
        });
        body.setClipToOutline(true);
        body.setBackground(new CardArt(density));
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(16));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 一个选项一张卡片。 */
    private View single(View row) {
        LinearLayout b = cardBody();
        b.addView(row);
        return wrapCard(b);
    }

    /** 不同组之间 32–48dp；卡片之间 12dp。 */
    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
