package com.dyhide;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    static int BG, CARD, INK, SUB, ACCENT, OFF, HAIR;
    static boolean dark;
    static final long SLIDE = 320;   // 页面/标签切换总时长：先滑到位，再回弹
    static final String VOL = "1.9";
    static final int REQ_EXPORT = 11, REQ_IMPORT = 12;
    static final String[] TABS = {"规则", "外观", "设置"};
    static final String[] TAB_EN = {"RULES", "APPEARANCE", "SETTINGS"};

    static void palette(boolean d) {
        dark = d;
        // 哑光纸：暖灰白 / 炭黑；点缀色取酒红 / 暗金，克制不跳
        BG = d ? 0xFF141311 : 0xFFEFEBE3;
        CARD = d ? 0xFF1E1C19 : 0xFFF8F5EF;
        INK = d ? 0xFFEBE5D9 : 0xFF1C1B18;
        SUB = d ? 0xFF958D7F : 0xFF7B756B;
        ACCENT = d ? 0xFFC9A66B : 0xFF7D3A2E;
        OFF = d ? 0xFF3A3630 : 0xFFD0C9BB;
        HAIR = d ? 0x24EBE5D9 : 0x261C1B18;
    }

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    /** 可按压的容器：按下内容缩到 96%，松手时弹簧回弹（先略超过 100% 再落回）；波纹从手指按下的位置扩散。 */
    private static final class Press extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float rx, ry, radius, alpha;
        private ValueAnimator grow, fade, spring;

        Press(Context c, View content, int width, Runnable click) {
            super(c);
            setWillNotDraw(false);
            addView(content, new LayoutParams(width, -2));
            setOnClickListener(v -> click.run());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (alpha > 0f) {
                paint.setAlpha((int) (alpha * 40));
                canvas.drawCircle(rx, ry, radius, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) down(e.getX(), e.getY());
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) up();
            return super.onTouchEvent(e);
        }

        private void down(float x, float y) {
            if (fade != null) fade.cancel();
            if (spring != null) spring.cancel();
            paint.setColor(dark ? Color.WHITE : Color.BLACK);
            rx = x;
            ry = y;
            alpha = 1f;
            grow = ValueAnimator.ofFloat(0f, (float) Math.hypot(Math.max(x, getWidth() - x), Math.max(y, getHeight() - y)));
            grow.setDuration(450);
            grow.setInterpolator(new DecelerateInterpolator());
            grow.addUpdateListener(a -> { radius = (float) a.getAnimatedValue(); invalidate(); });
            grow.start();
            getChildAt(0).animate().cancel();
            getChildAt(0).animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
        }

        private void up() {
            fade = ValueAnimator.ofFloat(alpha, 0f);
            fade.setDuration(250);
            fade.addUpdateListener(a -> { alpha = (float) a.getAnimatedValue(); invalidate(); });
            fade.start();
            final View c = getChildAt(0);
            c.animate().cancel();
            final float from = c.getScaleX();
            spring = ValueAnimator.ofFloat(0f, 0.5f);   // 数值为秒；欠阻尼弹簧：x(t) = 1 - (1-from)·e^(-ζω0t)·(cos ωd·t + ζω0/ωd·sin ωd·t)
            spring.setDuration(500);
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                double w0 = 2 * Math.PI * 3.2, z = 0.42, wd = w0 * Math.sqrt(1 - z * z);
                float s = a.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t)));
                c.setScaleX(s);
                c.setScaleY(s);
            });
            spring.start();
        }
    }

    /**
     * 两段式：前 72% 时间平滑滑到位（不带回弹），到位后用剩下的时间冲出 3% 再落回（原来的回弹是 1.5%，现在大一倍）。
     * reverse 是它的逆动画（返回时用）：先反向蓄力一下，再滑出。
     */
    private static final class SlideEase implements android.animation.TimeInterpolator {
        private static final float SPLIT = 0.72f, BOUNCE = 0.03f;
        private final boolean reverse;

        SlideEase(boolean reverse) { this.reverse = reverse; }

        @Override
        public float getInterpolation(float x) {
            return reverse ? 1f - ease(1f - x) : ease(x);
        }

        private static float ease(float x) {
            if (x <= 0f) return 0f;
            if (x >= 1f) return 1f;
            if (x < SPLIT) {
                float u = x / SPLIT;
                return 1f - (1f - u) * (1f - u) * (1f - u);
            }
            double s = Math.sin(Math.PI * (x - SPLIT) / (1f - SPLIT));
            return 1f + BOUNCE * (float) (s * s);
        }
    }

    /** 半透明的纸：底色 + 柔和高光 + 极细纸纹颗粒 + 右上角渐隐的半调网点 + 底部淡淡的压暗。 */
    private static final class Paper extends Drawable {
        private final Paint fill = new Paint(), glow = new Paint(), shade = new Paint(), grain = new Paint();
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        Paper(float density) {
            d = density;
            fill.setColor(BG);
            int n = 128;
            int[] px = new int[n * n];
            Random r = new Random(7);
            int rgb = dark ? 0xFFFFFF : 0x000000;
            for (int i = 0; i < px.length; i++) {
                if (r.nextInt(100) < 38) px[i] = ((2 + r.nextInt(dark ? 9 : 11)) << 24) | rgb;
            }
            grain.setShader(new BitmapShader(Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888),
                    Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            dot.setColor(dark ? 0xFFEBE5D9 : 0xFF1C1B18);
            dot.setAlpha(dark ? 22 : 26);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float w = Math.max(1, b.width()), h = Math.max(1, b.height());
            int hi = dark ? 0x1AC9A66B : 0x80FFFFFF, hi0 = dark ? 0x00C9A66B : 0x00FFFFFF;
            glow.setShader(new RadialGradient(w * 0.9f, 0f, w * 1.1f, hi, hi0, Shader.TileMode.CLAMP));
            int lo = dark ? 0x40000000 : 0x14503A1E;
            shade.setShader(new LinearGradient(0f, h * 0.65f, 0f, h, lo & 0x00FFFFFF, lo, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, fill);
            c.drawRect(b, glow);
            c.drawRect(b, shade);
            // 半调网点：错行排布，越靠右上角越大，向内渐隐
            float sp = 10 * d, maxR = 2.6f * d, reach = b.width() * 0.95f;
            int row = 0;
            for (float y = 0; y < reach; y += sp * 0.5f, row++) {
                for (float x = (row % 2) * sp * 0.5f; x < reach; x += sp) {
                    float t = 1f - (float) Math.hypot(x, y) / reach;
                    if (t <= 0f) continue;
                    float r = maxR * t * t;
                    if (r >= 0.35f * d) c.drawCircle(b.right - x, b.top + y, r, dot);
                }
            }
            c.drawRect(b, grain);
        }

        @Override
        public void setAlpha(int a) {}

        @Override
        public void setColorFilter(ColorFilter f) {}

        @Override
        public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    private interface Change { void on(float v, boolean done); }

    /** 0..1 的滑杆：细轨道 + 空心圆钮 + 三个刻度。 */
    private static final class Slider extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final Change cb;
        private final String[] marks;
        private float v;

        Slider(Context c, float density, float v, String[] marks, Change cb) {
            super(c);
            d = density;
            this.v = v;
            this.marks = marks;
            this.cb = cb;
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setTextSize(11 * d);
        }

        void set(float x) {
            v = x;
            invalidate();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(60 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float pad = 12 * d, cy = 22 * d, x0 = pad, x1 = getWidth() - pad, x = x0 + (x1 - x0) * v;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * d);
            p.setColor(OFF);
            c.drawLine(x0, cy, x1, cy, p);
            p.setColor(ACCENT);
            c.drawLine(x0, cy, x, cy, p);
            p.setStrokeWidth(1 * d);
            p.setColor(SUB);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f;
                c.drawLine(tx, cy + 14 * d, tx, cy + 19 * d, p);
            }
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                float tx = x0 + (x1 - x0) * i / 2f, w = p.measureText(marks[i]);
                c.drawText(marks[i], i == 0 ? tx - 4 * d : i == 1 ? tx - w / 2f : tx - w + 4 * d, cy + 36 * d, p);
            }
            p.setColor(CARD);
            c.drawCircle(x, cy, 10 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(ACCENT);
            c.drawCircle(x, cy, 10 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) getParent().requestDisallowInterceptTouchEvent(true);
            float pad = 12 * d;
            v = Math.max(0f, Math.min(1f, (e.getX() - pad) / Math.max(1f, getWidth() - 2 * pad)));
            invalidate();
            cb.on(v, a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL);
            return true;
        }
    }

    /** 返回箭头图标。 */
    private static final class Arrow extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        Arrow(Context c, float density) {
            super(c);
            d = density;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(2.2f * d);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(44 * d), Math.round(44 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, s = 9 * d;
            paint.setColor(INK);
            c.drawLine(cx - s, cy, cx + s, cy, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy - s * 0.65f, paint);
            c.drawLine(cx - s, cy, cx - s * 0.35f, cy + s * 0.65f, paint);
        }
    }

    /** 开关：起步时前沿先走、横向拉长成胶囊；后沿滞后跟上，落位时压回原宽（略压窄再回弹），不像一张贴纸。 */
    private static final class Toggle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        boolean checked;
        private float l, r, cp;   // 圆点左右边缘(px)、轨道颜色进度
        private ValueAnimator anim;

        Toggle(Context c, boolean on, float density) {
            super(c);
            d = density;
            checked = on;
            l = (on ? 24f : 4f) * d;
            r = l + 24 * d;
            cp = on ? 1f : 0f;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(52 * d), Math.round(32 * d));
        }

        void set(boolean on) {
            checked = on;
            if (anim != null) anim.cancel();
            final float l0 = l, r0 = r, l1 = (on ? 24f : 4f) * d, r1 = l1 + 24 * d, c0 = cp, c1 = on ? 1f : 0f;
            final boolean right = l1 > l0;
            final OvershootInterpolator squash = new OvershootInterpolator(2.2f);
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(460);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                float t = a.getAnimatedFraction();
                float x = Math.min(1f, t / 0.7f);
                float lead = 1f - (1f - x) * (1f - x) * (1f - x);
                float trail = squash.getInterpolation(Math.max(0f, (t - 0.15f) / 0.85f));
                l = l0 + (l1 - l0) * (right ? trail : lead);
                r = r0 + (r1 - r0) * (right ? lead : trail);
                cp = c0 + (c1 - c0) * lead;
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            paint.setColor((Integer) new ArgbEvaluator().evaluate(Math.max(0f, Math.min(1f, cp)), OFF, ACCENT));
            rect.set(0, 0, getWidth(), h);
            c.drawRoundRect(rect, h / 2, h / 2, paint);
            paint.setColor(Color.WHITE);
            rect.set(l, 4 * d, r, h - 4 * d);
            c.drawRoundRect(rect, 12 * d, 12 * d, paint);
        }
    }

    /** 底部导航：背景块滑到选中项；选中项展开显示文字，其余只保留图标。 */
    private static final class NavBar extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        private final IntConsumer onSelect;
        private final float[] left = new float[3], wid = new float[3];
        private float pos;
        private ValueAnimator anim;

        NavBar(Context c, float density, IntConsumer onSelect) {
            super(c);
            d = density;
            this.onSelect = onSelect;
            setBackgroundColor(CARD);
            setElevation(6 * d);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setTextSize(14 * d);
            paint.setFakeBoldText(true);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(64 * d) + getPaddingBottom());
        }

        void select(int i, boolean animate) {
            if (anim != null) anim.cancel();
            if (!animate) {
                pos = i;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(pos, i);
            anim.setDuration(SLIDE);
            anim.setInterpolator(new SlideEase(false));
            anim.addUpdateListener(a -> { pos = (float) a.getAnimatedValue(); invalidate(); });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(HAIR);
            c.drawRect(0, 0, getWidth(), Math.max(1f, 0.5f * d), paint);
            float small = 56 * d, big = 132 * d, cy = 32 * d, x = (getWidth() - (2 * small + big)) / 2f;
            for (int i = 0; i < 3; i++) {
                wid[i] = small + (big - small) * Math.max(0f, 1f - Math.abs(pos - i));
                left[i] = x;
                x += wid[i];
            }
            float p = Math.max(0f, Math.min(2f, pos));
            int i0 = Math.min(1, (int) p);
            float f = p - i0;
            float pl = left[i0] + (left[i0 + 1] - left[i0]) * f, pw = wid[i0] + (wid[i0 + 1] - wid[i0]) * f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ACCENT);
            paint.setAlpha(dark ? 56 : 36);
            rect.set(pl, cy - 22 * d, pl + pw, cy + 22 * d);
            c.drawRoundRect(rect, 22 * d, 22 * d, paint);
            for (int i = 0; i < 3; i++) {
                float w = Math.max(0f, 1f - Math.abs(pos - i));
                int col = (Integer) new ArgbEvaluator().evaluate(w, SUB, ACCENT);
                float gap = 8 * d * w, group = 22 * d + gap + paint.measureText(TABS[i]) * w;
                float gx = left[i] + (wid[i] - group) / 2f;
                icon(c, i, gx + 11 * d, cy, col);
                if (w > 0.05f) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    paint.setAlpha((int) (255 * w));
                    c.save();
                    c.clipRect(left[i], 0, left[i] + wid[i], getHeight());
                    c.drawText(TABS[i], gx + 22 * d + gap, cy + 5 * d, paint);
                    c.restore();
                }
            }
        }

        private void icon(Canvas c, int i, float cx, float cy, int col) {
            float s = 11 * d;
            paint.setColor(col);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * d);
            if (i == 0) {
                for (int k = -1; k <= 1; k++) c.drawLine(cx - s, cy + k * 6 * d, cx + s * (k == 0 ? 0.5f : 1f), cy + k * 6 * d, paint);
            } else if (i == 1) {
                c.drawCircle(cx, cy, s, paint);
                paint.setStyle(Paint.Style.FILL);
                rect.set(cx - s, cy - s, cx + s, cy + s);
                c.drawArc(rect, 90, 180, true, paint);
            } else {
                c.drawCircle(cx, cy, s * 0.45f, paint);
                for (int k = 0; k < 8; k++) {
                    float cos = (float) Math.cos(k * Math.PI / 4), sin = (float) Math.sin(k * Math.PI / 4);
                    c.drawLine(cx + cos * s * 0.75f, cy + sin * s * 0.75f, cx + cos * s, cy + sin * s, paint);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                for (int i = 0; i < 3; i++) if (e.getX() >= left[i] && e.getX() < left[i] + wid[i]) onSelect.accept(i);
            }
            return true;
        }
    }

    /** 深色模式切换：新主题从开关位置圆形扩散；切回时原路收回。叠加层是切换前的截图，开关处按胶囊形状抠空，露出实时的开关。 */
    private static final class Reveal extends View {
        private final Bitmap old;
        private final Path path = new Path();
        private final Paint erase = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF hole;
        private final float cx, cy, max;
        private final boolean expand;
        private float radius;

        Reveal(Context c, Bitmap old, RectF hole, boolean expand) {
            super(c);
            this.old = old;
            this.hole = hole;
            cx = hole.centerX();
            cy = hole.centerY();
            this.expand = expand;
            max = (float) Math.hypot(Math.max(cx, old.getWidth() - cx), Math.max(cy, old.getHeight() - cy));
            radius = expand ? 0f : max;
            erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        }

        void start() {
            ValueAnimator a = expand ? ValueAnimator.ofFloat(0f, max) : ValueAnimator.ofFloat(max, 0f);
            a.setDuration(560);
            a.setInterpolator(new AccelerateDecelerateInterpolator());
            a.addUpdateListener(v -> { radius = (float) v.getAnimatedValue(); invalidate(); });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    ((ViewGroup) getParent()).removeView(Reveal.this);
                    old.recycle();
                }
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            path.reset();
            path.addCircle(cx, cy, radius, Path.Direction.CW);
            int layer = c.saveLayer(0f, 0f, (float) getWidth(), (float) getHeight(), null);
            c.save();
            if (expand) c.clipOutPath(path);   // 圆内露出新主题（实时界面），圆外仍是旧截图
            else c.clipPath(path);             // 圆内是旧主题截图，随圆缩小被新主题取代
            c.drawBitmap(old, 0, 0, null);
            c.restore();
            // 开关本体：按胶囊抠空（带抗锯齿），边缘不再出现矩形的新旧主题接缝
            c.drawRoundRect(hole, hole.height() / 2f, hole.height() / 2f, erase);
            c.restoreToCount(layer);
        }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private NavBar nav;
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;
    private boolean animateDark;   // 重建后的深色开关从旧状态起步，播放一次切换动画

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences("config", MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences("config", MODE_PRIVATE);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = prefs();
        density = getResources().getDisplayMetrics().density;
        palette(cfg.getBoolean("dark", false));
        build();
    }

    /** 按当前调色板重建整个界面（首次启动和切换深浅色时调用），回到当前标签的首页。 */
    private void build() {
        stacks.clear();
        refreshers.clear();
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = new NavBar(this, density, this::switchTab);
        if (Build.VERSION.SDK_INT >= 28) {
            nav.setOutlineAmbientShadowColor(0x12000000);
            nav.setOutlineSpotShadowColor(0x1A000000);
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, 0);
            nav.setPadding(0, 0, 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        Page p = rootPage(tab);
        stacks.get(tab).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        nav.select(tab, false);
    }

    private void setDark(final boolean on, final RectF hole) {
        final View decor = getWindow().getDecorView();
        final Bitmap old = Bitmap.createBitmap(decor.getWidth(), decor.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.request(getWindow(), old, res -> {
            cfg.edit().putBoolean("dark", on).apply();
            palette(on);
            animateDark = true;
            build();
            if (res == PixelCopy.SUCCESS) {
                Reveal ov = new Reveal(this, old, hole, on);
                ((ViewGroup) decor).addView(ov, new FrameLayout.LayoutParams(-1, -1));
                ov.start();
            }
        }, new Handler(Looper.getMainLooper()));
    }

    // ---------- 导航：页面右侧滑入/反向滑出，底部标签同样处理；先滑到位再回弹，总时长 320ms ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void park(View v) {
        v.setVisibility(View.GONE);
        v.setTranslationX(0);
        v.setAlpha(1f);
    }

    private void push(final Page p) {
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        final float w = content.getWidth();
        p.view.setTranslationX(w);
        p.view.animate().translationX(0).setDuration(SLIDE).setInterpolator(new SlideEase(false)).start();
        old.view.animate().cancel();
        old.view.animate().translationX(-w * 0.25f).alpha(0.6f).setDuration(SLIDE)
                .setInterpolator(new SlideEase(false))
                .withEndAction(() -> park(old.view)).start();
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。动画不阻塞点击：返回过程中可以立刻进入别的页面。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (st.size() <= keep) return;
        final float w = content.getWidth();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        target.view.animate().cancel();
        target.view.setVisibility(View.VISIBLE);
        target.view.setTranslationX(-w * 0.25f);
        target.view.setAlpha(0.6f);
        target.view.animate().translationX(0).alpha(1f).setDuration(SLIDE)
                .setInterpolator(new SlideEase(true)).start();
        topPage.view.animate().translationX(w).setDuration(SLIDE)
                .setInterpolator(new SlideEase(true))
                .withEndAction(() -> content.removeView(topPage.view)).start();
    }

    /** 底栏切换：往右边的标签 = 新页从右滑入（同“进入二级页”）；往左边的标签 = 当前页向右滑出（同“返回”）。 */
    private void switchTab(int to) {
        if (to == tab) return;
        final boolean forward = to > tab;
        final View from = top(tab).view;
        tab = to;
        nav.select(to, true);
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        final float w = content.getWidth();
        from.animate().cancel();
        in.animate().cancel();
        in.setVisibility(View.VISIBLE);
        if (forward) {
            in.bringToFront();
            in.setAlpha(1f);
            in.setTranslationX(w);
            in.animate().translationX(0).setDuration(SLIDE).setInterpolator(new SlideEase(false)).start();
            from.animate().translationX(-w * 0.25f).alpha(0.6f).setDuration(SLIDE)
                    .setInterpolator(new SlideEase(false)).withEndAction(() -> park(from)).start();
        } else {
            from.bringToFront();
            in.setAlpha(0.6f);
            in.setTranslationX(-w * 0.25f);
            in.animate().translationX(0).alpha(1f).setDuration(SLIDE).setInterpolator(new SlideEase(true)).start();
            from.animate().translationX(w).setDuration(SLIDE)
                    .setInterpolator(new SlideEase(true)).withEndAction(() -> park(from)).start();
        }
    }

    @Override
    public void onBackPressed() {
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 备份 / 恢复 ----------
    private static final String[] EXTRA_KEYS = {"dark", "nav_transparent", "extend_feed", "center_tabs", "dump", "pendant_scale"};

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void exportBackup() {
        String name = "DyHide_backup_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".json";
        startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT);
    }

    private void importBackup() {
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT);
    }

    private Set<String> knownKeys() {
        Set<String> k = new HashSet<>(Arrays.asList(EXTRA_KEYS));
        for (Rules.R r : Rules.ALL) k.add(r.key());
        return k;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_EXPORT) {
                JSONObject prefs = new JSONObject();   // 导出当前生效的全部值（没改过的取默认值），恢复时才是完整还原
                for (Rules.R r : Rules.ALL) prefs.put(r.key(), cfg.getBoolean(r.key(), true));
                for (String k : EXTRA_KEYS) {
                    if (k.equals("pendant_scale")) prefs.put(k, Math.round(cfg.getFloat(k, 1f) * 100f) / 100.0);
                    else prefs.put(k, cfg.getBoolean(k, !k.equals("dark")));
                }
                JSONObject root = new JSONObject().put("app", "DyHide").put("version", VOL).put("prefs", prefs);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("已导出 " + prefs.length() + " 项设置");
            } else if (req == REQ_IMPORT) {
                String text;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    for (int n; (n = in.read(buf)) > 0; ) b.write(buf, 0, n);
                    text = new String(b.toByteArray(), StandardCharsets.UTF_8);
                }
                JSONObject p = new JSONObject(text).getJSONObject("prefs");
                Set<String> known = knownKeys();
                SharedPreferences.Editor ed = cfg.edit();
                int n = 0;
                for (Iterator<String> it = p.keys(); it.hasNext(); ) {   // 只在这里校验一次：未知项、类型不对的一律跳过
                    String k = it.next();
                    Object v = p.get(k);
                    if (!known.contains(k)) continue;
                    if (k.equals("pendant_scale") && v instanceof Number) {
                        ed.putFloat(k, Math.max(0.5f, Math.min(1.5f, ((Number) v).floatValue())));
                    } else if (v instanceof Boolean) {
                        ed.putBoolean(k, (Boolean) v);
                    } else {
                        continue;
                    }
                    n++;
                }
                ed.apply();
                palette(cfg.getBoolean("dark", false));
                build();
                toast("已恢复 " + n + " 项设置");
            }
        } catch (Exception e) {
            toast((req == REQ_EXPORT ? "导出失败：" : "恢复失败：") + e.getMessage());
        }
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", "选择要从信息流里抹去的元素。改动约 1 秒内在抖音生效，无需重启。", path, col -> {
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            int n = 0;
            col.addView(hair(), hairLp(32, 0));
            for (final String g : groups) {
                col.addView(magRow(++n, g, summary(g, null), () -> push(groupPage(g))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, "逐项开关，改动约 1 秒内生效。", path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) body.addView(switchRow(r.label, r.key(), true));
            }
            if (body.getChildCount() > 0) addGroup(col, wrapCard(body), 32);
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            int n = 0;
            if (!subs.isEmpty()) col.addView(hair(), hairLp(40, 0));
            for (final String s : subs) {
                col.addView(magRow(++n, s, summary(g, s), () -> push(subPage(g, s))), lp(0, 0, 0, 0));
                col.addView(hair(), hairLp(0, 0));
            }
        });
    }

    private Page subPage(String g, String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, "逐项开关，改动约 1 秒内生效。", path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) body.addView(switchRow(r.label, r.key(), true));
            }
            addGroup(col, wrapCard(body), 32);
        });
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", "主题、底栏与红包挂件，克制地调整。", path, col -> {
            LinearLayout theme = cardBody();
            theme.addView(darkRow());
            addGroup(col, wrapCard(theme), 32);
            LinearLayout a = cardBody();
            a.addView(switchRow("底栏背景全透明", "nav_transparent", true));
            a.addView(switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 40);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
            addGroup(col, pendantCard(), 40);
            col.addView(text("红包挂件可在 0.5× – 1.5× 之间自由调节，松手后约 1 秒在抖音生效；默认 1.0×。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置"));
        return page("设置", "设置", "备份、统计与调试。", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            a.addView(valueRow("规则总数", total));
            a.addView(valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 32);
            LinearLayout bk = cardBody();
            bk.addView(actionRow("导出备份", "把全部开关、主题和挂件大小存成一个 JSON 文件", this::exportBackup));
            bk.addView(actionRow("恢复备份", "从备份文件还原，覆盖当前设置", this::importBackup));
            addGroup(col, wrapCard(bk), 40);
            LinearLayout b = cardBody();
            b.addView(switchRow("调试：导出控件树和状态文件", "dump", true));
            addGroup(col, wrapCard(b), 40);
            col.addView(text("文件保存在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/ 下的 dyhide_status.txt 和 viewdump_*.txt。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    /** 杂志内页：报头（品牌/卷期 + 发丝线）→ 短色条 → 衬线大标题 → 斜体导语 → 正文 → 版权页脚。 */
    private Page page(String crumb, String title, String deck, final List<String> path, Fill fill) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_ALWAYS);   // 到顶/到底的轻微回弹（Android 12+ 为弹性拉伸）
        sv.setBackground(new Paper(density));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(28), dp(16), dp(28), dp(64));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));

        LinearLayout mast = new LinearLayout(this);
        mast.setGravity(Gravity.CENTER_VERTICAL);
        mast.setMinimumHeight(dp(44));
        if (path.size() >= 2) {   // 二级及以下页面：左上角返回键
            LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(-2, -2);
            back.leftMargin = -dp(10);
            mast.addView(new Press(this, new Arrow(this, density), -2, () -> popTo(path.size() - 1)), back);
        } else {
            TextView brand = text("DYHIDE", 12, INK, true);
            brand.setLetterSpacing(0.32f);
            mast.addView(brand);
        }
        mast.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView vol = text("VOL. " + VOL + "  ·  " + TAB_EN[tab], 11, SUB, false);
        vol.setLetterSpacing(0.18f);
        mast.addView(vol);
        col.addView(mast, lp(0, 0, 0, 0));
        col.addView(hair(), hairLp(0, 0));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 12, 0, 0));

        View bar = new View(this);
        bar.setBackgroundColor(ACCENT);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(dp(28), dp(3));
        barLp.topMargin = dp(40);
        barLp.bottomMargin = dp(16);
        col.addView(bar, barLp);
        TextView head = text(title, 44, INK, true);
        head.setTypeface(Typeface.create("serif", Typeface.BOLD));
        head.setLineSpacing(0, 1.0f);
        col.addView(head, lp(0, 0, 0, 0));
        TextView dk = text(deck, 15, SUB, false);
        dk.setTypeface(Typeface.create("serif", Typeface.ITALIC));
        dk.setLineSpacing(0, 1.25f);
        col.addView(dk, lp(0, 12, 24, 0));

        fill.fill(col);
        col.addView(colophon(), lp(0, 64, 0, 0));
        return new Page(sv, crumb);
    }

    private View colophon() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(hair(), hairLp(0, 16));
        TextView t = text("DYHIDE  ·  抖音UI隐藏  ·  FIN", 11, SUB, false);
        t.setLetterSpacing(0.2f);
        c.addView(t);
        return c;
    }

    private View hair() {
        View v = new View(this);
        v.setBackgroundColor(HAIR);
        return v;
    }

    private LinearLayout.LayoutParams hairLp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.5f)));
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (last) {
                row.addView(c);
            } else {
                c.setPadding(0, dp(8), 0, dp(8));
                row.addView(new Press(this, c, -2, () -> popTo(idx + 1)));
                row.addView(text("  ›  ", 14, SUB, false));
            }
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------
    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    /** 目录式入口：斜体衬线大号序号 + 衬线标题 + 摘要。整行可点。 */
    private View magRow(int n, String name, TextView sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(20), 0, dp(20));
        TextView num = text(String.format(Locale.US, "%02d", n), 40, ACCENT, true);
        num.setTypeface(Typeface.create("serif", Typeface.BOLD_ITALIC));
        num.setAlpha(0.5f);
        row.addView(num, new LinearLayout.LayoutParams(dp(68), -2));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(name, 24, INK, true);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        mid.addView(title);
        mid.addView(sub, lp(0, 4, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 22, SUB, false));
        return new Press(this, row, -1, go);
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        FrameLayout f = new FrameLayout(this);
        f.addView(row);
        return f;
    }

    private View switchRow(String label, final String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, cfg.getBoolean(key, def), density);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            sw.set(!sw.checked);
            cfg.edit().putBoolean(key, sw.checked).apply();
            refreshAll();
        });
    }

    /** 点一下执行动作的行：标题 + 说明 + 箭头。 */
    private View actionRow(String label, String hint, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(text(label, 16, INK, false));
        mid.addView(text(hint, 13, SUB, false), lp(0, 2, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("→", 20, SUB, false));
        return new Press(this, row, -1, go);
    }

    private static String fmtScale(float x) {
        return String.format(Locale.US, "%.2f×", x);
    }

    /** 红包挂件大小：0.5×–1.5× 滑杆（默认 1.0×）+ 恢复默认。 */
    private View pendantCard() {
        final float min = 0.5f, max = 1.5f;
        float init = cfg.getFloat("pendant_scale", 1f);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("红包挂件大小", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = num(fmtScale(init));
        val.setTextColor(ACCENT);
        head.addView(val);
        row.addView(head);
        final Slider sl = new Slider(this, density, (init - min) / (max - min), new String[]{"0.5×", "1.0×", "1.5×"}, (v, done) -> {
            float x = Math.round((min + v * (max - min)) * 100f) / 100f;
            val.setText(fmtScale(x));
            if (done) cfg.edit().putFloat("pendant_scale", x).apply();
        });
        row.addView(sl, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout first = new FrameLayout(this);
        first.addView(row);
        LinearLayout body = cardBody();
        body.addView(first);
        body.addView(actionRow("恢复默认", "1.0×", () -> {
            cfg.edit().putFloat("pendant_scale", 1f).apply();
            sl.set(0.5f);
            val.setText(fmtScale(1f));
        }));
        return wrapCard(body);
    }

    /** 深色模式：点击后新主题从开关位置圆形扩散（切回时原路收回）。 */
    private View darkRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text("深色模式", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, animateDark != dark, density);
        if (animateDark) {
            animateDark = false;
            sw.post(() -> sw.set(dark));
        }
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            int[] loc = new int[2];
            sw.getLocationInWindow(loc);
            setDark(!dark, new RectF(loc[0], loc[1], loc[0] + sw.getWidth(), loc[1] + sw.getHeight()));
        });
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    /**
     * 卡片：三层柔和阴影（紧、中、宽）代替边框；内容按圆角裁剪，所以行的波纹/按压范围正好对齐卡片边缘。
     * 首行上、末行下补 16dp，行与行之间内容间距为 16dp。
     */
    private View wrapCard(LinearLayout body) {
        View first = ((ViewGroup) body.getChildAt(0)).getChildAt(0);
        first.setPadding(first.getPaddingLeft(), dp(16), first.getPaddingRight(), first.getPaddingBottom());
        View last = ((ViewGroup) body.getChildAt(body.getChildCount() - 1)).getChildAt(0);
        last.setPadding(last.getPaddingLeft(), last.getPaddingTop(), last.getPaddingRight(), dp(16));

        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x0F000000, 0x17000000);
        shadowLayer(w, 8, 0x0A000000, 0x12000000);
        shadowLayer(w, 18, 0x07000000, 0x0F000000);
        body.setElevation(dp(19));
        body.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16));
                o.setAlpha(0f);   // 只用于裁剪，不产生阴影
            }
        });
        body.setClipToOutline(true);
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(16));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 不同组之间 32–48dp。 */
    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
