package com.dyhide;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    static int BG, CARD, INK, SUB, ACCENT, OFF;
    static boolean dark;
    static final long SLIDE = 300, FADE = 240;
    static final String[] TABS = {"规则", "外观", "设置"};

    static void palette(boolean d) {
        dark = d;
        BG = d ? 0xFF0E0F13 : 0xFFF2F3F7;
        CARD = d ? 0xFF1B1D24 : 0xFFFFFFFF;
        INK = d ? 0xFFECEEF3 : 0xFF15181F;
        SUB = d ? 0xFF8A91A3 : 0xFF7C8394;
        ACCENT = d ? 0xFF6C93FF : 0xFF3B6CF6;
        OFF = d ? 0xFF3A3F4D : 0xFFC8CCD6;
    }

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    /** 可按压的容器：按下内容缩到 96%，松手时弹簧回弹（先略超过 100% 再落回）；波纹从手指按下的位置扩散。 */
    private static final class Press extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float rx, ry, radius, alpha;
        private ValueAnimator grow, fade, spring;

        Press(Context c, View content, int width, Runnable click) {
            super(c);
            setWillNotDraw(false);
            addView(content, new LayoutParams(width, -2));
            setOnClickListener(v -> click.run());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (alpha > 0f) {
                paint.setAlpha((int) (alpha * 40));
                canvas.drawCircle(rx, ry, radius, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) down(e.getX(), e.getY());
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) up();
            return super.onTouchEvent(e);
        }

        private void down(float x, float y) {
            if (fade != null) fade.cancel();
            if (spring != null) spring.cancel();
            paint.setColor(dark ? Color.WHITE : Color.BLACK);
            rx = x;
            ry = y;
            alpha = 1f;
            grow = ValueAnimator.ofFloat(0f, (float) Math.hypot(Math.max(x, getWidth() - x), Math.max(y, getHeight() - y)));
            grow.setDuration(450);
            grow.setInterpolator(new DecelerateInterpolator());
            grow.addUpdateListener(a -> { radius = (float) a.getAnimatedValue(); invalidate(); });
            grow.start();
            getChildAt(0).animate().cancel();
            getChildAt(0).animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
        }

        private void up() {
            fade = ValueAnimator.ofFloat(alpha, 0f);
            fade.setDuration(250);
            fade.addUpdateListener(a -> { alpha = (float) a.getAnimatedValue(); invalidate(); });
            fade.start();
            final View c = getChildAt(0);
            c.animate().cancel();
            final float from = c.getScaleX();
            spring = ValueAnimator.ofFloat(0f, 0.5f);   // 数值为秒；欠阻尼弹簧：x(t) = 1 - (1-from)·e^(-ζω0t)·(cos ωd·t + ζω0/ωd·sin ωd·t)
            spring.setDuration(500);
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                double w0 = 2 * Math.PI * 3.2, z = 0.42, wd = w0 * Math.sqrt(1 - z * z);
                float s = a.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t)));
                c.setScaleX(s);
                c.setScaleY(s);
            });
            spring.start();
        }
    }

    /** 开关：起步时前沿先走、横向拉长成胶囊；后沿滞后跟上，落位时压回原宽（略压窄再回弹），不像一张贴纸。 */
    private static final class Toggle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        boolean checked;
        private float l, r, cp;   // 圆点左右边缘(px)、轨道颜色进度
        private ValueAnimator anim;

        Toggle(Context c, boolean on, float density) {
            super(c);
            d = density;
            checked = on;
            l = (on ? 24f : 4f) * d;
            r = l + 24 * d;
            cp = on ? 1f : 0f;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(52 * d), Math.round(32 * d));
        }

        void set(boolean on) {
            checked = on;
            if (anim != null) anim.cancel();
            final float l0 = l, r0 = r, l1 = (on ? 24f : 4f) * d, r1 = l1 + 24 * d, c0 = cp, c1 = on ? 1f : 0f;
            final boolean right = l1 > l0;
            final OvershootInterpolator squash = new OvershootInterpolator(2.2f);
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(460);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                float t = a.getAnimatedFraction();
                float x = Math.min(1f, t / 0.7f);
                float lead = 1f - (1f - x) * (1f - x) * (1f - x);
                float trail = squash.getInterpolation(Math.max(0f, (t - 0.15f) / 0.85f));
                l = l0 + (l1 - l0) * (right ? trail : lead);
                r = r0 + (r1 - r0) * (right ? lead : trail);
                cp = c0 + (c1 - c0) * lead;
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            paint.setColor((Integer) new ArgbEvaluator().evaluate(Math.max(0f, Math.min(1f, cp)), OFF, ACCENT));
            rect.set(0, 0, getWidth(), h);
            c.drawRoundRect(rect, h / 2, h / 2, paint);
            paint.setColor(Color.WHITE);
            rect.set(l, 4 * d, r, h - 4 * d);
            c.drawRoundRect(rect, 12 * d, 12 * d, paint);
        }
    }

    /** 底部导航：背景块滑到选中项；选中项展开显示文字，其余只保留图标。 */
    private static final class NavBar extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        private final IntConsumer onSelect;
        private final float[] left = new float[3], wid = new float[3];
        private float pos;
        private ValueAnimator anim;

        NavBar(Context c, float density, IntConsumer onSelect) {
            super(c);
            d = density;
            this.onSelect = onSelect;
            setBackgroundColor(CARD);
            setElevation(10 * d);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setTextSize(14 * d);
            paint.setFakeBoldText(true);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), Math.round(64 * d) + getPaddingBottom());
        }

        void select(int i, boolean animate) {
            if (anim != null) anim.cancel();
            if (!animate) {
                pos = i;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(pos, i);
            anim.setDuration(340);
            anim.setInterpolator(new OvershootInterpolator(0.9f));
            anim.addUpdateListener(a -> { pos = (float) a.getAnimatedValue(); invalidate(); });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float small = 56 * d, big = 132 * d, cy = 32 * d, x = (getWidth() - (2 * small + big)) / 2f;
            for (int i = 0; i < 3; i++) {
                wid[i] = small + (big - small) * Math.max(0f, 1f - Math.abs(pos - i));
                left[i] = x;
                x += wid[i];
            }
            float p = Math.max(0f, Math.min(2f, pos));
            int i0 = Math.min(1, (int) p);
            float f = p - i0;
            float pl = left[i0] + (left[i0 + 1] - left[i0]) * f, pw = wid[i0] + (wid[i0 + 1] - wid[i0]) * f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ACCENT);
            paint.setAlpha(dark ? 56 : 36);
            rect.set(pl, cy - 22 * d, pl + pw, cy + 22 * d);
            c.drawRoundRect(rect, 22 * d, 22 * d, paint);
            for (int i = 0; i < 3; i++) {
                float w = Math.max(0f, 1f - Math.abs(pos - i));
                int col = (Integer) new ArgbEvaluator().evaluate(w, SUB, ACCENT);
                float gap = 8 * d * w, group = 22 * d + gap + paint.measureText(TABS[i]) * w;
                float gx = left[i] + (wid[i] - group) / 2f;
                icon(c, i, gx + 11 * d, cy, col);
                if (w > 0.05f) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    paint.setAlpha((int) (255 * w));
                    c.save();
                    c.clipRect(left[i], 0, left[i] + wid[i], getHeight());
                    c.drawText(TABS[i], gx + 22 * d + gap, cy + 5 * d, paint);
                    c.restore();
                }
            }
        }

        private void icon(Canvas c, int i, float cx, float cy, int col) {
            float s = 11 * d;
            paint.setColor(col);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * d);
            if (i == 0) {
                for (int k = -1; k <= 1; k++) c.drawLine(cx - s, cy + k * 6 * d, cx + s * (k == 0 ? 0.5f : 1f), cy + k * 6 * d, paint);
            } else if (i == 1) {
                c.drawCircle(cx, cy, s, paint);
                paint.setStyle(Paint.Style.FILL);
                rect.set(cx - s, cy - s, cx + s, cy + s);
                c.drawArc(rect, 90, 180, true, paint);
            } else {
                c.drawCircle(cx, cy, s * 0.45f, paint);
                for (int k = 0; k < 8; k++) {
                    float cos = (float) Math.cos(k * Math.PI / 4), sin = (float) Math.sin(k * Math.PI / 4);
                    c.drawLine(cx + cos * s * 0.75f, cy + sin * s * 0.75f, cx + cos * s, cy + sin * s, paint);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                for (int i = 0; i < 3; i++) if (e.getX() >= left[i] && e.getX() < left[i] + wid[i]) onSelect.accept(i);
            }
            return true;
        }
    }

    /** 深色模式切换：新主题从开关位置圆形扩散；切回时原路收回。叠加层是切换前的截图。 */
    private static final class Reveal extends View {
        private final Bitmap old;
        private final Path path = new Path();
        private final float cx, cy, max;
        private final boolean expand;
        private float radius;

        Reveal(Context c, Bitmap old, float cx, float cy, boolean expand) {
            super(c);
            this.old = old;
            this.cx = cx;
            this.cy = cy;
            this.expand = expand;
            max = (float) Math.hypot(Math.max(cx, old.getWidth() - cx), Math.max(cy, old.getHeight() - cy));
            radius = expand ? 0f : max;
        }

        void start() {
            ValueAnimator a = expand ? ValueAnimator.ofFloat(0f, max) : ValueAnimator.ofFloat(max, 0f);
            a.setDuration(560);
            a.setInterpolator(new AccelerateDecelerateInterpolator());
            a.addUpdateListener(v -> { radius = (float) v.getAnimatedValue(); invalidate(); });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator an) {
                    ((ViewGroup) getParent()).removeView(Reveal.this);
                    old.recycle();
                }
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            path.reset();
            path.addCircle(cx, cy, radius, Path.Direction.CW);
            c.save();
            if (expand) c.clipOutPath(path);   // 圆内露出新主题（实时界面），圆外仍是旧截图
            else c.clipPath(path);             // 圆内是旧主题截图，随圆缩小被新主题取代
            c.drawBitmap(old, 0, 0, null);
            c.restore();
        }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private NavBar nav;
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences("config", MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences("config", MODE_PRIVATE);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = prefs();
        density = getResources().getDisplayMetrics().density;
        palette(cfg.getBoolean("dark", false));
        build();
    }

    /** 按当前调色板重建整个界面（首次启动和切换深浅色时调用），回到当前标签的首页。 */
    private void build() {
        stacks.clear();
        refreshers.clear();
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = new NavBar(this, density, this::switchTab);
        if (Build.VERSION.SDK_INT >= 28) {
            nav.setOutlineAmbientShadowColor(0x1A000000);
            nav.setOutlineSpotShadowColor(0x26000000);
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, 0);
            nav.setPadding(0, 0, 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        Page p = rootPage(tab);
        stacks.get(tab).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        nav.select(tab, false);
    }

    private void setDark(final boolean on, final float cx, final float cy) {
        final View decor = getWindow().getDecorView();
        final Bitmap old = Bitmap.createBitmap(decor.getWidth(), decor.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.request(getWindow(), old, res -> {
            cfg.edit().putBoolean("dark", on).apply();
            palette(on);
            build();
            if (res == PixelCopy.SUCCESS) {
                Reveal ov = new Reveal(this, old, cx, cy, on);
                ((ViewGroup) decor).addView(ov, new FrameLayout.LayoutParams(-1, -1));
                ov.start();
            }
        }, new Handler(Looper.getMainLooper()));
    }

    // ---------- 导航：右侧滑入/反向滑出 300ms，底部标签淡入淡出 ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void push(final Page p) {
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        final float w = content.getWidth();
        p.view.setTranslationX(w);
        p.view.animate().translationX(0).setDuration(SLIDE).setInterpolator(new DecelerateInterpolator()).start();
        old.view.animate().cancel();
        old.view.animate().translationX(-w * 0.25f).alpha(0.6f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    old.view.setVisibility(View.GONE);
                    old.view.setTranslationX(0);
                    old.view.setAlpha(1f);
                }).start();
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。动画不阻塞点击：返回过程中可以立刻进入别的页面。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (st.size() <= keep) return;
        final float w = content.getWidth();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        target.view.animate().cancel();
        target.view.setVisibility(View.VISIBLE);
        target.view.setTranslationX(-w * 0.25f);
        target.view.setAlpha(0.6f);
        target.view.animate().translationX(0).alpha(1f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator()).start();
        topPage.view.animate().translationX(w).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> content.removeView(topPage.view)).start();
    }

    private void switchTab(int to) {
        if (to == tab) return;
        final View from = top(tab).view;
        tab = to;
        nav.select(to, true);
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        from.animate().cancel();
        in.animate().cancel();
        in.setVisibility(View.VISIBLE);
        in.setAlpha(0f);
        in.setTranslationX(0);
        from.animate().alpha(0f).setDuration(FADE).withEndAction(() -> {
            from.setVisibility(View.GONE);
            from.setAlpha(1f);
        }).start();
        in.animate().alpha(1f).setDuration(FADE).start();
    }

    @Override
    public void onBackPressed() {
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", path, col -> {
            col.addView(text("选择要隐藏的界面元素，改动约 1 秒内在抖音生效，无需重启。", 14, SUB, false), lp(0, 12, 0, 0));
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            for (final String g : groups) {
                LinearLayout body = cardBody();
                body.addView(navRow(g, summary(g, null), () -> push(groupPage(g))));
                addGroup(col, wrapCard(body), 40);
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) body.addView(switchRow(r.label, r.key(), true));
            }
            if (body.getChildCount() > 0) addGroup(col, wrapCard(body), 12);
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            for (final String s : subs) {
                LinearLayout sb = cardBody();
                sb.addView(navRow(s, summary(g, s), () -> push(subPage(g, s))));
                addGroup(col, wrapCard(sb), 40);
            }
        });
    }

    private Page subPage(String g, String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) body.addView(switchRow(r.label, r.key(), true));
            }
            addGroup(col, wrapCard(body), 12);
        });
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", path, col -> {
            LinearLayout theme = cardBody();
            theme.addView(darkRow());
            addGroup(col, wrapCard(theme), 12);
            LinearLayout a = cardBody();
            a.addView(switchRow("底栏背景全透明", "nav_transparent", true));
            a.addView(switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 40);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("设置"));
        return page("设置", "设置", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            a.addView(valueRow("规则总数", total));
            a.addView(valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 12);
            LinearLayout b = cardBody();
            b.addView(switchRow("调试：导出控件树和状态文件", "dump", true));
            addGroup(col, wrapCard(b), 40);
            col.addView(text("文件保存在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/ 下的 dyhide_status.txt 和 viewdump_*.txt。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page page(String crumb, String title, List<String> path, Fill fill) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(20), dp(24), dp(20), dp(56));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 0, 0, 12));
        col.addView(text(title, 30, INK, true), lp(0, 0, 0, 0));
        fill.fill(col);
        return new Page(sv, crumb);
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (last) {
                row.addView(c);
            } else {
                c.setPadding(0, dp(8), 0, dp(8));
                row.addView(new Press(this, c, -2, () -> popTo(idx + 1)));
                row.addView(text("  ›  ", 14, SUB, false));
            }
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------
    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    /** 整行可点；内容自带左右 20dp 内边距，波纹铺满整行（贴合卡片边缘）。 */
    private View navRow(String name, TextView sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(name, 18, INK, true));
        left.addView(sub, lp(0, 4, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("›", 26, SUB, false));
        return new Press(this, row, -1, go);
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        FrameLayout f = new FrameLayout(this);
        f.addView(row);
        return f;
    }

    private View switchRow(String label, final String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, cfg.getBoolean(key, def), density);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            sw.set(!sw.checked);
            cfg.edit().putBoolean(key, sw.checked).apply();
            refreshAll();
        });
    }

    /** 深色模式：点击后新主题从开关位置圆形扩散（切回时原路收回）。 */
    private View darkRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text("深色模式", 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, dark, density);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            int[] loc = new int[2];
            sw.getLocationInWindow(loc);
            setDark(!dark, loc[0] + sw.getWidth() / 2f, loc[1] + sw.getHeight() / 2f);
        });
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    /**
     * 卡片：三层柔和阴影（紧、中、宽）代替边框；内容按圆角裁剪，所以行的波纹/按压范围正好对齐卡片边缘。
     * 首行上、末行下补 16dp，行与行之间内容间距为 16dp。
     */
    private View wrapCard(LinearLayout body) {
        View first = ((ViewGroup) body.getChildAt(0)).getChildAt(0);
        first.setPadding(first.getPaddingLeft(), dp(16), first.getPaddingRight(), first.getPaddingBottom());
        View last = ((ViewGroup) body.getChildAt(body.getChildCount() - 1)).getChildAt(0);
        last.setPadding(last.getPaddingLeft(), last.getPaddingTop(), last.getPaddingRight(), dp(16));

        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x14000000, 0x1F000000);
        shadowLayer(w, 8, 0x0F000000, 0x1A000000);
        shadowLayer(w, 18, 0x0A000000, 0x14000000);
        body.setElevation(dp(19));
        body.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(20));
                o.setAlpha(0f);   // 只用于裁剪，不产生阴影
            }
        });
        body.setClipToOutline(true);
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(20));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 不同组之间 40dp。 */
    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
