package com.dyhide;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

public class MainActivity extends Activity {
    static final int BG = 0xFFF2F3F7, CARD = 0xFFFFFFFF, INK = 0xFF15181F, SUB = 0xFF7C8394,
            ACCENT = 0xFF3B6CF6, OFF = 0xFFC8CCD6;
    static final long SLIDE = 300, FADE = 240;
    static final String[] TABS = {"规则", "外观", "状态"};

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    /** 可按压的容器：按下内容缩到 96%，松手时弹簧回弹（先略超过 100% 再落回）；波纹从手指按下的位置扩散。 */
    private static final class Press extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float rx, ry, radius, alpha;
        private ValueAnimator grow, fade, spring;

        Press(Context c, View content, int width, Runnable click) {
            super(c);
            paint.setColor(Color.BLACK);
            setWillNotDraw(false);
            addView(content, new LayoutParams(width, -2));
            setOnClickListener(v -> click.run());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (alpha > 0f) {
                paint.setAlpha((int) (alpha * 40));
                canvas.drawCircle(rx, ry, radius, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) down(e.getX(), e.getY());
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) up();
            return super.onTouchEvent(e);
        }

        private void down(float x, float y) {
            if (fade != null) fade.cancel();
            if (spring != null) spring.cancel();
            rx = x;
            ry = y;
            alpha = 1f;
            grow = ValueAnimator.ofFloat(0f, (float) Math.hypot(Math.max(x, getWidth() - x), Math.max(y, getHeight() - y)));
            grow.setDuration(450);
            grow.setInterpolator(new DecelerateInterpolator());
            grow.addUpdateListener(a -> { radius = (float) a.getAnimatedValue(); invalidate(); });
            grow.start();
            getChildAt(0).animate().cancel();
            getChildAt(0).animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
        }

        private void up() {
            fade = ValueAnimator.ofFloat(alpha, 0f);
            fade.setDuration(250);
            fade.addUpdateListener(a -> { alpha = (float) a.getAnimatedValue(); invalidate(); });
            fade.start();
            final View c = getChildAt(0);
            c.animate().cancel();
            final float from = c.getScaleX();
            spring = ValueAnimator.ofFloat(0f, 0.5f);   // 数值为秒；欠阻尼弹簧：x(t) = 1 - (1-from)·e^(-ζω0t)·(cos ωd·t + ζω0/ωd·sin ωd·t)
            spring.setDuration(500);
            spring.setInterpolator(new LinearInterpolator());
            spring.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                double w0 = 2 * Math.PI * 3.2, z = 0.42, wd = w0 * Math.sqrt(1 - z * z);
                float s = a.getAnimatedFraction() >= 1f ? 1f : (float) (1 - (1 - from)
                        * Math.exp(-z * w0 * t) * (Math.cos(wd * t) + z * w0 / wd * Math.sin(wd * t)));
                c.setScaleX(s);
                c.setScaleY(s);
            });
            spring.start();
        }
    }

    /** 开关：圆点移动时横向拉长成胶囊，到达终点后恢复为圆形，带轻微回弹。 */
    private static final class Toggle extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float density;
        boolean checked;
        private float pos, stretch;
        private ValueAnimator anim;

        Toggle(Context c, boolean on, float density) {
            super(c);
            this.density = density;
            checked = on;
            pos = on ? 1f : 0f;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Math.round(52 * density), Math.round(32 * density));
        }

        void set(boolean on) {
            checked = on;
            if (anim != null) anim.cancel();
            final float from = pos, to = on ? 1f : 0f;
            final OvershootInterpolator bounce = new OvershootInterpolator(1.6f);
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(380);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                float t = a.getAnimatedFraction();
                pos = from + (to - from) * bounce.getInterpolation(t);
                stretch = (float) Math.sin(Math.PI * t);
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), pad = 4 * density, dia = h - 2 * pad;
            paint.setColor((Integer) new ArgbEvaluator().evaluate(Math.max(0f, Math.min(1f, pos)), OFF, ACCENT));
            rect.set(0, 0, w, h);
            c.drawRoundRect(rect, h / 2, h / 2, paint);
            float cx = pad + dia / 2 + pos * (w - 2 * pad - dia);
            float tw = dia * (1 + 0.7f * stretch);
            rect.set(cx - tw / 2, pad, cx + tw / 2, h - pad);
            paint.setColor(Color.WHITE);
            c.drawRoundRect(rect, dia / 2, dia / 2, paint);
        }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private final TextView[] tabViews = new TextView[3];
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;
    private boolean busy;

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences("config", MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences("config", MODE_PRIVATE);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = prefs();
        density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        final LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(CARD);
        bar.setElevation(dp(10));
        if (Build.VERSION.SDK_INT >= 28) {
            bar.setOutlineAmbientShadowColor(0x1A000000);
            bar.setOutlineSpotShadowColor(0x26000000);
        }
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = text(TABS[i], 15, SUB, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(16), 0, dp(16));
            tabViews[i] = t;
            bar.addView(new Press(this, t, -1, () -> switchTab(idx)), new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, 0);
            bar.setPadding(0, 0, 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);

        Page p = rootPage(0);
        stacks.get(0).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        styleTabs();
    }

    // ---------- 导航：右侧滑入/反向滑出 300ms，底部标签淡入淡出 ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void push(final Page p) {
        if (busy) return;
        busy = true;
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        final float w = content.getWidth();
        p.view.setTranslationX(w);
        p.view.animate().translationX(0).setDuration(SLIDE).setInterpolator(new DecelerateInterpolator()).start();
        old.view.animate().translationX(-w * 0.25f).alpha(0.6f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    old.view.setVisibility(View.GONE);
                    old.view.setTranslationX(0);
                    old.view.setAlpha(1f);
                    busy = false;
                }).start();
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (busy || st.size() <= keep || keep < 1) return;
        busy = true;
        final float w = content.getWidth();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        target.view.setVisibility(View.VISIBLE);
        target.view.setTranslationX(-w * 0.25f);
        target.view.setAlpha(0.6f);
        target.view.animate().translationX(0).alpha(1f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator()).start();
        topPage.view.animate().translationX(w).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    content.removeView(topPage.view);
                    busy = false;
                }).start();
    }

    private void switchTab(int to) {
        if (to == tab || busy) return;
        busy = true;
        final View from = top(tab).view;
        tab = to;
        styleTabs();
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        in.setVisibility(View.VISIBLE);
        in.setAlpha(0f);
        in.setTranslationX(0);
        from.animate().alpha(0f).setDuration(FADE).start();
        in.animate().alpha(1f).setDuration(FADE).withEndAction(() -> {
            from.setVisibility(View.GONE);
            from.setAlpha(1f);
            busy = false;
        }).start();
    }

    private void styleTabs() {
        for (int i = 0; i < 3; i++) {
            tabViews[i].setTextColor(i == tab ? ACCENT : SUB);
            tabViews[i].setTypeface(i == tab ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    @Override
    public void onBackPressed() {
        if (busy) return;
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", path, col -> {
            col.addView(text("选择要隐藏的界面元素，改动约 1 秒内在抖音生效，无需重启。", 14, SUB, false), lp(0, 12, 0, 0));
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            for (final String g : groups) {
                LinearLayout body = cardBody();
                body.addView(navRow(g, summary(g, null), () -> push(groupPage(g))));
                addGroup(col, wrapCard(body), 40);
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) body.addView(switchRow(r.label, r.key(), true));
            }
            if (body.getChildCount() > 0) addGroup(col, wrapCard(body), 12);
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            for (final String s : subs) {
                LinearLayout sb = cardBody();
                sb.addView(navRow(s, summary(g, s), () -> push(subPage(g, s))));
                addGroup(col, wrapCard(sb), 40);
            }
        });
    }

    private Page subPage(String g, String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) body.addView(switchRow(r.label, r.key(), true));
            }
            addGroup(col, wrapCard(body), 12);
        });
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", path, col -> {
            LinearLayout a = cardBody();
            a.addView(switchRow("底栏背景全透明", "nav_transparent", true));
            a.addView(switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 12);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            b.addView(switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("状态"));
        return page("状态", "状态", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            a.addView(valueRow("规则总数", total));
            a.addView(valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 12);
            LinearLayout b = cardBody();
            b.addView(switchRow("调试：导出控件树和状态文件", "dump", true));
            addGroup(col, wrapCard(b), 40);
            col.addView(text("文件保存在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/ 下的 dyhide_status.txt 和 viewdump_*.txt。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page page(String crumb, String title, List<String> path, Fill fill) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(20), dp(24), dp(20), dp(56));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 0, 0, 12));
        col.addView(text(title, 30, INK, true), lp(0, 0, 0, 0));
        fill.fill(col);
        return new Page(sv, crumb);
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (last) {
                row.addView(c);
            } else {
                c.setPadding(0, dp(8), 0, dp(8));
                row.addView(new Press(this, c, -2, () -> popTo(idx + 1)));
                row.addView(text("  ›  ", 14, SUB, false));
            }
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------
    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    /** 整行可点；内容自带左右 20dp 内边距，波纹铺满整行（贴合卡片边缘）。 */
    private View navRow(String name, TextView sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(name, 18, INK, true));
        left.addView(sub, lp(0, 4, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("›", 26, SUB, false));
        return new Press(this, row, -1, go);
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        FrameLayout f = new FrameLayout(this);
        f.addView(row);
        return f;
    }

    private View switchRow(String label, final String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final Toggle sw = new Toggle(this, cfg.getBoolean(key, def), density);
        row.addView(sw);
        return new Press(this, row, -1, () -> {
            sw.set(!sw.checked);
            cfg.edit().putBoolean(key, sw.checked).apply();
            refreshAll();
        });
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    /**
     * 卡片：三层柔和阴影（紧、中、宽）代替边框；内容按圆角裁剪，所以行的波纹/按压范围正好对齐卡片边缘。
     * 首行上、末行下补 16dp，行与行之间内容间距为 16dp。
     */
    private View wrapCard(LinearLayout body) {
        View first = ((ViewGroup) body.getChildAt(0)).getChildAt(0);
        first.setPadding(first.getPaddingLeft(), dp(16), first.getPaddingRight(), first.getPaddingBottom());
        View last = ((ViewGroup) body.getChildAt(body.getChildCount() - 1)).getChildAt(0);
        last.setPadding(last.getPaddingLeft(), last.getPaddingTop(), last.getPaddingRight(), dp(16));

        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x14000000, 0x1F000000);
        shadowLayer(w, 8, 0x0F000000, 0x1A000000);
        shadowLayer(w, 18, 0x0A000000, 0x14000000);
        body.setElevation(dp(19));
        body.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(20));
                o.setAlpha(0f);   // 只用于裁剪，不产生阴影
            }
        });
        body.setClipToOutline(true);
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(20));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 不同组之间 40dp。 */
    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
