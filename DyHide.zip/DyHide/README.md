# 抖音UI隐藏（LSPosed 模块）
构建：推到 GitHub 后在 Actions 里下载 DyHide-apk；或用 Android Studio 打开后 Build > Build APK。
使用：安装 → LSPosed 启用并勾选抖音 → 强行停止抖音 → 在模块界面调开关（改完约1秒生效）。
v1.9：设置页杂志化（纸张/网点质感）、页面与底栏 320ms 两段式切换、备份/恢复（设置页）、红包挂件大小（外观页）、视频位置/分享给好友/底部搜索栏、底栏透明与分享面板偏移修复。
